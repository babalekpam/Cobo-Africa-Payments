// PATCH 2+3+6+9: New routes to MERGE into server/routes/auth.js
// Run first: npm install speakeasy qrcode
const crypto = require('crypto')
const bcrypt = require('bcryptjs')
const { v4: uuid } = require('uuid')
const db = require('../database')
const { auth } = require('../middleware/auth')
const emailSvc = require('../services/email')

// ── PATCH 3: KYC Daily Limits ─────────────────────────────────────────
const KYC_LIMITS = { 0: 100, 1: 5000, 2: 50000 }

function checkKYCLimit(user, amountUSD) {
  const limit = KYC_LIMITS[user.kyc_level || 0]
  if (amountUSD > limit) return { allowed: false, message: `KYC Level ${user.kyc_level||0} max: $${limit.toLocaleString()} per transfer. ${user.kyc_level<2?'Complete KYC to increase limits.':''}`, code: 'KYC_LIMIT_EXCEEDED', limit }
  const today = new Date().toISOString().slice(0,10)
  const todaySent = (db.get('transactions').filter(t => t.user_id===user.id && t.type==='send' && t.status!=='failed' && t.created_at.slice(0,10)===today).value()||[]).reduce((s,t)=>s+(t.amount||0),0)
  if (todaySent+amountUSD>limit) return { allowed:false, message:`Daily limit reached. Limit: $${limit.toLocaleString()}. Sent today: $${todaySent.toLocaleString()}. ${user.kyc_level<2?'Complete KYC to increase limits.':''}`, code:'DAILY_LIMIT_EXCEEDED', limit, sent_today:todaySent }
  return { allowed:true, limit, sent_today:todaySent }
}
module.exports.checkKYCLimit = checkKYCLimit
module.exports.KYC_LIMITS = KYC_LIMITS

// ── PATCH 9: Audit Log ────────────────────────────────────────────────
function addAuditLog(userId, action, ip, meta={}) {
  const logs = db.get('audit_logs').value() || []
  db.set('audit_logs', [...logs.slice(-9999), { id:uuid(), user_id:userId, action, ip, meta, created_at:new Date().toISOString() }]).write()
}
module.exports.addAuditLog = addAuditLog

// ── ROUTES — add these to your auth.js router ─────────────────────────
// POST /api/auth/forgot-password
module.exports.forgotPassword = async (req, res) => {
  const { email } = req.body
  res.json({ success:true, message:'If that email exists, a reset link has been sent.' })
  const user = db.get('users').find({ email:(email||'').toLowerCase().trim() }).value()
  if (!user) return
  const token = crypto.randomBytes(32).toString('hex')
  db.get('users').find({ id:user.id }).assign({ password_reset_token:token, password_reset_expires:new Date(Date.now()+3600000).toISOString() }).write()
  const resetUrl = `${process.env.CLIENT_URL||'http://localhost:5173'}/reset-password?token=${token}`
  emailSvc.sendPasswordResetEmail(user, resetUrl).catch(()=>{})
  addAuditLog(user.id, 'password_reset_requested', req.ip, {})
}

// POST /api/auth/reset-password
module.exports.resetPassword = async (req, res) => {
  const { token, new_password } = req.body
  if (!token||!new_password||new_password.length<8) return res.status(400).json({ success:false, message:'Token and new password (min 8 chars) required' })
  const user = db.get('users').find(u => u.password_reset_token===token && u.password_reset_expires && new Date(u.password_reset_expires)>new Date()).value()
  if (!user) return res.status(400).json({ success:false, message:'Invalid or expired reset token' })
  db.get('users').find({ id:user.id }).assign({ password:await bcrypt.hash(new_password,12), password_reset_token:null, password_reset_expires:null }).write()
  emailSvc.sendPasswordChangedEmail(user).catch(()=>{})
  addAuditLog(user.id, 'password_reset_done', req.ip, {})
  res.json({ success:true, message:'Password reset successfully. You can now log in.' })
}

// POST /api/auth/2fa/setup
module.exports.setup2FA = async (req, res) => {
  const speakeasy = require('speakeasy')
  const QRCode = require('qrcode')
  const user = db.get('users').find({ id:req.user.id }).value()
  if (user.two_fa_enabled) return res.status(400).json({ success:false, message:'2FA already enabled' })
  const secret = speakeasy.generateSecret({ name:`COBO (${user.email})`, length:20 })
  db.get('users').find({ id:req.user.id }).assign({ two_fa_secret:secret.base32 }).write()
  const qr_code = await QRCode.toDataURL(secret.otpauth_url)
  res.json({ success:true, secret:secret.base32, qr_code })
}

// POST /api/auth/2fa/verify
module.exports.verify2FA = (req, res) => {
  const speakeasy = require('speakeasy')
  const { totp_code } = req.body
  const user = db.get('users').find({ id:req.user.id }).value()
  if (!user.two_fa_secret) return res.status(400).json({ success:false, message:'Setup 2FA first' })
  const valid = speakeasy.totp.verify({ secret:user.two_fa_secret, encoding:'base32', token:totp_code, window:2 })
  if (!valid) return res.status(400).json({ success:false, message:'Invalid code. Try again.' })
  db.get('users').find({ id:req.user.id }).assign({ two_fa_enabled:true }).write()
  addAuditLog(req.user.id, '2fa_enabled', req.ip, {})
  res.json({ success:true, message:'2FA enabled successfully' })
}

// POST /api/auth/2fa/disable
module.exports.disable2FA = async (req, res) => {
  const { password } = req.body
  const user = db.get('users').find({ id:req.user.id }).value()
  const valid = await bcrypt.compare(password, user.password)
  if (!valid) return res.status(400).json({ success:false, message:'Incorrect password' })
  db.get('users').find({ id:req.user.id }).assign({ two_fa_enabled:false, two_fa_secret:null }).write()
  addAuditLog(req.user.id, '2fa_disabled', req.ip, {})
  res.json({ success:true, message:'2FA disabled' })
}

// GET /api/auth/audit-log
module.exports.getAuditLog = (req, res) => {
  const logs = (db.get('audit_logs').filter({ user_id:req.user.id }).value()||[]).sort((a,b)=>new Date(b.created_at)-new Date(a.created_at)).slice(0,50)
  res.json({ success:true, logs })
}

// ── Wire these into your auth.js like this: ───────────────────────────
// const patch = require('./auth-patch')
// router.post('/forgot-password', patch.forgotPassword)
// router.post('/reset-password', patch.resetPassword)
// router.post('/2fa/setup', auth, patch.setup2FA)
// router.post('/2fa/verify', auth, patch.verify2FA)
// router.post('/2fa/disable', auth, patch.disable2FA)
// router.get('/audit-log', auth, patch.getAuditLog)
