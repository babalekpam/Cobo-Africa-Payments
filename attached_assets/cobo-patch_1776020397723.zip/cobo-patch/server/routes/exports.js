// PATCH 7: CSV Export + Printable Receipt
// DROP INTO: server/routes/exports.js
// ADD TO server/index.js: app.use('/api/exports', require('./routes/exports'))
const router = require('express').Router()
const { auth } = require('../middleware/auth')
const db = require('../database')

router.get('/transactions.csv', auth, (req, res) => {
  let txs = db.get('transactions').filter({ user_id:req.user.id }).value()
  const{from,to,type,status}=req.query
  if(type) txs=txs.filter(t=>t.type===type)
  if(status) txs=txs.filter(t=>t.status===status)
  if(from) txs=txs.filter(t=>t.created_at>=from)
  if(to) txs=txs.filter(t=>t.created_at<=to+'T23:59:59')
  txs=txs.sort((a,b)=>new Date(b.created_at)-new Date(a.created_at))
  const cols=['Date','Reference','Type','Status','Amount','Currency','Fee','Net Amount','Description','Recipient','Channel']
  const rows=txs.map(t=>[new Date(t.created_at).toISOString().replace('T',' ').slice(0,19),t.reference||'',t.type||'',t.status||'',Number(t.amount||0).toFixed(2),t.currency||'',Number(t.fee||0).toFixed(2),Number(t.net_amount||t.amount||0).toFixed(2),`"${(t.description||'').replace(/"/g,'""')}"`,`"${(t.recipient_name||'').replace(/"/g,'""')}"`,t.channel||t.provider||''])
  const csv=[cols.join(','),...rows.map(r=>r.join(','))].join('\n')
  res.setHeader('Content-Type','text/csv')
  res.setHeader('Content-Disposition',`attachment; filename="cobo-transactions-${new Date().toISOString().slice(0,10)}.csv"`)
  res.send('\uFEFF'+csv)
})

router.get('/transactions.json', auth, (req, res) => {
  const txs=db.get('transactions').filter({user_id:req.user.id}).value().sort((a,b)=>new Date(b.created_at)-new Date(a.created_at))
  res.setHeader('Content-Disposition',`attachment; filename="cobo-transactions-${new Date().toISOString().slice(0,10)}.json"`)
  res.json({exported_at:new Date().toISOString(),account:req.user.email,count:txs.length,transactions:txs})
})

router.get('/receipt/:txId', auth, (req, res) => {
  const tx=db.get('transactions').find({id:req.params.txId,user_id:req.user.id}).value()
  if(!tx) return res.status(404).json({success:false,message:'Transaction not found'})
  const user=db.get('users').find({id:req.user.id}).value()
  const isIn=tx.type==='receive'||tx.type==='deposit'
  const html=`<!DOCTYPE html><html><head><meta charset="utf-8"><title>Receipt ${tx.reference||tx.id}</title>
<style>*{box-sizing:border-box;margin:0;padding:0}body{font-family:Georgia,serif;background:#f5f0e8;padding:40px 20px;color:#2a1a06}.card{background:#fff;border:2px solid #C8921A;border-radius:14px;padding:44px;max-width:520px;margin:0 auto}.logo{font-size:24px;font-weight:700;color:#C8921A;margin-bottom:4px}.sub{font-size:9px;color:#9a7030;letter-spacing:4px;margin-bottom:28px}.amount{font-size:44px;font-weight:700;color:${isIn?'#157a40':'#2a1a06'};letter-spacing:-2px;margin:16px 0 4px}.cur{font-size:15px;color:#9a7030;margin-bottom:8px}.badge{display:inline-block;padding:4px 14px;border-radius:99px;font-size:12px;font-weight:600;background:${tx.status==='success'?'#edf7f2':tx.status==='pending'?'#fef9ec':'#fef2f2'};color:${tx.status==='success'?'#157a40':tx.status==='pending'?'#C8921A':'#b02020'}}.row{display:flex;justify-content:space-between;padding:10px 0;border-bottom:1px solid #f5f0e8;font-size:14px;gap:16px}.lbl{color:#9a7030;flex-shrink:0}.val{text-align:right;font-weight:500;word-break:break-all}.footer{text-align:center;margin-top:28px;padding-top:18px;border-top:1px solid #f0e8d8;font-size:11px;color:#c8a860;line-height:2}@media print{body{background:#fff;padding:20px}}</style>
</head><body><div class="card">
<div class="logo">🌍 COBO</div><div class="sub">AFRICA PAYMENTS · OFFICIAL RECEIPT</div>
<div class="amount">${isIn?'+':'−'}${Number(tx.amount||0).toLocaleString('en-US',{minimumFractionDigits:2})}</div>
<div class="cur">${tx.currency} &nbsp;·&nbsp; <span class="badge">${tx.status}</span></div>
<div style="height:1px;background:#f0e8d8;margin:18px 0"></div>
<div class="row"><span class="lbl">Date</span><span class="val">${new Date(tx.created_at).toLocaleString('en-GB',{dateStyle:'full',timeStyle:'short'})}</span></div>
<div class="row"><span class="lbl">Transaction ID</span><span class="val" style="font-family:monospace;font-size:11px">${tx.id}</span></div>
<div class="row"><span class="lbl">Reference</span><span class="val" style="font-family:monospace;font-size:11px">${tx.reference||'—'}</span></div>
<div class="row"><span class="lbl">Type</span><span class="val">${tx.type}</span></div>
${tx.description?`<div class="row"><span class="lbl">Description</span><span class="val">${tx.description}</span></div>`:''}
${tx.recipient_name?`<div class="row"><span class="lbl">Recipient</span><span class="val">${tx.recipient_name}</span></div>`:''}
${tx.recipient_bank?`<div class="row"><span class="lbl">Bank</span><span class="val">${tx.recipient_bank}</span></div>`:''}
<div class="row"><span class="lbl">Fee</span><span class="val">${tx.currency} ${Number(tx.fee||0).toFixed(2)}</span></div>
<div class="row" style="border:none"><span class="lbl">Net amount</span><span class="val" style="color:#C8921A;font-size:16px">${tx.currency} ${Number(tx.net_amount||tx.amount||0).toLocaleString('en-US',{minimumFractionDigits:2})}</span></div>
<div class="footer">${user?.email||req.user.email}<br>${user?.business_name||(user?.first_name+' '+user?.last_name)}<br><strong>COBO Payment Platform · cobo.africa</strong><br>Generated: ${new Date().toLocaleString()}</div>
</div><script>window.addEventListener('load',()=>window.print())</script></body></html>`
  res.setHeader('Content-Type','text/html;charset=utf-8')
  res.send(html)
})

module.exports = router
