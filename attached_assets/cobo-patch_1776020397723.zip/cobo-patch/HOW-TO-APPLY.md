# COBO Patch Package — 10 Missing Features
Apply each patch individually. Zero existing files are deleted.

---

## What's in this package

| File | Patch # | Feature |
|------|---------|---------|
| `client/src/i18n/translations.js` | 1 | Multi-language EN/FR/PT/AR/SW |
| `client/src/pages/TwoFA.jsx` | 2 | 2FA setup UI |
| `client/src/pages/ForgotPassword.jsx` | 6 | Forgot password page |
| `client/src/pages/ResetPassword.jsx` | 6 | Reset password page |
| `server/routes/auth-patch.js` | 2+3+6+9 | 2FA routes, forgot/reset, KYC limits, audit log |
| `server/routes/exports.js` | 7 | CSV export + printable receipt |
| `server/services/email.js` | 5 | Email notifications (all templates) |
| `client/src/mobile.css` | 8 | Mobile responsiveness CSS |
| `client/public/terms.html` | 10 | Terms of Service |
| `client/public/privacy.html` | 10 | Privacy Policy |

---

## Step-by-step instructions

### PATCH 1 — Multi-language (EN/FR/PT/AR/SW)
1. Copy `client/src/i18n/translations.js` into your project
2. In `client/src/main.jsx`, wrap your app:
   ```jsx
   import { LangProvider } from './i18n/translations'
   // wrap <App /> with <LangProvider>
   ```
3. In any component, use:
   ```jsx
   import { useTranslation, LanguageSwitcher } from '../i18n/translations'
   const { t, lang, setLang } = useTranslation()
   // <p>{t('send_money')}</p>
   // <LanguageSwitcher /> — renders the language dropdown
   ```

### PATCH 2 — Two-Factor Authentication
1. Run: `npm install speakeasy qrcode`
2. Copy `client/src/pages/TwoFA.jsx` into your pages folder
3. Add route in `App.jsx`: `<Route path="/settings/2fa" element={<TwoFA />} />`
4. Add a link to it in your Settings page
5. Copy the routes from `server/routes/auth-patch.js` into your `server/routes/auth.js`:
   - `POST /auth/2fa/setup`
   - `POST /auth/2fa/verify`
   - `POST /auth/2fa/disable`
6. In your login route, add the 2FA check:
   ```js
   if (user.two_fa_enabled) {
     const { totp_code } = req.body
     if (!totp_code) return res.json({ success: false, requires_2fa: true })
     const speakeasy = require('speakeasy')
     const valid = speakeasy.totp.verify({ secret: user.two_fa_secret, encoding: 'base32', token: totp_code, window: 2 })
     if (!valid) return res.status(401).json({ success: false, message: 'Invalid 2FA code' })
   }
   ```

### PATCH 3 — Transaction Limits (KYC-enforced)
1. Copy the `checkKYCLimit()` function from `server/routes/auth-patch.js`
2. In each transfer route (bank, mobile-money, internal), add before processing:
   ```js
   const { checkKYCLimit } = require('./auth-patch')
   const user = db.get('users').find({ id: req.user.id }).value()
   const check = checkKYCLimit(user, amount)
   if (!check.allowed) return res.status(403).json({ success: false, message: check.message, code: check.code })
   ```

### PATCH 4 — Real Payment Gateway
Add to your `.env` file:
```
FLUTTERWAVE_SECRET_KEY=FLWSECK-your-live-key-here
FLUTTERWAVE_WEBHOOK_HASH=your-webhook-hash
STRIPE_SECRET_KEY=sk_live_your-key-here
```
Your existing code in `server/routes/transfers.js` already checks for
`process.env.FLUTTERWAVE_SECRET_KEY` and switches from sandbox to live automatically.

### PATCH 5 — Email Notifications
1. Run: `npm install nodemailer`
2. Replace/drop `server/services/email.js` from this package
3. Add to `.env`:
   ```
   SMTP_HOST=smtp.gmail.com
   SMTP_PORT=587
   SMTP_USER=your@gmail.com
   SMTP_PASS=your-app-password
   FROM_EMAIL=noreply@cobo.africa
   CLIENT_URL=https://your-domain.com
   ```
4. Call in your routes (non-blocking):
   ```js
   const emailSvc = require('../services/email')
   emailSvc.sendTransferSentEmail(user, { amount, currency, recipient, reference, fee }).catch(() => {})
   ```

### PATCH 6 — Forgot / Reset Password
1. Copy `client/src/pages/ForgotPassword.jsx` and `ResetPassword.jsx`
2. Add routes in `App.jsx`:
   ```jsx
   <Route path="/forgot-password" element={<ForgotPassword />} />
   <Route path="/reset-password" element={<ResetPassword />} />
   ```
3. Add a "Forgot password?" link to your Login page pointing to `/forgot-password`
4. Add the server routes from `auth-patch.js`:
   - `POST /api/auth/forgot-password`
   - `POST /api/auth/reset-password`
5. Add to your user schema:
   ```js
   password_reset_token: null,
   password_reset_expires: null,
   ```

### PATCH 7 — CSV Export + Printable Receipts
1. Copy `server/routes/exports.js`
2. Add to `server/index.js`:
   ```js
   app.use('/api/exports', require('./routes/exports'))
   ```
3. Link from your Transactions page:
   ```jsx
   // Export CSV
   window.open('/api/exports/transactions.csv', '_blank')
   // Print receipt
   window.open(`/api/exports/receipt/${tx.id}`, '_blank')
   ```

### PATCH 8 — Mobile Responsiveness
1. Copy `client/src/mobile.css`
2. Import at bottom of `client/src/index.css`:
   ```css
   @import './mobile.css';
   ```
   Or import in `main.jsx`:
   ```js
   import './mobile.css'
   ```

### PATCH 9 — Audit Logs
1. Copy the `addAuditLog()` function from `auth-patch.js`
2. Add the `audit_logs` collection to your database:
   ```js
   db.set('audit_logs', []).write()
   ```
3. Call throughout your routes:
   ```js
   addAuditLog(userId, 'login_success', req.ip, { browser: req.headers['user-agent'] })
   addAuditLog(userId, 'transfer_sent', req.ip, { amount, currency, reference })
   ```
4. `GET /api/auth/audit-log` endpoint is in `auth-patch.js`

### PATCH 10 — Terms & Privacy
1. Copy `client/public/terms.html` and `client/public/privacy.html`
2. They are accessible at `/terms` and `/privacy`
3. Link from your login/register page footer:
   ```jsx
   <a href="/terms">Terms of Service</a> · <a href="/privacy">Privacy Policy</a>
   ```

---

## npm packages needed
```bash
npm install speakeasy qrcode nodemailer
```

## .env additions needed
```
# Email (PATCH 5)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your@gmail.com
SMTP_PASS=your-app-password
FROM_EMAIL=noreply@cobo.africa
CLIENT_URL=https://your-domain.com

# Live payments (PATCH 4)
FLUTTERWAVE_SECRET_KEY=FLWSECK-...
FLUTTERWAVE_WEBHOOK_HASH=...
STRIPE_SECRET_KEY=sk_live_...
```
