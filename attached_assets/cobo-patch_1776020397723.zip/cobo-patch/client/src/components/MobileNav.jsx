// Feature 8: Mobile-first bottom navigation
// HOW TO INSTALL: Copy to client/src/components/MobileNav.jsx
// In Layout.jsx add: import MobileNav from './MobileNav'
// Then render: <MobileNav page={page} setPage={setPage} unread={unread} />

import { useEffect, useState } from 'react'

const TABS = [
  { id:'dashboard',    lb:'Home',    ic:'⬡' },
  { id:'wallets',      lb:'Wallets', ic:'◉' },
  { id:'send',         lb:'Send',    ic:'↑' },
  { id:'transactions', lb:'History', ic:'≡' },
  { id:'exchange',     lb:'Swap',    ic:'⇄' },
]

export default function MobileNav({ page, setPage, unread = 0 }) {
  const [visible, setVisible] = useState(true)
  const [lastY, setLastY] = useState(0)

  useEffect(() => {
    const el = document.querySelector('main')
    if (!el) return
    const fn = () => {
      const y = el.scrollTop
      setVisible(y < lastY || y < 60)
      setLastY(y)
    }
    el.addEventListener('scroll', fn, { passive: true })
    return () => el.removeEventListener('scroll', fn)
  }, [lastY])

  return (
    <>
      <nav className="mobile-bottom-nav" style={{
        display:'none', position:'fixed', bottom:0, left:0, right:0, zIndex:200,
        background:'var(--color-background-primary)',
        borderTop:'0.5px solid var(--color-border-tertiary)',
        padding:'6px 0 calc(6px + env(safe-area-inset-bottom))',
        transform: visible ? 'translateY(0)' : 'translateY(100%)',
        transition:'transform .2s ease',
      }}>
        {TABS.map(n => {
          const active = page === n.id
          return (
            <button key={n.id} onClick={() => setPage(n.id)} style={{
              flex:1, display:'flex', flexDirection:'column', alignItems:'center',
              gap:3, padding:'4px 0', border:'none', background:'none', cursor:'pointer',
              color: active ? '#C8921A' : 'var(--color-text-secondary)', position:'relative',
            }}>
              {active && <span style={{ position:'absolute', top:0, left:'50%', transform:'translateX(-50%)', width:20, height:2, background:'#C8921A', borderRadius:99 }} />}
              <span style={{ fontSize:19, lineHeight:1 }}>{n.ic}</span>
              <span style={{ fontSize:10, fontWeight: active ? 600 : 400 }}>{n.lb}</span>
              {n.id === 'notifications' && unread > 0 && (
                <span style={{ position:'absolute', top:2, right:'18%', width:7, height:7, background:'#b02020', borderRadius:'50%' }} />
              )}
            </button>
          )
        })}
      </nav>

      <style>{`
        @media (max-width: 768px) {
          .mobile-bottom-nav { display: flex !important; }
          aside { display: none !important; }
          main { margin-left: 0 !important; padding-bottom: 68px !important; }
          [style*="repeat(4,1fr)"] { grid-template-columns: repeat(2,1fr) !important; }
          [style*="repeat(3,minmax"] { grid-template-columns: repeat(2,1fr) !important; }
          [style*="1.3fr 1fr"],[style*="1.4fr 1fr"] { grid-template-columns: 1fr !important; }
          [style*="grid-template-columns: 1fr 1fr"] { grid-template-columns: 1fr !important; }
          table { display:block; overflow-x:auto; }
          button,input,select { min-height:44px; }
        }
        @media (max-width:480px){
          [style*="padding: 22px 24px"],[style*="padding:22px 24px"] { padding:14px 12px !important; }
        }
      `}</style>
    </>
  )
}
