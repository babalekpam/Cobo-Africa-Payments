// Feature 9: Activity / Audit Log page
// HOW TO INSTALL: Copy to client/src/pages/AuditLog.jsx
// Add to NAV array and App.jsx routes
import { useState, useEffect } from 'react'
import api from '../lib/api'

const ACTION_LABELS = {
  login_success:'Signed in', login_failed:'Failed login attempt',
  password_changed:'Password changed', password_reset_requested:'Password reset requested',
  password_reset_completed:'Password reset completed',
  '2fa_enabled':'2FA enabled', '2fa_disabled':'2FA disabled', '2fa_failed':'Failed 2FA attempt',
  transfer_bank:'Bank transfer initiated', transfer_mobile_money:'Mobile money transfer',
  account_created:'Account created',
}
const ACTION_TYPE = {
  login_failed:'error','2fa_failed':'error',
  login_success:'success','2fa_enabled':'success',account_created:'success',
}

export default function AuditLog() {
  const [logs, setLogs] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    api.get('/auth/audit-log').then(r => { setLogs(r.data.logs || []); setLoading(false) }).catch(() => setLoading(false))
  }, [])

  const color = t => ({ success:'#157a40', error:'#b02020', warning:'#C8921A' })[t] || 'var(--color-text-secondary)'
  const bg    = t => ({ success:'rgba(21,122,64,.08)', error:'rgba(176,32,32,.08)', warning:'rgba(200,146,26,.08)' })[t] || 'var(--color-background-secondary)'
  const icon  = a => ({ login_success:'✅', login_failed:'❌', password_changed:'🔑', '2fa_enabled':'🔐', '2fa_failed':'⚠️', transfer_bank:'↑', transfer_mobile_money:'📱', account_created:'🌍' })[a] || '•'

  return (
    <div style={{ padding:'22px 24px', maxWidth:700 }}>
      <h2 style={{ margin:'0 0 6px', fontSize:20, fontWeight:500 }}>Activity Log</h2>
      <p style={{ color:'var(--color-text-secondary)', fontSize:13, marginBottom:20 }}>Recent account activity, logins, and security events</p>

      {loading && <div style={{ textAlign:'center', padding:'40px', color:'var(--color-text-secondary)' }}>Loading...</div>}
      {!loading && logs.length === 0 && <div style={{ textAlign:'center', padding:'40px', color:'var(--color-text-secondary)' }}>No activity recorded yet</div>}

      <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
        {logs.map(log => {
          const type = ACTION_TYPE[log.action]
          const label = ACTION_LABELS[log.action] || log.action
          return (
            <div key={log.id} style={{ background:'var(--color-background-primary)', border:'0.5px solid var(--color-border-tertiary)', borderRadius:10, padding:'12px 16px', display:'flex', alignItems:'center', gap:14 }}>
              <div style={{ width:36, height:36, borderRadius:'50%', background:bg(type), display:'flex', alignItems:'center', justifyContent:'center', fontSize:16, flexShrink:0 }}>
                {icon(log.action)}
              </div>
              <div style={{ flex:1 }}>
                <div style={{ fontWeight:500, fontSize:13, color: type ? color(type) : 'var(--color-text-primary)' }}>{label}</div>
                <div style={{ fontSize:11, color:'var(--color-text-tertiary)', marginTop:2 }}>
                  {new Date(log.created_at).toLocaleString('en-GB', { dateStyle:'medium', timeStyle:'short' })}
                  {log.ip && log.ip !== 'unknown' && ` · IP: ${log.ip}`}
                </div>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
