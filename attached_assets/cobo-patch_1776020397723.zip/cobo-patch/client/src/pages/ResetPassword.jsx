// Feature 6: Reset Password page
// HOW TO INSTALL: Copy to client/src/pages/ResetPassword.jsx
// Add route in App.jsx: <Route path="/reset-password" element={<ResetPassword />} />
import { useState } from 'react'
import api from '../lib/api'
export default function ResetPassword() {
  const token = new URLSearchParams(window.location.search).get('token') || ''
  const [pw, setPw] = useState('')
  const [pw2, setPw2] = useState('')
  const [done, setDone] = useState(false)
  const [err, setErr] = useState('')
  const [loading, setLoading] = useState(false)
  const submit = async e => {
    e.preventDefault(); setErr('')
    if (pw !== pw2) { setErr('Passwords do not match'); return }
    if (pw.length < 8) { setErr('Password must be at least 8 characters'); return }
    setLoading(true)
    try { await api.post('/auth/reset-password', { token, new_password: pw }); setDone(true) }
    catch (e2) { setErr(e2.response?.data?.message || 'Reset failed. Link may have expired.') }
    setLoading(false)
  }
  const S = { minHeight:'100vh', display:'flex', alignItems:'center', justifyContent:'center', background:'var(--color-background-tertiary)', padding:20 }
  const C = { background:'var(--color-background-primary)', border:'0.5px solid var(--color-border-tertiary)', borderRadius:14, padding:'32px 28px', width:'100%', maxWidth:400 }
  const I = { width:'100%', padding:'10px 14px', background:'var(--color-background-secondary)', border:'0.5px solid var(--color-border-tertiary)', borderRadius:8, fontSize:14, outline:'none', color:'var(--color-text-primary)' }
  const B = { width:'100%', padding:'12px', background:'#C8921A', color:'#fff', border:'none', borderRadius:8, fontSize:14, fontWeight:600, cursor:'pointer', marginTop:8 }
  return (
    <div style={S}>
      <div>
        <div style={{ textAlign:'center', marginBottom:20, fontFamily:'Georgia,serif', fontSize:22, fontWeight:700, color:'#C8921A' }}>🌍 COBO</div>
        <div style={C}>
          {done ? (
            <>
              <div style={{ fontSize:36, textAlign:'center', marginBottom:12 }}>✅</div>
              <h3 style={{ fontWeight:500, fontSize:18, marginBottom:10, textAlign:'center' }}>Password reset!</h3>
              <p style={{ color:'var(--color-text-secondary)', fontSize:13, textAlign:'center', marginBottom:16 }}>You can now log in with your new password.</p>
              <a href="/login" style={{ display:'block', textAlign:'center', padding:'12px', background:'#C8921A', color:'#fff', textDecoration:'none', borderRadius:8, fontWeight:600 }}>Sign In →</a>
            </>
          ) : (
            <>
              <h3 style={{ fontWeight:500, fontSize:18, marginBottom:20 }}>Set new password</h3>
              {err && <div style={{ background:'rgba(176,32,32,.08)', border:'1px solid rgba(176,32,32,.3)', borderRadius:8, padding:'9px 13px', fontSize:13, color:'#b02020', marginBottom:14 }}>{err}</div>}
              <form onSubmit={submit} style={{ display:'flex', flexDirection:'column', gap:12 }}>
                <div><label style={{ fontSize:12, color:'var(--color-text-secondary)', display:'block', marginBottom:5 }}>New password</label>
                  <input style={I} type="password" value={pw} onChange={e=>setPw(e.target.value)} placeholder="At least 8 characters" required /></div>
                <div><label style={{ fontSize:12, color:'var(--color-text-secondary)', display:'block', marginBottom:5 }}>Confirm password</label>
                  <input style={I} type="password" value={pw2} onChange={e=>setPw2(e.target.value)} placeholder="Repeat password" required /></div>
                <button style={B} disabled={loading || !token}>{loading ? 'Resetting...' : 'Reset Password'}</button>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
