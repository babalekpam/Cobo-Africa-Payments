// Feature 6: Forgot Password page
// HOW TO INSTALL: Copy to client/src/pages/ForgotPassword.jsx
// Add route in App.jsx: <Route path="/forgot-password" element={<ForgotPassword />} />
import { useState } from 'react'
import api from '../lib/api'
export default function ForgotPassword() {
  const [email, setEmail] = useState('')
  const [sent, setSent] = useState(false)
  const [loading, setLoading] = useState(false)
  const submit = async e => {
    e.preventDefault(); setLoading(true)
    try { await api.post('/auth/forgot-password', { email }); setSent(true) } catch { setSent(true) }
    setLoading(false)
  }
  const S = { minHeight:'100vh', display:'flex', alignItems:'center', justifyContent:'center', background:'var(--color-background-tertiary)', padding:20 }
  const C = { background:'var(--color-background-primary)', border:'0.5px solid var(--color-border-tertiary)', borderRadius:14, padding:'32px 28px', width:'100%', maxWidth:400 }
  const I = { width:'100%', padding:'10px 14px', background:'var(--color-background-secondary)', border:'0.5px solid var(--color-border-tertiary)', borderRadius:8, fontSize:14, outline:'none', color:'var(--color-text-primary)' }
  const B = { width:'100%', padding:'12px', background:'#C8921A', color:'#fff', border:'none', borderRadius:8, fontSize:14, fontWeight:600, cursor:'pointer', marginTop:8 }
  return (
    <div style={S}>
      <div>
        <div style={{ textAlign:'center', marginBottom:20, fontFamily:'Georgia,serif', fontSize:22, fontWeight:700, color:'#C8921A' }}>🌍 COBO</div>
        <div style={C}>
          {sent ? (
            <>
              <div style={{ fontSize:36, textAlign:'center', marginBottom:12 }}>📧</div>
              <h3 style={{ fontWeight:500, fontSize:18, marginBottom:10, textAlign:'center' }}>Check your email</h3>
              <p style={{ color:'var(--color-text-secondary)', fontSize:13, textAlign:'center' }}>If that email is registered, a reset link has been sent. Check your inbox (and spam folder).</p>
            </>
          ) : (
            <>
              <h3 style={{ fontWeight:500, fontSize:18, marginBottom:6 }}>Reset your password</h3>
              <p style={{ color:'var(--color-text-secondary)', fontSize:13, marginBottom:20 }}>Enter your email and we'll send you a reset link.</p>
              <form onSubmit={submit} style={{ display:'flex', flexDirection:'column', gap:12 }}>
                <div><label style={{ fontSize:12, color:'var(--color-text-secondary)', display:'block', marginBottom:5 }}>Email address</label>
                  <input style={I} type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com" required /></div>
                <button style={B} disabled={loading}>{loading ? 'Sending...' : 'Send Reset Link'}</button>
              </form>
            </>
          )}
          <div style={{ textAlign:'center', marginTop:18, fontSize:13, color:'var(--color-text-secondary)' }}>
            <a href="/login" style={{ color:'#C8921A', textDecoration:'none' }}>← Back to login</a>
          </div>
        </div>
      </div>
    </div>
  )
}
