// PATCH 2: Two-Factor Authentication
// DROP INTO: client/src/pages/TwoFA.jsx
import { useState } from 'react'
import api from '../lib/api'
import toast from 'react-hot-toast'
const G='#C8921A'
const inp={width:'100%',padding:'10px 12px',background:'var(--color-background-secondary)',border:'0.5px solid var(--color-border-tertiary)',borderRadius:8,color:'var(--color-text-primary)',fontSize:14,outline:'none',boxSizing:'border-box'}
const card={background:'var(--color-background-primary)',border:'0.5px solid var(--color-border-tertiary)',borderRadius:12,padding:'24px'}
export default function TwoFA() {
  const[step,setStep]=useState('intro')
  const[qr,setQr]=useState('')
  const[secret,setSecret]=useState('')
  const[code,setCode]=useState('')
  const[pw,setPw]=useState('')
  const[loading,setLoading]=useState(false)
  const start=async()=>{setLoading(true);try{const r=await api.post('/auth/2fa/setup');setQr(r.data.qr_code);setSecret(r.data.secret);setStep('setup')}catch(e){toast.error(e.response?.data?.message||'Setup failed')}setLoading(false)}
  const verify=async()=>{if(code.length!==6){toast.error('Enter 6-digit code');return}setLoading(true);try{await api.post('/auth/2fa/verify',{totp_code:code});setStep('done');toast.success('2FA enabled!')}catch(e){toast.error(e.response?.data?.message||'Invalid code')}setLoading(false)}
  const disable=async()=>{if(!pw){toast.error('Enter your password');return}setLoading(true);try{await api.post('/auth/2fa/disable',{password:pw});setStep('intro');setPw('');toast.success('2FA disabled')}catch(e){toast.error(e.response?.data?.message||'Failed')}setLoading(false)}
  return (
    <div style={{padding:'22px 24px',maxWidth:520}}>
      <h2 style={{margin:'0 0 4px',fontSize:20,fontWeight:500}}>Two-Factor Authentication</h2>
      <p style={{fontSize:13,color:'var(--color-text-secondary)',marginBottom:24}}>Add an extra layer of security to your COBO account</p>
      {step==='intro'&&<div style={card}>
        <div style={{fontSize:48,marginBottom:16}}>🔐</div>
        <h3 style={{fontWeight:500,fontSize:16,marginBottom:8}}>Authenticator App 2FA</h3>
        <p style={{fontSize:13,color:'var(--color-text-secondary)',marginBottom:20,lineHeight:1.6}}>Use Google Authenticator, Authy, or any TOTP app. Works offline — no SMS required.</p>
        {['🛡️ Protects against password theft','📱 Works on any smartphone','⚡ Instant verification','🌍 Works anywhere in Africa'].map(f=><div key={f} style={{fontSize:13,color:'var(--color-text-secondary)',marginBottom:6}}>{f}</div>)}
        <button onClick={start} disabled={loading} style={{marginTop:20,width:'100%',padding:'11px',background:G,border:'none',borderRadius:8,color:'#fff',fontWeight:500,fontSize:14,cursor:'pointer'}}>{loading?'Setting up...':'Enable 2FA →'}</button>
      </div>}
      {step==='setup'&&<div style={card}>
        <div style={{fontWeight:500,fontSize:15,marginBottom:12}}>Step 1 — Scan QR code</div>
        <p style={{fontSize:13,color:'var(--color-text-secondary)',marginBottom:14}}>Open Google Authenticator or Authy and scan:</p>
        {qr&&<div style={{textAlign:'center',marginBottom:14}}><img src={qr} alt="QR" style={{width:200,height:200,border:'4px solid '+G,borderRadius:12}}/></div>}
        <div style={{background:'var(--color-background-secondary)',borderRadius:8,padding:'10px 14px',marginBottom:20}}>
          <div style={{fontSize:11,color:'var(--color-text-secondary)',marginBottom:4}}>Manual entry key:</div>
          <div style={{fontFamily:'monospace',fontSize:12,letterSpacing:2,color:G,wordBreak:'break-all'}}>{secret}</div>
        </div>
        <div style={{fontWeight:500,fontSize:15,marginBottom:10}}>Step 2 — Enter the 6-digit code</div>
        <input type="text" inputMode="numeric" maxLength={6} placeholder="000000" value={code} onChange={e=>setCode(e.target.value.replace(/\D/g,''))} style={{...inp,textAlign:'center',fontSize:28,letterSpacing:10,marginBottom:14,fontFamily:'monospace'}}/>
        <div style={{display:'flex',gap:10}}>
          <button onClick={()=>setStep('intro')} style={{flex:1,padding:'10px',background:'var(--color-background-secondary)',border:'0.5px solid var(--color-border-tertiary)',borderRadius:8,cursor:'pointer',color:'var(--color-text-secondary)',fontWeight:500}}>Back</button>
          <button onClick={verify} disabled={loading||code.length!==6} style={{flex:2,padding:'10px',background:G,border:'none',borderRadius:8,color:'#fff',fontWeight:500,cursor:'pointer',opacity:code.length!==6?.5:1}}>{loading?'Verifying...':'Verify & Enable →'}</button>
        </div>
      </div>}
      {step==='done'&&<div style={card}>
        <div style={{textAlign:'center',marginBottom:20}}>
          <div style={{fontSize:56,marginBottom:12}}>✅</div>
          <h3 style={{fontWeight:500,fontSize:18,marginBottom:8}}>2FA Enabled!</h3>
          <p style={{fontSize:13,color:'var(--color-text-secondary)'}}>Your account is now protected. You'll need your authenticator app each login.</p>
        </div>
        <div style={{height:'0.5px',background:'var(--color-border-tertiary)',margin:'20px 0'}}/>
        <div style={{fontWeight:500,fontSize:13,marginBottom:10,color:'var(--color-text-secondary)'}}>Disable 2FA</div>
        <input type="password" placeholder="Enter your password to disable" value={pw} onChange={e=>setPw(e.target.value)} style={{...inp,marginBottom:10}}/>
        <button onClick={disable} disabled={loading||!pw} style={{width:'100%',padding:'10px',background:'rgba(176,32,32,.08)',border:'0.5px solid #b02020',borderRadius:8,color:'#b02020',fontWeight:500,cursor:'pointer',opacity:!pw?.5:1}}>{loading?'Disabling...':'Disable 2FA'}</button>
      </div>}
    </div>
  )
}
