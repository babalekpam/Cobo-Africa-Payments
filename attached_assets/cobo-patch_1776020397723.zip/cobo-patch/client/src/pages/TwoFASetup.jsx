// Feature 2: 2FA Setup page — add to Settings
// HOW TO INSTALL: Import this component into Settings.jsx
// import TwoFASetup from './TwoFASetup'  → render inside Settings card
import { useState } from 'react'
import api from '../lib/api'

export default function TwoFASetup({ user, toast }) {
  const [step, setStep] = useState('idle') // idle | setup | verify | done
  const [qr, setQr] = useState(null)
  const [secret, setSecret] = useState('')
  const [code, setCode] = useState('')
  const [disablePw, setDisablePw] = useState('')
  const [loading, setLoading] = useState(false)
  const enabled = user?.two_fa_enabled

  const startSetup = async () => {
    setLoading(true)
    try {
      const r = await api.post('/auth/2fa/setup')
      setQr(r.data.qr_code); setSecret(r.data.secret); setStep('setup')
    } catch (e) { toast(e.response?.data?.message || 'Failed', 'error') }
    setLoading(false)
  }

  const verify = async () => {
    if (!code || code.length !== 6) { toast('Enter 6-digit code', 'error'); return }
    setLoading(true)
    try {
      await api.post('/auth/2fa/verify', { totp_code: code })
      toast('2FA enabled successfully! ✅'); setStep('done')
    } catch (e) { toast(e.response?.data?.message || 'Invalid code', 'error') }
    setLoading(false)
  }

  const disable = async () => {
    if (!disablePw) { toast('Enter your password', 'error'); return }
    setLoading(true)
    try {
      await api.post('/auth/2fa/disable', { password: disablePw })
      toast('2FA disabled'); setStep('idle'); setDisablePw('')
    } catch (e) { toast(e.response?.data?.message || 'Failed', 'error') }
    setLoading(false)
  }

  const inp = { padding:'10px 14px', background:'var(--color-background-secondary)', border:'0.5px solid var(--color-border-tertiary)', borderRadius:8, fontSize:14, outline:'none', color:'var(--color-text-primary)', width:'100%' }
  const btn = (color='#C8921A') => ({ padding:'10px 20px', background:color, color:'#fff', border:'none', borderRadius:8, fontSize:13, fontWeight:600, cursor:'pointer' })

  if (enabled && step !== 'done') return (
    <div style={{ background:'rgba(21,122,64,.06)', border:'0.5px solid rgba(21,122,64,.2)', borderRadius:10, padding:'16px 18px' }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:14 }}>
        <div>
          <div style={{ fontWeight:500, fontSize:14, color:'#157a40' }}>✅ 2FA is enabled</div>
          <div style={{ fontSize:12, color:'var(--color-text-secondary)', marginTop:3 }}>Your account is protected with an authenticator app</div>
        </div>
      </div>
      {step !== 'disabling' ? (
        <button onClick={() => setStep('disabling')} style={{ ...btn('#b02020'), fontSize:12, padding:'7px 14px' }}>Disable 2FA</button>
      ) : (
        <div style={{ display:'flex', flexDirection:'column', gap:10, marginTop:8 }}>
          <div style={{ fontSize:12, color:'var(--color-text-secondary)' }}>Confirm your password to disable 2FA:</div>
          <input type="password" placeholder="Your password" value={disablePw} onChange={e=>setDisablePw(e.target.value)} style={inp} />
          <div style={{ display:'flex', gap:8 }}>
            <button onClick={disable} disabled={loading} style={btn('#b02020')}>{loading?'...':'Disable 2FA'}</button>
            <button onClick={()=>setStep('idle')} style={btn('var(--color-background-secondary)')}>Cancel</button>
          </div>
        </div>
      )}
    </div>
  )

  if (step === 'idle' || step === 'done') return (
    <div style={{ background:'var(--color-background-secondary)', borderRadius:10, padding:'16px 18px', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
      <div>
        <div style={{ fontWeight:500, fontSize:14 }}>Two-Factor Authentication</div>
        <div style={{ fontSize:12, color:'var(--color-text-secondary)', marginTop:3 }}>Add an extra layer of security to your account</div>
      </div>
      <button onClick={startSetup} disabled={loading} style={btn()}>{loading?'...':'Enable 2FA'}</button>
    </div>
  )

  if (step === 'setup') return (
    <div style={{ border:'0.5px solid var(--color-border-tertiary)', borderRadius:10, padding:'18px' }}>
      <div style={{ fontWeight:500, fontSize:14, marginBottom:14 }}>Set up authenticator app</div>
      <div style={{ display:'flex', gap:16, alignItems:'flex-start', flexWrap:'wrap' }}>
        {qr && <img src={qr} alt="QR Code" style={{ width:140, height:140, borderRadius:8, border:'0.5px solid var(--color-border-tertiary)' }} />}
        <div style={{ flex:1, minWidth:200 }}>
          <div style={{ fontSize:12, color:'var(--color-text-secondary)', marginBottom:8 }}>1. Open <strong>Google Authenticator</strong> or <strong>Authy</strong></div>
          <div style={{ fontSize:12, color:'var(--color-text-secondary)', marginBottom:8 }}>2. Tap "+" and scan the QR code</div>
          <div style={{ fontSize:12, color:'var(--color-text-secondary)', marginBottom:12 }}>3. Or enter this key manually:</div>
          <div style={{ fontFamily:'monospace', fontSize:11, background:'var(--color-background-secondary)', padding:'8px 10px', borderRadius:6, wordBreak:'break-all', marginBottom:14, color:'#C8921A' }}>{secret}</div>
          <input type="text" inputMode="numeric" maxLength={6} placeholder="Enter 6-digit code" value={code} onChange={e=>setCode(e.target.value.replace(/\D/g,''))} style={{...inp, marginBottom:10, letterSpacing:6, textAlign:'center', fontSize:20}} />
          <button onClick={verify} disabled={loading || code.length !== 6} style={{...btn(), width:'100%'}}>{loading ? 'Verifying...' : 'Activate 2FA'}</button>
        </div>
      </div>
    </div>
  )
}
