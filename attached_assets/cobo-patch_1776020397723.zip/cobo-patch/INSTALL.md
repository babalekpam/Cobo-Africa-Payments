# COBO — 10 Feature Patch
## Installation Guide

Drop each file into your existing COBO app, then `npm install` the new deps.

---

## New npm packages required
```bash
npm install speakeasy qrcode nodemailer
```

---

## File map — where each file goes

```
PATCH FILE                                    → DESTINATION IN YOUR APP
─────────────────────────────────────────────────────────────────────
server/services/email.js                      → server/services/email.js
server/routes/auth-patch.js                   → MERGE into server/routes/auth.js (see below)
server/routes/transfers-patch.js              → server/routes/transfers.js  (replace)
server/routes/exports.js                      → server/routes/exports.js    (new file)
client/src/i18n/translations.js               → client/src/i18n/translations.js
client/src/pages/ForgotPassword.jsx           → client/src/pages/ForgotPassword.jsx
client/src/pages/ResetPassword.jsx            → client/src/pages/ResetPassword.jsx
client/src/pages/TwoFASetup.jsx               → client/src/pages/TwoFASetup.jsx
client/src/pages/AuditLog.jsx                 → client/src/pages/AuditLog.jsx
client/src/components/MobileNav.jsx           → client/src/components/MobileNav.jsx
client/public/terms.html                      → client/public/terms.html
client/public/privacy.html                    → client/public/privacy.html
```

---

## Step 1 — Merge auth-patch.js into your auth.js

Add these routes to the END of `server/routes/auth.js` (before `module.exports`):
- Copy all `router.post('/2fa/...')` routes
- Copy `router.post('/forgot-password')`
- Copy `router.post('/reset-password')`  
- Copy `router.get('/audit-log')`
- Copy the `auditLog()` helper function
- Copy `module.exports.KYC_LIMITS = KYC_LIMITS`

---

## Step 2 — Wire exports route in server/index.js

Add this line:
```js
app.use('/api/exports', require('./routes/exports'))
```

Add Terms/Privacy static routes:
```js
const path = require('path')
app.get('/terms',   (req, res) => res.sendFile(path.join(__dirname, '../client/public/terms.html')))
app.get('/privacy', (req, res) => res.sendFile(path.join(__dirname, '../client/public/privacy.html')))
```

---

## Step 3 — Wire new pages in client/src/App.jsx

```jsx
import ForgotPassword from './pages/ForgotPassword'
import ResetPassword  from './pages/ResetPassword'
import AuditLog       from './pages/AuditLog'

// Add these routes:
<Route path="/forgot-password" element={<ForgotPassword />} />
<Route path="/reset-password"  element={<ResetPassword />} />
// Add /audit-log to your authenticated routes
```

---

## Step 4 — Add MobileNav to Layout.jsx

```jsx
import MobileNav from './MobileNav'
// Inside the Layout return, after <Outlet />:
<MobileNav page={page} setPage={setPage} unread={unread} />
```

---

## Step 5 — Add TwoFASetup to Settings.jsx

```jsx
import TwoFASetup from './TwoFASetup'
// Inside Settings, in the Security card:
<TwoFASetup user={user} toast={toast} />
```

---

## Step 6 — Add language switcher

```jsx
import { LANGUAGES, useLang, useTranslation } from '../i18n/translations'
// In any component:
const { lang, setLang } = useLang()
const t = useTranslation(lang)
// Use: t('send_money') → "Send Money" or "Envoyer de l'argent" etc.

// Language switcher UI:
<select value={lang} onChange={e => setLang(e.target.value)}>
  {Object.entries(LANGUAGES).map(([code, info]) => (
    <option key={code} value={code}>{info.flag} {info.label}</option>
  ))}
</select>
```

---

## Step 7 — Add to .env.example

```bash
# Email (Feature 5)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your@gmail.com
SMTP_PASS=your-app-password
FROM_EMAIL=noreply@cobo.africa
CLIENT_URL=https://your-domain.com

# Flutterwave live mode (Feature 4)
FLUTTERWAVE_SECRET_KEY=FLWSECK-your-key-here
FLUTTERWAVE_WEBHOOK_HASH=your-webhook-hash
```

---

## Step 8 — Add audit_logs to database

In your `server/database.js` init, add:
```js
if (!db.has('audit_logs').value()) db.set('audit_logs', []).write()
```

---

## Feature summary

| # | Feature                    | Files changed                              |
|---|----------------------------|--------------------------------------------|
| 1 | Multi-language EN/FR/PT/AR/SW | translations.js                          |
| 2 | 2FA (TOTP)                 | auth-patch.js + TwoFASetup.jsx             |
| 3 | KYC transaction limits     | transfers-patch.js                         |
| 4 | Real Flutterwave payments  | transfers-patch.js                         |
| 5 | Email notifications        | email.js                                   |
| 6 | Forgot/reset password      | auth-patch.js + ForgotPassword/Reset.jsx   |
| 7 | CSV export + receipts      | exports.js                                 |
| 8 | Mobile responsiveness      | MobileNav.jsx                              |
| 9 | Activity/audit log         | auth-patch.js + AuditLog.jsx               |
|10 | Terms + Privacy Policy     | terms.html + privacy.html                  |
