const jwt = require('jsonwebtoken')
const bcrypt = require('bcryptjs')
const db = require('../database')

const SECRET = process.env.JWT_SECRET || 'cobo_dev_secret_change_in_production'

const auth = (req, res, next) => {
  try {
    const apiKey = req.headers['x-api-key']
    const authHeader = req.headers.authorization

    if (apiKey) {
      const keys = db.get('api_keys').filter({ is_active: true }).value()
      const matched = keys.find(k => bcrypt.compareSync(apiKey, k.key_hash))
      if (!matched) return res.status(401).json({ success: false, message: 'Invalid API key' })
      const user = db.get('users').find({ id: matched.user_id, is_active: true }).value()
      if (!user) return res.status(401).json({ success: false, message: 'User not found' })
      db.get('api_keys').find({ id: matched.id }).assign({ last_used_at: new Date().toISOString() }).write()
      req.user = user
      req.isApiKey = true
      return next()
    }

    if (!authHeader?.startsWith('Bearer '))
      return res.status(401).json({ success: false, message: 'No token provided' })

    const token = authHeader.split(' ')[1]
    const decoded = jwt.verify(token, SECRET)
    const user = db.get('users').find({ id: decoded.id, is_active: true }).value()
    if (!user) return res.status(401).json({ success: false, message: 'User not found' })

    req.user = user
    next()
  } catch {
    return res.status(401).json({ success: false, message: 'Invalid or expired token' })
  }
}

const adminAuth = (req, res, next) => {
  auth(req, res, () => {
    if (req.user.role !== 'admin')
      return res.status(403).json({ success: false, message: 'Admin access required' })
    next()
  })
}

const signToken = (user) => jwt.sign(
  { id: user.id, email: user.email },
  SECRET,
  { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
)

module.exports = { auth, adminAuth, signToken }
