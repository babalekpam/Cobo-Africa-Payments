/**
 * COBO Flutterwave Service
 * Handles live payments when FLUTTERWAVE_SECRET_KEY is configured
 * Falls back to sandbox simulation when not configured
 */
const axios = require('axios')

const FW_BASE = 'https://api.flutterwave.com/v3'
const SECRET = () => process.env.FLUTTERWAVE_SECRET_KEY

function isConfigured() {
  return !!SECRET() && !SECRET().includes('your_')
}

function fwClient() {
  return axios.create({
    baseURL: FW_BASE,
    headers: { Authorization: `Bearer ${SECRET()}` },
    timeout: 10000,
  })
}

/**
 * Initiate bank transfer via Flutterwave
 */
async function initiateTransfer({ account_bank, account_number, amount, currency, narration, reference, callback_url }) {
  if (!isConfigured()) {
    return { sandbox: true, status: 'pending', id: 'SBX-' + Date.now() }
  }
  const res = await fwClient().post('/transfers', {
    account_bank, account_number, amount, currency,
    narration: narration || 'COBO Transfer',
    reference, debit_currency: currency,
    callback_url,
  })
  if (res.data.status !== 'success') throw new Error(res.data.message || 'Transfer failed')
  return res.data.data
}

/**
 * Verify a charge/collection
 */
async function verifyTransaction(transaction_id) {
  if (!isConfigured()) return { status: 'successful', amount: 0 }
  const res = await fwClient().get(`/transactions/${transaction_id}/verify`)
  return res.data.data
}

/**
 * Get list of banks for a country
 */
async function getBanks(country) {
  if (!isConfigured()) return []
  const res = await fwClient().get(`/banks/${country}`)
  return res.data.data || []
}

/**
 * Resolve account name from account number + bank code
 */
async function resolveAccount(account_number, account_bank) {
  if (!isConfigured()) return { account_name: 'Account holder', sandbox: true }
  const res = await fwClient().post('/accounts/resolve', { account_number, account_bank })
  return res.data.data
}

/**
 * Initiate mobile money transfer
 */
async function initiateMobileMoneyTransfer({ phone_number, amount, currency, narration, reference, provider }) {
  if (!isConfigured()) {
    return { sandbox: true, status: 'pending', id: 'SBX-MM-' + Date.now() }
  }
  const res = await fwClient().post('/transfers', {
    account_bank: provider, account_number: phone_number,
    amount, currency, narration: narration || 'COBO Mobile Transfer',
    reference,
  })
  if (res.data.status !== 'success') throw new Error(res.data.message || 'Transfer failed')
  return res.data.data
}

/**
 * Validate Flutterwave webhook signature
 */
function validateWebhook(req) {
  const hash = req.headers['verif-hash']
  return hash === process.env.FLUTTERWAVE_WEBHOOK_HASH
}

module.exports = {
  isConfigured,
  initiateTransfer,
  verifyTransaction,
  getBanks,
  resolveAccount,
  initiateMobileMoneyTransfer,
  validateWebhook,
}
