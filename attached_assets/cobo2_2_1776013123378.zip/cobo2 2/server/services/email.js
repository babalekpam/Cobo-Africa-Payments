/**
 * COBO Email Service
 * Uses nodemailer when SMTP configured, falls back to console log in dev
 */

let transporter = null

async function getTransporter() {
  if (transporter) return transporter
  if (!process.env.SMTP_HOST || !process.env.SMTP_USER) return null
  const nodemailer = require('nodemailer')
  transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: parseInt(process.env.SMTP_PORT || '587'),
    secure: process.env.SMTP_PORT === '465',
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
  })
  return transporter
}

async function sendEmail({ to, subject, html, text }) {
  const transport = await getTransporter()
  if (!transport) {
    if (process.env.NODE_ENV !== 'production') {
      console.log(`[EMAIL] To: ${to} | Subject: ${subject}`)
    }
    return { ok: false, reason: 'no_smtp' }
  }
  try {
    await transport.sendMail({
      from: process.env.FROM_EMAIL || 'noreply@cobo.africa',
      to, subject, html, text
    })
    return { ok: true }
  } catch (err) {
    console.error('[EMAIL ERROR]', err.message)
    return { ok: false, error: err.message }
  }
}

const TEMPLATES = {
  transferSent: ({ name, amount, currency, recipient, reference }) => ({
    subject: `Transfer of ${currency} ${amount} initiated — COBO`,
    html: `
      <div style="font-family:sans-serif;max-width:560px;margin:0 auto;padding:32px 24px">
        <div style="font-size:24px;font-weight:800;color:#C9880F;margin-bottom:24px">🌍 COBO</div>
        <h2 style="font-size:20px;margin-bottom:8px">Transfer Initiated</h2>
        <p style="color:#666;margin-bottom:24px">Hi ${name}, your transfer is being processed.</p>
        <div style="background:#f8f6f0;border-radius:12px;padding:20px 24px;margin-bottom:24px">
          <div style="display:flex;justify-content:space-between;margin-bottom:8px"><span style="color:#888">Amount</span><strong>${currency} ${amount}</strong></div>
          <div style="display:flex;justify-content:space-between;margin-bottom:8px"><span style="color:#888">Recipient</span><strong>${recipient}</strong></div>
          <div style="display:flex;justify-content:space-between"><span style="color:#888">Reference</span><code style="font-size:12px">${reference}</code></div>
        </div>
        <p style="color:#888;font-size:13px">Funds typically arrive within minutes for mobile money and 1-3 business days for bank transfers.</p>
      </div>
    `
  }),

  transferReceived: ({ name, amount, currency, sender, reference }) => ({
    subject: `You received ${currency} ${amount} — COBO`,
    html: `
      <div style="font-family:sans-serif;max-width:560px;margin:0 auto;padding:32px 24px">
        <div style="font-size:24px;font-weight:800;color:#C9880F;margin-bottom:24px">🌍 COBO</div>
        <h2 style="font-size:20px;margin-bottom:8px">💰 Money Received!</h2>
        <p style="color:#666;margin-bottom:24px">Hi ${name}, you received a payment on COBO.</p>
        <div style="background:#f0faf5;border:1px solid #b2dfc8;border-radius:12px;padding:20px 24px;margin-bottom:24px">
          <div style="font-size:32px;font-weight:800;color:#157a40;margin-bottom:4px">${currency} ${amount}</div>
          <div style="color:#888;font-size:14px">from ${sender}</div>
        </div>
        <p style="color:#888;font-size:13px">Reference: <code>${reference}</code></p>
      </div>
    `
  }),

  welcome: ({ name, email }) => ({
    subject: 'Welcome to COBO — Africa\'s Unified Payments',
    html: `
      <div style="font-family:sans-serif;max-width:560px;margin:0 auto;padding:32px 24px">
        <div style="font-size:24px;font-weight:800;color:#C9880F;margin-bottom:24px">🌍 COBO</div>
        <h2 style="font-size:20px;margin-bottom:8px">Welcome, ${name}!</h2>
        <p style="color:#666;margin-bottom:24px">Your COBO account is ready. You can now send money, swap currencies, and collect payments across Africa.</p>
        <div style="background:#f8f6f0;border-radius:12px;padding:20px 24px;margin-bottom:24px">
          <p style="margin:0 0 8px;font-weight:600">Next steps:</p>
          <p style="margin:0 0 6px;color:#666">1. Complete your KYC verification to unlock full limits</p>
          <p style="margin:0 0 6px;color:#666">2. Add a currency wallet for your country</p>
          <p style="margin:0;color:#666">3. Create a payment link to start collecting</p>
        </div>
        <p style="color:#888;font-size:13px">Your account email: ${email}</p>
      </div>
    `
  }),

  paymentReceived: ({ name, amount, currency, payer, linkTitle }) => ({
    subject: `Payment received via "${linkTitle}" — COBO`,
    html: `
      <div style="font-family:sans-serif;max-width:560px;margin:0 auto;padding:32px 24px">
        <div style="font-size:24px;font-weight:800;color:#C9880F;margin-bottom:24px">🌍 COBO</div>
        <h2 style="font-size:20px;margin-bottom:8px">💰 Payment Received!</h2>
        <p style="color:#666;margin-bottom:24px">Hi ${name}, someone paid via your payment link.</p>
        <div style="background:#f0faf5;border:1px solid #b2dfc8;border-radius:12px;padding:20px 24px;margin-bottom:24px">
          <div style="font-size:28px;font-weight:800;color:#157a40;margin-bottom:4px">${currency} ${amount}</div>
          <div style="color:#888;font-size:14px">via "${linkTitle}" • from ${payer}</div>
        </div>
      </div>
    `
  })
}

async function sendTransferSentEmail(user, { amount, currency, recipient, reference }) {
  const tpl = TEMPLATES.transferSent({ name: user.first_name, amount, currency, recipient, reference })
  return sendEmail({ to: user.email, ...tpl })
}

async function sendTransferReceivedEmail(user, { amount, currency, sender, reference }) {
  const tpl = TEMPLATES.transferReceived({ name: user.first_name, amount, currency, sender, reference })
  return sendEmail({ to: user.email, ...tpl })
}

async function sendWelcomeEmail(user) {
  const tpl = TEMPLATES.welcome({ name: user.first_name, email: user.email })
  return sendEmail({ to: user.email, ...tpl })
}

async function sendPaymentReceivedEmail(user, { amount, currency, payer, linkTitle }) {
  const tpl = TEMPLATES.paymentReceived({ name: user.first_name, amount, currency, payer, linkTitle })
  return sendEmail({ to: user.email, ...tpl })
}

module.exports = {
  sendEmail,
  sendTransferSentEmail,
  sendTransferReceivedEmail,
  sendWelcomeEmail,
  sendPaymentReceivedEmail,
}
