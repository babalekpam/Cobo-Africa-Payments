const router = require('express').Router()
const bcrypt = require('bcryptjs')
const { v4: uuid } = require('uuid')
const { body, validationResult } = require('express-validator')
const db = require('../database')
const { auth, signToken } = require('../middleware/auth')
const { sendWelcomeEmail } = require('../services/email')

const DEFAULT_CURRENCIES = {
  NG:'NGN',GH:'GHS',SN:'XOF',TG:'XOF',CI:'XOF',CM:'XAF',
  KE:'KES',ZA:'ZAR',EG:'EGP',MA:'MAD',TZ:'TZS',UG:'UGX',
  ET:'ETB',RW:'RWF',US:'USD',GB:'GBP',FR:'EUR'
}

router.post('/register', [
  body('email').isEmail().normalizeEmail(),
  body('password').isLength({ min: 8 }),
  body('first_name').trim().notEmpty(),
  body('last_name').trim().notEmpty(),
  body('country').trim().notEmpty(),
], async (req, res) => {
  const errs = validationResult(req)
  if (!errs.isEmpty()) return res.status(400).json({ success: false, errors: errs.array() })

  const { email, password, first_name, last_name, phone, country, business_name, business_type } = req.body
  if (db.get('users').find({ email }).value())
    return res.status(409).json({ success: false, message: 'Email already registered' })

  const isFirstUser = db.get('users').size().value() === 0
  const user = {
    id: uuid(), email,
    password: await bcrypt.hash(password, 12),
    first_name, last_name,
    phone: phone || null, country,
    business_name: business_name || null,
    business_type: business_type || 'individual',
    kyc_status: 'pending', kyc_level: 0,
    role: isFirstUser ? 'admin' : 'user',
    is_active: true,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  }
  db.get('users').push(user).write()

  const primaryCur = DEFAULT_CURRENCIES[country] || 'USD'
  const currencies = [...new Set([primaryCur, 'USD'])]
  currencies.forEach((currency, i) => {
    db.get('wallets').push({
      id: uuid(), user_id: user.id, currency,
      balance: 0, locked_balance: 0, is_default: i === 0,
      created_at: new Date().toISOString()
    }).write()
  })

  db.get('notifications').push({
    id: uuid(), user_id: user.id,
    title: 'Welcome to COBO! 🌍',
    message: 'Your account is ready. Complete KYC to unlock full limits.',
    type: 'success', is_read: false,
    created_at: new Date().toISOString()
  }).write()

  if (isFirstUser) {
    db.get('notifications').push({
      id: uuid(), user_id: user.id,
      title: '⚙ Admin access granted',
      message: 'You are the first user — admin role assigned automatically.',
      type: 'info', is_read: false,
      created_at: new Date().toISOString()
    }).write()
  }

  // Send welcome email (non-blocking)
  sendWelcomeEmail(user).catch(() => {})

  const { password: _, ...safeUser } = user
  const wallets = db.get('wallets').filter({ user_id: user.id }).value()
  res.status(201).json({ success: true, message: 'Account created', token: signToken(user), user: safeUser, wallets })
})

router.post('/login', [
  body('email').isEmail().normalizeEmail(),
  body('password').notEmpty(),
], async (req, res) => {
  const { email, password } = req.body
  const user = db.get('users').find({ email, is_active: true }).value()
  if (!user) return res.status(401).json({ success: false, message: 'Invalid credentials' })
  if (!await bcrypt.compare(password, user.password))
    return res.status(401).json({ success: false, message: 'Invalid credentials' })
  const { password: _, ...safeUser } = user
  const wallets = db.get('wallets').filter({ user_id: user.id }).value()
  res.json({ success: true, token: signToken(user), user: safeUser, wallets })
})

router.get('/me', auth, (req, res) => {
  const { password: _, ...safeUser } = req.user
  const wallets = db.get('wallets').filter({ user_id: req.user.id }).value()
  res.json({ success: true, user: safeUser, wallets })
})

router.put('/profile', auth, (req, res) => {
  const { first_name, last_name, phone, business_name, business_type } = req.body
  const updates = { updated_at: new Date().toISOString() }
  if (first_name) updates.first_name = first_name
  if (last_name) updates.last_name = last_name
  if (phone !== undefined) updates.phone = phone
  if (business_name !== undefined) updates.business_name = business_name
  if (business_type) updates.business_type = business_type
  db.get('users').find({ id: req.user.id }).assign(updates).write()
  const { password: _, ...safeUser } = db.get('users').find({ id: req.user.id }).value()
  res.json({ success: true, message: 'Profile updated', user: safeUser })
})

router.post('/change-password', auth, async (req, res) => {
  const { current_password, new_password } = req.body
  if (!current_password || !new_password || new_password.length < 8)
    return res.status(400).json({ success: false, message: 'Invalid password data' })
  const user = db.get('users').find({ id: req.user.id }).value()
  if (!await bcrypt.compare(current_password, user.password))
    return res.status(400).json({ success: false, message: 'Current password incorrect' })
  db.get('users').find({ id: req.user.id }).assign({
    password: await bcrypt.hash(new_password, 12),
    updated_at: new Date().toISOString()
  }).write()
  res.json({ success: true, message: 'Password changed successfully' })
})

router.get('/dashboard', auth, (req, res) => {
  const uid = req.user.id
  const wallets = db.get('wallets').filter({ user_id: uid }).value()
  const allTx = db.get('transactions').filter({ user_id: uid }).value()
  const successTx = allTx.filter(t => t.status === 'success')
  const recent = [...allTx].sort((a,b) => new Date(b.created_at)-new Date(a.created_at)).slice(0,10)
  const unread = db.get('notifications').filter({ user_id: uid, is_read: false }).size().value()
  const monthlyMap = {}
  successTx.forEach(t => {
    const m = t.created_at.slice(0,7)
    if (!monthlyMap[m]) monthlyMap[m] = { month: m, volume: 0, count: 0 }
    monthlyMap[m].volume += t.amount
    monthlyMap[m].count++
  })
  const monthly_volume = Object.values(monthlyMap)
    .sort((a,b) => b.month.localeCompare(a.month)).slice(0,6)
  res.json({
    success: true, wallets,
    stats: {
      total_transactions: allTx.length,
      total_volume: successTx.reduce((s,t) => s+t.amount, 0),
      unread_notifications: unread
    },
    recent_transactions: recent,
    monthly_volume
  })
})

module.exports = router
