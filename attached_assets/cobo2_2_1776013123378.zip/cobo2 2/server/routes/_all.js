// wallets.js
const { Router } = require('express')
const { v4: uuid } = require('uuid')
const db = require('../database')
const { auth } = require('../middleware/auth')

const walletsRouter = Router()
const ALLOWED_CURRENCIES = ['USD','NGN','GHS','XOF','XAF','KES','ZAR','EGP','MAD','TZS','UGX','ETB','RWF','EUR','GBP']

walletsRouter.get('/', auth, (req, res) => {
  const wallets = db.get('wallets').filter({ user_id: req.user.id }).value()
  res.json({ success: true, wallets })
})

walletsRouter.post('/add', auth, (req, res) => {
  const { currency } = req.body
  if (!currency || !ALLOWED_CURRENCIES.includes(currency.toUpperCase()))
    return res.status(400).json({ success: false, message: 'Unsupported currency' })
  const cur = currency.toUpperCase()
  if (db.get('wallets').find({ user_id: req.user.id, currency: cur }).value())
    return res.status(409).json({ success: false, message: 'Wallet already exists' })
  const wallet = { id: uuid(), user_id: req.user.id, currency: cur, balance: 0, locked_balance: 0, is_default: false, created_at: new Date().toISOString() }
  db.get('wallets').push(wallet).write()
  res.status(201).json({ success: true, wallet })
})

walletsRouter.post('/fund', auth, (req, res) => {
  const { currency, amount } = req.body
  if (!currency || !amount || amount <= 0 || amount > 100000)
    return res.status(400).json({ success: false, message: 'Invalid funding. Max 100,000 in sandbox.' })
  const wallet = db.get('wallets').find({ user_id: req.user.id, currency: currency.toUpperCase() }).value()
  if (!wallet) return res.status(404).json({ success: false, message: 'Wallet not found' })
  db.get('wallets').find({ id: wallet.id }).assign({ balance: wallet.balance + Number(amount) }).write()
  const tx = { id: uuid(), user_id: req.user.id, type: 'deposit', status: 'success', amount: Number(amount), currency: currency.toUpperCase(), fee: 0, net_amount: Number(amount), reference: 'COBO-FUND-' + Date.now(), description: 'Sandbox wallet funding', provider: 'sandbox', created_at: new Date().toISOString() }
  db.get('transactions').push(tx).write()
  res.json({ success: true, message: `${currency} ${amount} added (sandbox)`, wallet: db.get('wallets').find({ id: wallet.id }).value() })
})

module.exports = { walletsRouter }

// ────────────────────────────────────────────────────────────
// transactions.js
const txRouter = Router()

txRouter.get('/', auth, (req, res) => {
  const { type, status, currency, page = 1, limit = 20 } = req.query
  let txs = db.get('transactions').filter({ user_id: req.user.id }).value()
  if (type) txs = txs.filter(t => t.type === type)
  if (status) txs = txs.filter(t => t.status === status)
  if (currency) txs = txs.filter(t => t.currency === currency.toUpperCase())
  txs.sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
  const total = txs.length
  const paginated = txs.slice((page-1)*limit, page*limit)
  res.json({ success: true, transactions: paginated, pagination: { page: Number(page), limit: Number(limit), total } })
})

txRouter.get('/:id', auth, (req, res) => {
  const tx = db.get('transactions').find({ id: req.params.id, user_id: req.user.id }).value()
  if (!tx) return res.status(404).json({ success: false, message: 'Not found' })
  res.json({ success: true, transaction: tx })
})

module.exports.txRouter = txRouter

// ────────────────────────────────────────────────────────────
// transfers.js
const transferRouter = Router()
const FEE = 0.009
const MIN_FEE = 0.5

function calcFee(amount) { return Math.max(amount * FEE, MIN_FEE) }

transferRouter.get('/fee', auth, (req, res) => {
  const { amount, type } = req.query
  const amt = parseFloat(amount) || 0
  const fee = type === 'internal' ? 0 : calcFee(amt)
  res.json({ success: true, amount: amt, fee, fee_percent: type === 'internal' ? 0 : FEE * 100, total: amt + fee })
})

transferRouter.get('/banks/:country', auth, (req, res) => {
  const BANKS = {
    NG: [{ name:'GTBank',code:'058' },{ name:'Access Bank',code:'044' },{ name:'Zenith Bank',code:'057' },{ name:'First Bank',code:'011' },{ name:'UBA',code:'033' },{ name:'Kuda Bank',code:'50211' },{ name:'Opay',code:'100004' }],
    GH: [{ name:'GCB Bank',code:'040100' },{ name:'Ecobank Ghana',code:'130100' },{ name:'Absa Bank',code:'030100' }],
    KE: [{ name:'KCB Bank',code:'01' },{ name:'Equity Bank',code:'68' },{ name:'NCBA Bank',code:'07' }],
    SN: [{ name:'CBAO',code:'CBAO' },{ name:'Ecobank Senegal',code:'ECO' }],
    TG: [{ name:'Ecobank Togo',code:'ECO-TG' },{ name:'BTCI',code:'BTCI' },{ name:'UTB',code:'UTB' }],
  }
  res.json({ success: true, banks: BANKS[req.params.country.toUpperCase()] || [] })
})

function makeTransfer(req, res, txData) {
  const { currency, amount } = txData
  const wallet = db.get('wallets').find({ user_id: req.user.id, currency: currency.toUpperCase() }).value()
  if (!wallet) return res.status(404).json({ success: false, message: `No ${currency} wallet` })
  const fee = txData.fee === 0 ? 0 : calcFee(amount)
  const total = amount + fee
  if (wallet.balance < total) return res.status(400).json({ success: false, message: `Insufficient balance. Need ${currency} ${total.toFixed(2)} (incl. ${fee.toFixed(2)} fee)` })
  db.get('wallets').find({ id: wallet.id }).assign({ balance: wallet.balance - total }).write()
  const ref = 'COBO-' + txData.refPrefix + '-' + Date.now() + '-' + Math.random().toString(36).slice(2,6).toUpperCase()
  const tx = { id: uuid(), user_id: req.user.id, type: 'send', status: txData.instant ? 'success' : 'pending', amount, currency: currency.toUpperCase(), fee, net_amount: amount - fee, reference: ref, description: txData.description, provider: txData.provider, created_at: new Date().toISOString() }
  db.get('transactions').push(tx).write()
  res.json({ success: true, message: 'Transfer initiated', transaction: tx, reference: ref })
}

transferRouter.post('/bank', auth, (req, res) => {
  const { currency, amount, account_number, account_name, bank_name, country, description } = req.body
  if (!currency || !amount || !account_number || !account_name) return res.status(400).json({ success: false, message: 'Missing required fields' })
  makeTransfer(req, res, { currency, amount: Number(amount), fee: calcFee(Number(amount)), refPrefix: 'BANK', provider: 'flutterwave', description: description || `Bank → ${account_name}`, instant: false })
})

transferRouter.post('/mobile-money', auth, (req, res) => {
  const { currency, amount, phone, provider, country, description } = req.body
  if (!currency || !amount || !phone) return res.status(400).json({ success: false, message: 'Missing required fields' })
  makeTransfer(req, res, { currency, amount: Number(amount), fee: calcFee(Number(amount)), refPrefix: 'MM', provider: provider || 'mobile_money', description: description || `${provider} → ${phone}`, instant: false })
})

transferRouter.post('/internal', auth, (req, res) => {
  const { recipient_email, amount, currency, description } = req.body
  if (!recipient_email || !amount || !currency) return res.status(400).json({ success: false, message: 'Missing fields' })
  if (recipient_email === req.user.email) return res.status(400).json({ success: false, message: 'Cannot send to yourself' })
  const recipient = db.get('users').find({ email: recipient_email, is_active: true }).value()
  if (!recipient) return res.status(404).json({ success: false, message: 'COBO user not found' })
  const fromWallet = db.get('wallets').find({ user_id: req.user.id, currency: currency.toUpperCase() }).value()
  if (!fromWallet || fromWallet.balance < Number(amount)) return res.status(400).json({ success: false, message: 'Insufficient balance' })
  db.get('wallets').find({ id: fromWallet.id }).assign({ balance: fromWallet.balance - Number(amount) }).write()
  let toWallet = db.get('wallets').find({ user_id: recipient.id, currency: currency.toUpperCase() }).value()
  if (!toWallet) {
    toWallet = { id: uuid(), user_id: recipient.id, currency: currency.toUpperCase(), balance: 0, locked_balance: 0, is_default: false, created_at: new Date().toISOString() }
    db.get('wallets').push(toWallet).write()
  }
  db.get('wallets').find({ id: toWallet.id }).assign({ balance: toWallet.balance + Number(amount) }).write()
  const ref = 'COBO-INT-' + Date.now()
  const now = new Date().toISOString()
  db.get('transactions').push({ id: uuid(), user_id: req.user.id, type: 'send', status: 'success', amount: Number(amount), currency: currency.toUpperCase(), fee: 0, net_amount: Number(amount), reference: ref, description: description || `Transfer to ${recipient.first_name}`, provider: 'cobo_internal', created_at: now }).write()
  db.get('transactions').push({ id: uuid(), user_id: recipient.id, type: 'receive', status: 'success', amount: Number(amount), currency: currency.toUpperCase(), fee: 0, net_amount: Number(amount), reference: ref + '-R', description: description || `From ${req.user.first_name} ${req.user.last_name}`, provider: 'cobo_internal', created_at: now }).write()
  db.get('notifications').push({ id: uuid(), user_id: recipient.id, title: 'Money Received! 💰', message: `${currency} ${amount} received from ${req.user.first_name} ${req.user.last_name}`, type: 'success', is_read: false, created_at: now }).write()
  res.json({ success: true, message: `Sent ${currency} ${amount} to ${recipient.first_name}`, reference: ref })
})

module.exports.transferRouter = transferRouter

// ────────────────────────────────────────────────────────────
// exchange.js
const exchangeRouter = Router()
const axios = require('axios')

async function getRate(from, to) {
  if (from === to) return 1
  const direct = db.get('exchange_rates').find({ from, to }).value()
  if (direct) return direct.rate
  const toUSD = db.get('exchange_rates').find({ from, to: 'USD' }).value()
  const fromUSD = db.get('exchange_rates').find({ from: 'USD', to }).value()
  if (toUSD && fromUSD) return toUSD.rate * fromUSD.rate
  throw new Error(`Rate unavailable for ${from}/${to}`)
}

exchangeRouter.get('/rates', auth, (req, res) => {
  const rates = db.get('exchange_rates').filter({ from: 'USD' }).value()
  const map = { USD: 1 }
  rates.forEach(r => { map[r.to] = r.rate })
  res.json({ success: true, base: 'USD', rates: map })
})

exchangeRouter.get('/rate', auth, async (req, res) => {
  try {
    const rate = await getRate(req.query.from?.toUpperCase(), req.query.to?.toUpperCase())
    res.json({ success: true, rate, from: req.query.from, to: req.query.to })
  } catch (e) { res.status(500).json({ success: false, message: e.message }) }
})

exchangeRouter.post('/convert', auth, async (req, res) => {
  const { from, to, amount } = req.body
  try {
    const rate = await getRate(from?.toUpperCase(), to?.toUpperCase())
    const converted = amount * rate
    const fee_amount = amount * 0.005
    const net_amount = converted * 0.995
    res.json({ success: true, from, to, amount: Number(amount), rate, converted, fee_percent: 0.5, fee_amount, net_amount })
  } catch (e) { res.status(500).json({ success: false, message: e.message }) }
})

exchangeRouter.post('/swap', auth, async (req, res) => {
  const { from_currency, to_currency, amount } = req.body
  const F = from_currency?.toUpperCase(), T = to_currency?.toUpperCase()
  if (!F || !T || !amount || amount <= 0) return res.status(400).json({ success: false, message: 'Invalid swap request' })
  const fromW = db.get('wallets').find({ user_id: req.user.id, currency: F }).value()
  if (!fromW || fromW.balance < amount) return res.status(400).json({ success: false, message: 'Insufficient balance' })
  const rate = await getRate(F, T)
  const received = Number(amount) * rate * 0.995
  db.get('wallets').find({ id: fromW.id }).assign({ balance: fromW.balance - Number(amount) }).write()
  let toW = db.get('wallets').find({ user_id: req.user.id, currency: T }).value()
  if (!toW) {
    toW = { id: uuid(), user_id: req.user.id, currency: T, balance: 0, locked_balance: 0, is_default: false, created_at: new Date().toISOString() }
    db.get('wallets').push(toW).write()
  }
  db.get('wallets').find({ id: toW.id }).assign({ balance: toW.balance + received }).write()
  const ref = 'COBO-SWAP-' + Date.now()
  db.get('transactions').push({ id: uuid(), user_id: req.user.id, type: 'swap', status: 'success', amount: Number(amount), currency: F, fee: Number(amount) * 0.005, net_amount: received, reference: ref, description: `Swap ${F} → ${T}`, recipient_currency: T, exchange_rate: rate, provider: 'cobo_fx', created_at: new Date().toISOString() }).write()
  res.json({ success: true, message: `Swapped ${F} → ${T}`, rate, amount_swapped: Number(amount), amount_received: received, from_wallet: db.get('wallets').find({ id: fromW.id }).value(), to_wallet: db.get('wallets').find({ id: toW.id }).value() })
})

module.exports.exchangeRouter = exchangeRouter

// ────────────────────────────────────────────────────────────
// paymentLinks.js
const plRouter = Router()

plRouter.post('/', auth, (req, res) => {
  const { title, description, amount, currency, is_fixed_amount, redirect_url } = req.body
  if (!title || !currency) return res.status(400).json({ success: false, message: 'Title and currency required' })
  const slug = title.toLowerCase().replace(/[^a-z0-9]/g,'-') + '-' + Math.random().toString(36).slice(2,8)
  const link = { id: uuid(), user_id: req.user.id, title, description: description || null, amount: amount ? Number(amount) : null, currency: currency.toUpperCase(), is_fixed_amount: is_fixed_amount !== false, slug, is_active: true, total_collected: 0, payment_count: 0, redirect_url: redirect_url || null, created_at: new Date().toISOString() }
  db.get('payment_links').push(link).write()
  res.status(201).json({ success: true, payment_link: link, url: `/pay/${slug}` })
})

plRouter.get('/', auth, (req, res) => {
  const links = db.get('payment_links').filter({ user_id: req.user.id }).value().sort((a,b) => new Date(b.created_at) - new Date(a.created_at))
  res.json({ success: true, payment_links: links })
})

plRouter.get('/:id', auth, (req, res) => {
  const link = db.get('payment_links').find({ id: req.params.id, user_id: req.user.id }).value()
  if (!link) return res.status(404).json({ success: false, message: 'Not found' })
  res.json({ success: true, payment_link: link })
})

plRouter.patch('/:id/toggle', auth, (req, res) => {
  const link = db.get('payment_links').find({ id: req.params.id, user_id: req.user.id }).value()
  if (!link) return res.status(404).json({ success: false, message: 'Not found' })
  db.get('payment_links').find({ id: link.id }).assign({ is_active: !link.is_active }).write()
  res.json({ success: true, message: `Link ${link.is_active ? 'deactivated' : 'activated'}` })
})

plRouter.delete('/:id', auth, (req, res) => {
  const link = db.get('payment_links').find({ id: req.params.id, user_id: req.user.id }).value()
  if (!link) return res.status(404).json({ success: false, message: 'Not found' })
  db.get('payment_links').remove({ id: req.params.id }).write()
  res.json({ success: true, message: 'Deleted' })
})

module.exports.plRouter = plRouter

// ────────────────────────────────────────────────────────────
// kyc.js
const kycRouter = Router()

kycRouter.post('/submit', auth, (req, res) => {
  const { doc_type, doc_url } = req.body
  if (!doc_type) return res.status(400).json({ success: false, message: 'doc_type required' })
  db.get('kyc_documents').push({ id: uuid(), user_id: req.user.id, doc_type, doc_url: doc_url || null, status: 'pending', created_at: new Date().toISOString() }).write()
  db.get('users').find({ id: req.user.id }).assign({ kyc_status: 'submitted', updated_at: new Date().toISOString() }).write()
  res.json({ success: true, message: 'Document submitted for review' })
})

kycRouter.get('/status', auth, (req, res) => {
  const docs = db.get('kyc_documents').filter({ user_id: req.user.id }).value()
  const user = db.get('users').find({ id: req.user.id }).value()
  res.json({ success: true, kyc_status: user.kyc_status, kyc_level: user.kyc_level, documents: docs })
})

module.exports.kycRouter = kycRouter

// ────────────────────────────────────────────────────────────
// notifications.js
const notifRouter = Router()

notifRouter.get('/', auth, (req, res) => {
  const notifs = db.get('notifications').filter({ user_id: req.user.id }).value().sort((a,b) => new Date(b.created_at) - new Date(a.created_at)).slice(0, 50)
  res.json({ success: true, notifications: notifs })
})

notifRouter.patch('/read-all', auth, (req, res) => {
  db.get('notifications').filter({ user_id: req.user.id }).each(n => { n.is_read = true }).write()
  res.json({ success: true, message: 'All marked as read' })
})

notifRouter.patch('/:id/read', auth, (req, res) => {
  db.get('notifications').find({ id: req.params.id, user_id: req.user.id }).assign({ is_read: true }).write()
  res.json({ success: true })
})

module.exports.notifRouter = notifRouter

// ────────────────────────────────────────────────────────────
// beneficiaries.js
const benRouter = Router()

benRouter.get('/', auth, (req, res) => {
  const bens = db.get('beneficiaries').filter({ user_id: req.user.id }).value()
  res.json({ success: true, beneficiaries: bens })
})

benRouter.post('/', auth, (req, res) => {
  const { name, country, currency, type, account_number, bank_name, phone, provider } = req.body
  if (!name) return res.status(400).json({ success: false, message: 'Name required' })
  const ben = { id: uuid(), user_id: req.user.id, name, country: country || 'NG', currency: currency || 'NGN', type: type || 'bank', account_number: account_number || null, bank_name: bank_name || null, phone: phone || null, provider: provider || null, created_at: new Date().toISOString() }
  db.get('beneficiaries').push(ben).write()
  res.status(201).json({ success: true, beneficiary: ben })
})

benRouter.delete('/:id', auth, (req, res) => {
  db.get('beneficiaries').remove({ id: req.params.id, user_id: req.user.id }).write()
  res.json({ success: true, message: 'Removed' })
})

module.exports.benRouter = benRouter

// ────────────────────────────────────────────────────────────
// webhooks.js
const crypto = require('crypto')
const whRouter = Router()

whRouter.post('/', auth, (req, res) => {
  const { url, events } = req.body
  if (!url) return res.status(400).json({ success: false, message: 'URL required' })
  const wh = { id: uuid(), user_id: req.user.id, url, events: events || 'payment.success,payment.failed', secret: 'whsec_' + crypto.randomBytes(24).toString('hex'), is_active: true, created_at: new Date().toISOString() }
  db.get('webhooks').push(wh).write()
  res.status(201).json({ success: true, webhook: wh })
})

whRouter.get('/', auth, (req, res) => res.json({ success: true, webhooks: db.get('webhooks').filter({ user_id: req.user.id }).value() }))

whRouter.delete('/:id', auth, (req, res) => {
  db.get('webhooks').remove({ id: req.params.id, user_id: req.user.id }).write()
  res.json({ success: true })
})

module.exports.whRouter = whRouter

// ────────────────────────────────────────────────────────────
// apiKeys.js
const bcrypt2 = require('bcryptjs')
const akRouter = Router()

akRouter.post('/', auth, async (req, res) => {
  const { name, is_live } = req.body
  if (!name) return res.status(400).json({ success: false, message: 'Name required' })
  const prefix = is_live ? 'ck_live_' : 'ck_test_'
  const rawKey = prefix + require('crypto').randomBytes(24).toString('hex')
  const hash = await bcrypt2.hash(rawKey, 10)
  db.get('api_keys').push({ id: uuid(), user_id: req.user.id, name, key_hash: hash, key_prefix: prefix, is_live: !!is_live, is_active: true, last_used_at: null, created_at: new Date().toISOString() }).write()
  res.status(201).json({ success: true, key: rawKey, message: 'Save this key — shown only once!' })
})

akRouter.get('/', auth, (req, res) => {
  const keys = db.get('api_keys').filter({ user_id: req.user.id }).value().map(({ key_hash, ...k }) => k)
  res.json({ success: true, api_keys: keys })
})

akRouter.delete('/:id', auth, (req, res) => {
  db.get('api_keys').find({ id: req.params.id, user_id: req.user.id }).assign({ is_active: false }).write()
  res.json({ success: true, message: 'Key revoked' })
})

module.exports.akRouter = akRouter

// ────────────────────────────────────────────────────────────
// admin.js
const { adminAuth } = require('../middleware/auth')
const adminRouter = Router()

adminRouter.get('/stats', adminAuth, (req, res) => {
  const users = db.get('users').value()
  const txs = db.get('transactions').value()
  const success = txs.filter(t => t.status === 'success')
  const pendingKYC = db.get('kyc_documents').filter({ status: 'pending' }).size().value()
  res.json({ success: true, stats: { total_users: users.length, total_transactions: txs.length, total_volume: success.reduce((s,t) => s+t.amount, 0), pending_kyc: pendingKYC } })
})

adminRouter.get('/users', adminAuth, (req, res) => {
  const users = db.get('users').value().map(({ password, ...u }) => u)
  res.json({ success: true, users })
})

adminRouter.get('/transactions', adminAuth, (req, res) => {
  const txs = db.get('transactions').value().sort((a,b) => new Date(b.created_at) - new Date(a.created_at)).slice(0, 200)
  res.json({ success: true, transactions: txs })
})

adminRouter.patch('/kyc/:docId', adminAuth, (req, res) => {
  const { status, rejection_reason } = req.body
  if (!['approved','rejected'].includes(status)) return res.status(400).json({ success: false, message: 'Invalid status' })
  const doc = db.get('kyc_documents').find({ id: req.params.docId }).value()
  if (!doc) return res.status(404).json({ success: false, message: 'Document not found' })
  db.get('kyc_documents').find({ id: doc.id }).assign({ status, rejection_reason: rejection_reason || null, reviewed_at: new Date().toISOString() }).write()
  if (status === 'approved') {
    db.get('users').find({ id: doc.user_id }).assign({ kyc_status: 'verified', kyc_level: 1, updated_at: new Date().toISOString() }).write()
    db.get('notifications').push({ id: uuid(), user_id: doc.user_id, title: 'KYC Approved! ✅', message: 'Your identity is verified. Full access unlocked.', type: 'success', is_read: false, created_at: new Date().toISOString() }).write()
  } else {
    db.get('users').find({ id: doc.user_id }).assign({ kyc_status: 'rejected', updated_at: new Date().toISOString() }).write()
  }
  res.json({ success: true, message: `KYC ${status}` })
})

adminRouter.patch('/users/:id/toggle', adminAuth, (req, res) => {
  const user = db.get('users').find({ id: req.params.id }).value()
  if (!user) return res.status(404).json({ success: false, message: 'Not found' })
  db.get('users').find({ id: req.params.id }).assign({ is_active: !user.is_active }).write()
  res.json({ success: true, message: `User ${user.is_active ? 'deactivated' : 'activated'}` })
})

module.exports.adminRouter = adminRouter

// ────────────────────────────────────────────────────────────
// public.js (no auth — pay pages, webhook receiver)
const pubRouter = Router()

pubRouter.get('/pay/:slug', (req, res) => {
  const link = db.get('payment_links').find({ slug: req.params.slug, is_active: true }).value()
  if (!link) return res.status(404).json({ success: false, message: 'Payment link not found or inactive' })
  const owner = db.get('users').find({ id: link.user_id }).value()
  res.json({ success: true, payment_link: { ...link, business_name: owner?.business_name || `${owner?.first_name} ${owner?.last_name}` } })
})

pubRouter.post('/pay/:slug/charge', (req, res) => {
  const { amount, email, name } = req.body
  const link = db.get('payment_links').find({ slug: req.params.slug, is_active: true }).value()
  if (!link) return res.status(404).json({ success: false, message: 'Invalid link' })
  const finalAmount = link.is_fixed_amount ? link.amount : Number(amount)
  if (!finalAmount || finalAmount <= 0) return res.status(400).json({ success: false, message: 'Amount required' })
  const ref = 'COBO-PAY-' + Date.now() + '-' + Math.random().toString(36).slice(2,6).toUpperCase()
  db.get('transactions').push({ id: uuid(), user_id: link.user_id, type: 'receive', status: 'success', amount: finalAmount, currency: link.currency, fee: finalAmount * 0.014, net_amount: finalAmount * 0.986, reference: ref, description: `Payment via "${link.title}" from ${name || email}`, provider: 'cobo_link', created_at: new Date().toISOString() }).write()
  let wallet = db.get('wallets').find({ user_id: link.user_id, currency: link.currency }).value()
  if (!wallet) {
    wallet = { id: uuid(), user_id: link.user_id, currency: link.currency, balance: 0, locked_balance: 0, is_default: false, created_at: new Date().toISOString() }
    db.get('wallets').push(wallet).write()
  }
  db.get('wallets').find({ id: wallet.id }).assign({ balance: wallet.balance + finalAmount * 0.986 }).write()
  db.get('payment_links').find({ id: link.id }).assign({ total_collected: link.total_collected + finalAmount, payment_count: link.payment_count + 1 }).write()
  db.get('notifications').push({ id: uuid(), user_id: link.user_id, title: 'Payment Received! 💰', message: `${link.currency} ${finalAmount} received from ${name || email || 'a customer'}`, type: 'success', is_read: false, created_at: new Date().toISOString() }).write()
  res.json({ success: true, message: 'Payment successful', reference: ref, redirect_url: link.redirect_url })
})

pubRouter.post('/webhook/flutterwave', (req, res) => {
  const hash = req.headers['verif-hash']
  if (hash !== process.env.FLUTTERWAVE_SECRET_KEY) return res.sendStatus(401)
  const { event, data } = req.body
  if (event === 'charge.completed' && data.status === 'successful') {
    db.get('transactions').find({ external_reference: String(data.id) }).assign({ status: 'success' }).write()
  }
  res.sendStatus(200)
})

module.exports.pubRouter = pubRouter
