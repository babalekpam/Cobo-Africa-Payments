const router = require('express').Router()
const { v4: uuid } = require('uuid')
const db = require('../database')
const { auth } = require('../middleware/auth')
const { sendTransferSentEmail, sendTransferReceivedEmail } = require('../services/email')
const fw = require('../services/flutterwave')

const FEE = 0.009
const MIN_FEE = 0.5

function calcFee(amount) {
  return Math.max(amount * FEE, MIN_FEE)
}

// GET /api/transfers/fee
router.get('/fee', auth, (req, res) => {
  const { amount, type } = req.query
  const amt = parseFloat(amount) || 0
  const fee = type === 'internal' ? 0 : calcFee(amt)
  res.json({
    success: true,
    amount: amt,
    fee: parseFloat(fee.toFixed(4)),
    fee_percent: type === 'internal' ? 0 : FEE * 100,
    total: parseFloat((amt + fee).toFixed(4)),
    is_internal: type === 'internal',
    mode: fw.isConfigured() ? 'live' : 'sandbox',
  })
})

// GET /api/transfers/banks/:country
router.get('/banks/:country', auth, async (req, res) => {
  const country = req.params.country.toUpperCase()
  // Try Flutterwave live list first
  const liveBanks = await fw.getBanks(country).catch(() => [])
  if (liveBanks.length > 0) return res.json({ success: true, banks: liveBanks, source: 'flutterwave' })
  // Fallback static list
  const STATIC = {
    NG: [{ name:'GTBank',code:'058' },{ name:'Access Bank',code:'044' },{ name:'Zenith Bank',code:'057' },{ name:'First Bank',code:'011' },{ name:'UBA',code:'033' },{ name:'Kuda Bank',code:'50211' },{ name:'Opay',code:'100004' },{ name:'Palmpay',code:'100033' }],
    GH: [{ name:'GCB Bank',code:'040100' },{ name:'Ecobank Ghana',code:'130100' },{ name:'Absa Bank',code:'030100' },{ name:'Fidelity Bank',code:'240100' }],
    KE: [{ name:'KCB Bank',code:'01' },{ name:'Equity Bank',code:'68' },{ name:'NCBA Bank',code:'07' },{ name:'Co-op Bank',code:'11' }],
    SN: [{ name:'CBAO',code:'CBAO' },{ name:'Ecobank Senegal',code:'ECO' },{ name:'SGBS',code:'SGBS' },{ name:'BIS',code:'BIS' }],
    TG: [{ name:'Ecobank Togo',code:'ECO-TG' },{ name:'BTCI',code:'BTCI' },{ name:'UTB',code:'UTB' },{ name:'BIA Togo',code:'BIA' }],
    CI: [{ name:'Ecobank CI',code:'ECO-CI' },{ name:'SGBCI',code:'SGBCI' },{ name:'BICICI',code:'BICICI' }],
    CM: [{ name:'Afriland First Bank',code:'AFR' },{ name:'SCB Cameroun',code:'SCB' },{ name:'BICEC',code:'BICEC' }],
    ZA: [{ name:'Standard Bank',code:'051' },{ name:'Absa',code:'632005' },{ name:'FNB',code:'250655' },{ name:'Nedbank',code:'198765' }],
    EG: [{ name:'National Bank of Egypt',code:'NBE' },{ name:'Banque Misr',code:'BM' },{ name:'CIB Egypt',code:'CIB' }],
    MA: [{ name:'Attijariwafa Bank',code:'ATW' },{ name:'BMCE Bank',code:'BMCE' },{ name:'CIH Bank',code:'CIH' }],
  }
  res.json({ success: true, banks: STATIC[country] || [], source: 'static' })
})

// POST /api/transfers/bank
router.post('/bank', auth, async (req, res) => {
  const { currency, amount, account_number, account_name, bank_name, bank_code, country, description } = req.body
  if (!currency || !amount || amount <= 0 || !account_number || !account_name)
    return res.status(400).json({ success: false, message: 'Missing required fields' })

  const cur = currency.toUpperCase()
  const amt = Number(amount)
  const fee = calcFee(amt)
  const total = amt + fee

  const wallet = db.get('wallets').find({ user_id: req.user.id, currency: cur }).value()
  if (!wallet) return res.status(404).json({ success: false, message: `No ${cur} wallet found` })
  if (wallet.balance < total)
    return res.status(400).json({ success: false, message: `Insufficient balance. Need ${cur} ${total.toFixed(2)} (incl. ${fee.toFixed(2)} fee)` })

  const ref = 'COBO-BANK-' + Date.now() + '-' + Math.random().toString(36).slice(2,6).toUpperCase()

  // Attempt Flutterwave transfer
  let externalId = null
  let status = 'pending'
  try {
    const fwRes = await fw.initiateTransfer({
      account_bank: bank_code || '000',
      account_number,
      amount: amt,
      currency: cur,
      narration: description || `COBO Transfer to ${account_name}`,
      reference: ref,
      callback_url: `${process.env.SERVER_URL || ''}/api/public/webhook/flutterwave`,
    })
    externalId = fwRes.id
    if (fwRes.sandbox) status = 'success' // sandbox = instant
    else status = 'processing'
  } catch (err) {
    return res.status(502).json({ success: false, message: 'Transfer failed: ' + err.message })
  }

  // Deduct from wallet
  db.get('wallets').find({ id: wallet.id }).assign({ balance: wallet.balance - total }).write()

  const tx = {
    id: uuid(), user_id: req.user.id,
    type: 'send', status, amount: amt, currency: cur,
    fee, net_amount: amt,
    reference: ref, external_reference: externalId ? String(externalId) : null,
    description: description || `Bank transfer to ${account_name}`,
    recipient_name: account_name, recipient_account: account_number,
    recipient_bank: bank_name || bank_code || '',
    recipient_country: country || '', provider: 'flutterwave',
    created_at: new Date().toISOString()
  }
  db.get('transactions').push(tx).write()

  // Email (non-blocking)
  sendTransferSentEmail(req.user, { amount: amt, currency: cur, recipient: account_name, reference: ref }).catch(() => {})

  res.json({ success: true, message: 'Transfer initiated', transaction: tx, reference: ref, mode: fw.isConfigured() ? 'live' : 'sandbox' })
})

// POST /api/transfers/mobile-money
router.post('/mobile-money', auth, async (req, res) => {
  const { currency, amount, phone, provider, recipient_name, country, description } = req.body
  if (!currency || !amount || amount <= 0 || !phone || !provider)
    return res.status(400).json({ success: false, message: 'Missing required fields' })

  const cur = currency.toUpperCase()
  const amt = Number(amount)
  const fee = calcFee(amt)
  const total = amt + fee

  const wallet = db.get('wallets').find({ user_id: req.user.id, currency: cur }).value()
  if (!wallet) return res.status(404).json({ success: false, message: `No ${cur} wallet found` })
  if (wallet.balance < total)
    return res.status(400).json({ success: false, message: `Insufficient balance. Need ${cur} ${total.toFixed(2)}` })

  const ref = 'COBO-MM-' + Date.now() + '-' + Math.random().toString(36).slice(2,6).toUpperCase()

  let externalId = null
  let status = 'pending'
  try {
    const fwRes = await fw.initiateMobileMoneyTransfer({
      phone_number: phone, amount: amt, currency: cur,
      narration: description || `COBO Mobile Money`,
      reference: ref, provider,
    })
    externalId = fwRes.id
    status = fwRes.sandbox ? 'success' : 'processing'
  } catch (err) {
    return res.status(502).json({ success: false, message: 'Transfer failed: ' + err.message })
  }

  db.get('wallets').find({ id: wallet.id }).assign({ balance: wallet.balance - total }).write()

  const tx = {
    id: uuid(), user_id: req.user.id,
    type: 'send', status, amount: amt, currency: cur,
    fee, net_amount: amt,
    reference: ref, external_reference: externalId ? String(externalId) : null,
    description: description || `${provider} transfer to ${phone}`,
    recipient_name: recipient_name || phone,
    recipient_account: phone, recipient_country: country || '',
    provider, created_at: new Date().toISOString()
  }
  db.get('transactions').push(tx).write()

  // Notification for sandbox (simulate callback)
  if (status === 'success') {
    db.get('notifications').push({
      id: uuid(), user_id: req.user.id,
      title: 'Transfer Successful ✅',
      message: `${cur} ${amt.toLocaleString()} sent via ${provider} to ${phone}`,
      type: 'success', is_read: false,
      created_at: new Date().toISOString()
    }).write()
  }

  sendTransferSentEmail(req.user, { amount: amt, currency: cur, recipient: phone, reference: ref }).catch(() => {})

  res.json({ success: true, message: 'Mobile money transfer initiated', transaction: tx, reference: ref, mode: fw.isConfigured() ? 'live' : 'sandbox' })
})

// POST /api/transfers/internal  (free COBO-to-COBO)
router.post('/internal', auth, (req, res) => {
  const { recipient_email, amount, currency, description } = req.body
  if (!recipient_email || !amount || !currency || amount <= 0)
    return res.status(400).json({ success: false, message: 'Missing required fields' })
  if (recipient_email.toLowerCase() === req.user.email.toLowerCase())
    return res.status(400).json({ success: false, message: 'Cannot send to yourself' })

  const cur = currency.toUpperCase()
  const amt = Number(amount)

  const recipient = db.get('users').find({ email: recipient_email, is_active: true }).value()
  if (!recipient) return res.status(404).json({ success: false, message: 'COBO user not found' })

  const fromWallet = db.get('wallets').find({ user_id: req.user.id, currency: cur }).value()
  if (!fromWallet) return res.status(404).json({ success: false, message: `No ${cur} wallet` })
  if (fromWallet.balance < amt)
    return res.status(400).json({ success: false, message: `Insufficient balance. Need ${cur} ${amt}` })

  let toWallet = db.get('wallets').find({ user_id: recipient.id, currency: cur }).value()
  if (!toWallet) {
    toWallet = { id: uuid(), user_id: recipient.id, currency: cur, balance: 0, locked_balance: 0, is_default: false, created_at: new Date().toISOString() }
    db.get('wallets').push(toWallet).write()
  }

  db.get('wallets').find({ id: fromWallet.id }).assign({ balance: fromWallet.balance - amt }).write()
  db.get('wallets').find({ id: toWallet.id }).assign({ balance: toWallet.balance + amt }).write()

  const ref = 'COBO-INT-' + Date.now()
  const now = new Date().toISOString()
  const senderName = `${req.user.first_name} ${req.user.last_name}`
  const recipientName = `${recipient.first_name} ${recipient.last_name}`

  db.get('transactions').push({
    id: uuid(), user_id: req.user.id,
    type: 'send', status: 'success', amount: amt, currency: cur,
    fee: 0, net_amount: amt, reference: ref,
    description: description || `Transfer to ${recipientName}`,
    recipient_name: recipientName, recipient_account: recipient_email,
    provider: 'cobo_internal', created_at: now
  }).write()

  db.get('transactions').push({
    id: uuid(), user_id: recipient.id,
    type: 'receive', status: 'success', amount: amt, currency: cur,
    fee: 0, net_amount: amt, reference: ref + '-R',
    description: description || `From ${senderName}`,
    recipient_name: senderName, provider: 'cobo_internal', created_at: now
  }).write()

  db.get('notifications').push({
    id: uuid(), user_id: recipient.id,
    title: 'Money Received! 💰',
    message: `${cur} ${amt.toLocaleString()} received from ${senderName}`,
    type: 'success', is_read: false, created_at: now
  }).write()

  // Emails (non-blocking)
  sendTransferSentEmail(req.user, { amount: amt, currency: cur, recipient: recipientName, reference: ref }).catch(() => {})
  sendTransferReceivedEmail(recipient, { amount: amt, currency: cur, sender: senderName, reference: ref }).catch(() => {})

  res.json({ success: true, message: `${cur} ${amt} sent to ${recipientName}`, reference: ref })
})

// POST /api/transfers/resolve-account
router.post('/resolve-account', auth, async (req, res) => {
  const { account_number, account_bank } = req.body
  if (!account_number || !account_bank)
    return res.status(400).json({ success: false, message: 'account_number and account_bank required' })
  try {
    const result = await fw.resolveAccount(account_number, account_bank)
    res.json({ success: true, account_name: result.account_name, account_number: result.account_number })
  } catch (err) {
    res.status(502).json({ success: false, message: 'Could not resolve account: ' + err.message })
  }
})

module.exports = router
