const router = require('express').Router()
const { v4: uuid } = require('uuid')
const db = require('../database')
const { sendPaymentReceivedEmail } = require('../services/email')
const fw = require('../services/flutterwave')

// GET /api/public/pay/:slug  — no auth required
router.get('/pay/:slug', (req, res) => {
  const link = db.get('payment_links').find({ slug: req.params.slug, is_active: true }).value()
  if (!link) return res.status(404).json({ success: false, message: 'Payment link not found or inactive' })
  const owner = db.get('users').find({ id: link.user_id }).value()
  res.json({
    success: true,
    payment_link: {
      ...link,
      business_name: owner?.business_name || `${owner?.first_name} ${owner?.last_name}`
    }
  })
})

// POST /api/public/pay/:slug/charge  — no auth required
router.post('/pay/:slug/charge', (req, res) => {
  const { amount, email, name, currency: payCurrency } = req.body
  const link = db.get('payment_links').find({ slug: req.params.slug, is_active: true }).value()
  if (!link) return res.status(404).json({ success: false, message: 'Invalid or inactive payment link' })

  const finalAmount = link.is_fixed_amount ? link.amount : Number(amount)
  if (!finalAmount || finalAmount <= 0)
    return res.status(400).json({ success: false, message: 'Amount required' })

  const ref = 'COBO-PAY-' + Date.now() + '-' + Math.random().toString(36).slice(2, 6).toUpperCase()
  const fee = parseFloat((finalAmount * 0.014).toFixed(4))
  const net = parseFloat((finalAmount - fee).toFixed(4))

  // Credit merchant wallet
  let wallet = db.get('wallets').find({ user_id: link.user_id, currency: link.currency }).value()
  if (!wallet) {
    wallet = {
      id: uuid(), user_id: link.user_id, currency: link.currency,
      balance: 0, locked_balance: 0, is_default: false,
      created_at: new Date().toISOString()
    }
    db.get('wallets').push(wallet).write()
  }
  db.get('wallets').find({ id: wallet.id }).assign({ balance: wallet.balance + net }).write()

  // Record transaction
  const tx = {
    id: uuid(), user_id: link.user_id,
    type: 'receive', status: 'success',
    amount: finalAmount, currency: link.currency,
    fee, net_amount: net,
    reference: ref,
    description: `Payment via "${link.title}" from ${name || email || 'customer'}`,
    recipient_name: name || email || 'Customer',
    provider: 'cobo_link',
    created_at: new Date().toISOString()
  }
  db.get('transactions').push(tx).write()

  // Update payment link stats
  db.get('payment_links').find({ id: link.id }).assign({
    total_collected: link.total_collected + finalAmount,
    payment_count: link.payment_count + 1
  }).write()

  // In-app notification for merchant
  db.get('notifications').push({
    id: uuid(), user_id: link.user_id,
    title: 'Payment Received! 💰',
    message: `${link.currency} ${finalAmount.toLocaleString()} from ${name || email || 'a customer'} via "${link.title}"`,
    type: 'success', is_read: false,
    created_at: new Date().toISOString()
  }).write()

  // Email merchant (non-blocking)
  const owner = db.get('users').find({ id: link.user_id }).value()
  if (owner) {
    sendPaymentReceivedEmail(owner, {
      amount: finalAmount,
      currency: link.currency,
      payer: name || email || 'a customer',
      linkTitle: link.title
    }).catch(() => {})
  }

  res.json({
    success: true,
    message: 'Payment successful',
    reference: ref,
    redirect_url: link.redirect_url || null
  })
})

// POST /api/public/webhook/flutterwave  — Flutterwave callback
router.post('/webhook/flutterwave', (req, res) => {
  if (!fw.validateWebhook(req)) return res.sendStatus(401)
  const { event, data } = req.body
  if (event === 'charge.completed' && data?.status === 'successful') {
    db.get('transactions').find({ external_reference: String(data.id) })
      .assign({ status: 'success', updated_at: new Date().toISOString() }).write()
  }
  if (event === 'transfer.completed') {
    const ref = data?.reference
    if (ref) {
      const status = data?.status === 'SUCCESSFUL' ? 'success' : 'failed'
      db.get('transactions').find({ reference: ref })
        .assign({ status, updated_at: new Date().toISOString() }).write()
    }
  }
  res.sendStatus(200)
})

module.exports = router
