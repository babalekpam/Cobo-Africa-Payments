const { benRouter } = require('./_all'); module.exports = benRouter;
