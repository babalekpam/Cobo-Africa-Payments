const { akRouter } = require('./_all'); module.exports = akRouter;
