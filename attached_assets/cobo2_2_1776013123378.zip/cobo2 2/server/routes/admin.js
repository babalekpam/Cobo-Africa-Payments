const { adminRouter } = require('./_all'); module.exports = adminRouter;
