const { exchangeRouter } = require('./_all'); module.exports = exchangeRouter;
