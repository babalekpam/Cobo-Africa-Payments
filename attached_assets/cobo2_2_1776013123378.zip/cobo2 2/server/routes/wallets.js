const { walletsRouter } = require('./_all'); module.exports = walletsRouter;
