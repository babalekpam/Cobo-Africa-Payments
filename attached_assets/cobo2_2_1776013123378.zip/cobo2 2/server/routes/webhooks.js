const { whRouter } = require('./_all'); module.exports = whRouter;
