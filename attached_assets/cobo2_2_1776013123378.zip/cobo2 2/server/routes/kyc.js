const { kycRouter } = require('./_all'); module.exports = kycRouter;
