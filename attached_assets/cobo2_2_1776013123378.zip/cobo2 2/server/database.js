const low = require('lowdb')
const FileSync = require('lowdb/adapters/FileSync')
const path = require('path')
const fs = require('fs')

const DATA_DIR = path.join(__dirname, '..', 'data')
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true })

const adapter = new FileSync(path.join(DATA_DIR, 'cobo.json'))
const db = low(adapter)

// Seed default structure + exchange rates
db.defaults({
  users: [],
  wallets: [],
  transactions: [],
  payment_links: [],
  kyc_documents: [],
  api_keys: [],
  webhooks: [],
  notifications: [],
  beneficiaries: [],
  exchange_rates: [
    { from: 'USD', to: 'NGN', rate: 1580.00 },
    { from: 'USD', to: 'GHS', rate: 14.50 },
    { from: 'USD', to: 'XOF', rate: 620.00 },
    { from: 'USD', to: 'KES', rate: 129.00 },
    { from: 'USD', to: 'ZAR', rate: 18.90 },
    { from: 'USD', to: 'EGP', rate: 48.50 },
    { from: 'USD', to: 'MAD', rate: 10.10 },
    { from: 'USD', to: 'TZS', rate: 2540.00 },
    { from: 'USD', to: 'UGX', rate: 3750.00 },
    { from: 'USD', to: 'ETB', rate: 57.50 },
    { from: 'USD', to: 'RWF', rate: 1290.00 },
    { from: 'USD', to: 'EUR', rate: 0.92 },
    { from: 'USD', to: 'GBP', rate: 0.79 },
    { from: 'NGN', to: 'USD', rate: 0.000633 },
    { from: 'GHS', to: 'USD', rate: 0.069 },
    { from: 'XOF', to: 'USD', rate: 0.00161 },
    { from: 'KES', to: 'USD', rate: 0.00775 },
    { from: 'ZAR', to: 'USD', rate: 0.053 },
    { from: 'EUR', to: 'USD', rate: 1.087 },
    { from: 'GBP', to: 'USD', rate: 1.265 },
  ]
}).write()

console.log('✅ Database (lowdb/JSON) initialized at', DATA_DIR)

module.exports = db
