require('dotenv').config()
const express = require('express')
const cors = require('cors')
const helmet = require('helmet')
const morgan = require('morgan')
const compression = require('compression')
const path = require('path')
const rateLimit = require('express-rate-limit')

require('./database') // init on startup

const app = express()
const PORT = process.env.PORT || 3000

// ── Security ──────────────────────────────────────────────
app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false }))

app.use(cors({
  origin: (origin, cb) => cb(null, true), // allow all origins (Replit dynamic URLs)
  credentials: true,
  methods: ['GET','POST','PUT','PATCH','DELETE','OPTIONS'],
  allowedHeaders: ['Content-Type','Authorization','X-API-Key']
}))

app.use(compression())
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'))
app.use(express.json({ limit: '10mb' }))
app.use(express.urlencoded({ extended: true }))

// Rate limiting
const limiter = rateLimit({ windowMs: 15*60*1000, max: 300, standardHeaders: true, legacyHeaders: false })
const authLimiter = rateLimit({ windowMs: 15*60*1000, max: 30 })
app.use('/api/', limiter)

// ── Routes ────────────────────────────────────────────────
app.use('/api/auth',          authLimiter, require('./routes/auth'))
app.use('/api/wallets',       require('./routes/wallets'))
app.use('/api/transactions',  require('./routes/transactions'))
app.use('/api/transfers',     require('./routes/transfers'))
app.use('/api/payment-links', require('./routes/paymentLinks'))
app.use('/api/exchange',      require('./routes/exchange'))
app.use('/api/webhooks',      require('./routes/webhooks'))
app.use('/api/api-keys',      require('./routes/apiKeys'))
app.use('/api/kyc',           require('./routes/kyc'))
app.use('/api/notifications', require('./routes/notifications'))
app.use('/api/beneficiaries', require('./routes/beneficiaries'))
app.use('/api/admin',         require('./routes/admin'))
app.use('/api/public',        require('./routes/public'))

// Health check
app.get('/api/health', (req, res) => res.json({
  success: true,
  service: 'COBO Payment Platform',
  version: '1.0.0',
  status: 'operational',
  timestamp: new Date().toISOString(),
  db: 'lowdb/json (Replit compatible)'
}))

// ── Serve React frontend (production) ─────────────────────
const clientDist = path.join(__dirname, '..', 'client', 'dist')
const fs = require('fs')
if (fs.existsSync(clientDist)) {
  app.use(express.static(clientDist))
  app.get('*', (req, res) => {
    if (!req.path.startsWith('/api')) {
      res.sendFile(path.join(clientDist, 'index.html'))
    }
  })
} else {
  app.get('/', (req, res) => res.json({ 
    message: '🌍 COBO API running. Run `npm run build` to serve the frontend.',
    docs: '/api/health'
  }))
}

// ── Error handler ─────────────────────────────────────────
app.use((err, req, res, next) => {
  console.error('❌', err.message)
  res.status(err.status || 500).json({
    success: false,
    message: err.message || 'Internal server error',
    ...(process.env.NODE_ENV !== 'production' && { stack: err.stack })
  })
})

app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 COBO running on port ${PORT}`)
  console.log(`🌍 Mode: ${process.env.NODE_ENV || 'development'}`)
  console.log(`💾 DB: lowdb/JSON (no native binaries)`)
})

module.exports = app
