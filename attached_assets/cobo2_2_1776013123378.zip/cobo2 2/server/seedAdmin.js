require('dotenv').config()
const bcrypt = require('bcryptjs')
const { v4: uuid } = require('uuid')
const db = require('./database')

const email = process.env.ADMIN_EMAIL || 'admin@cobo.africa'
const password = process.env.ADMIN_PASSWORD || 'CoboAdmin2024!'

async function seed() {
  const existing = db.get('users').find({ email }).value()
  if (existing) {
    db.get('users').find({ id: existing.id }).assign({ role: 'admin' }).write()
    console.log(`✅ Admin role granted to: ${email}`)
    return
  }

  const hash = await bcrypt.hash(password, 12)
  const user = {
    id: uuid(), email, password: hash,
    first_name: 'COBO', last_name: 'Admin',
    country: 'US', role: 'admin',
    kyc_status: 'verified', kyc_level: 2,
    business_name: 'COBO Platform', business_type: 'business',
    is_active: true, phone: null,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  }
  db.get('users').push(user).write()
  db.get('wallets').push({ id: uuid(), user_id: user.id, currency: 'USD', balance: 0, locked_balance: 0, is_default: true, created_at: new Date().toISOString() }).write()
  console.log(`✅ Admin created: ${email} / ${password}`)
  console.log('⚠️  Change the password immediately after first login!')
}

seed()
