#!/bin/bash
set -e

echo "🌍 Setting up COBO Payment Platform..."

# Install root dependencies
echo "📦 Installing backend dependencies..."
npm install

# Install + build client
echo "📦 Installing frontend dependencies..."
cd client && npm install

echo "🔨 Building React frontend..."
npm run build
cd ..

# Copy env if not exists
if [ ! -f .env ]; then
  cp .env.example .env
  echo "✅ .env created from .env.example — edit your secrets!"
fi

# Seed admin (first run only, safe to re-run)
echo "🔑 Seeding admin user..."
node server/seedAdmin.js

echo ""
echo "✅ COBO setup complete!"
echo "👉 Add your secrets in Replit → Secrets tab"
echo "👉 Click Run to start the platform"
echo ""
echo "   Default admin: admin@cobo.africa / CoboAdmin2024!"
echo "   Change password immediately after first login"
