# 🌍 COBO — Africa's Unified Payment Infrastructure
**Stripe-style payment platform for Africa. 54 countries. 15 currencies. Zero native dependencies.**

---

## 🚀 Deploy on Replit — 3 Steps

### Step 1 — Import
1. Create new Replit → **Node.js** template
2. Upload `COBO-platform.zip` → Replit auto-extracts
3. Open **Shell** tab

### Step 2 — Build
```bash
chmod +x build.sh && bash build.sh
```
This installs all dependencies (backend + frontend), builds the React app, and seeds the admin user.

### Step 3 — Add Secrets
In Replit → **Secrets** tab, add at minimum:
| Key | Value |
|-----|-------|
| `JWT_SECRET` | any long random string |
| `NODE_ENV` | `production` |

Click **Run** — your platform is live at `https://your-app.replit.app`

**Default admin login:** `admin@cobo.africa` / `CoboAdmin2024!`  
⚠️ Change the password immediately after first login!

---

## 📁 Architecture

```
cobo/
├── server/
│   ├── index.js              # Express server entry point
│   ├── database.js           # lowdb/JSON (no native deps — Replit compatible)
│   ├── seedAdmin.js          # Admin user seed script
│   ├── middleware/
│   │   └── auth.js           # JWT + API key dual authentication
│   └── routes/
│       ├── auth.js           # Register, login, profile, dashboard stats
│       ├── wallets.js        # Multi-currency wallets + sandbox funding
│       ├── transfers.js      # Bank, mobile money, COBO-to-COBO transfers
│       ├── exchange.js       # FX rates, convert, wallet swap
│       ├── transactions.js   # Transaction history with filters + pagination
│       ├── paymentLinks.js   # No-code payment page creation
│       ├── kyc.js            # KYC document submission
│       ├── notifications.js  # In-app notifications
│       ├── beneficiaries.js  # Saved recipients
│       ├── apiKeys.js        # Developer API key management
│       ├── webhooks.js       # Webhook endpoint management
│       ├── admin.js          # Admin panel (users, KYC review, stats)
│       └── public.js         # Public pay pages + webhook receiver
├── client/                   # React + Vite frontend
│   └── src/
│       ├── pages/            # 12 pages: Dashboard, Wallets, Send, Transactions,
│       │                     #   Exchange, PaymentLinks, Beneficiaries, KYC,
│       │                     #   Notifications, Developer, Admin, Settings
│       ├── components/       # Layout + Sidebar (auto-hides Admin for non-admins)
│       ├── context/          # Auth state management
│       └── lib/              # API client + utilities + currency data
├── data/                     # Auto-created — stores cobo.json (all data)
├── build.sh                  # One-command Replit setup script
├── .env.example              # Environment variable template
└── .replit                   # Replit run configuration
```

---

## 💳 Complete Feature List

### Payments
- ✅ Bank transfer (NG, GH, KE, SN, TG + more via Flutterwave)
- ✅ Mobile Money: MTN MoMo, M-Pesa, Airtel Money, Orange Money, Wave, Moov Money, T-Money, Flooz
- ✅ COBO-to-COBO transfers (free, instant, no fees)
- ✅ Payment Links — shareable public checkout pages at `/pay/:slug`
- ✅ Sandbox mode — all transfers simulated, real mode on with Flutterwave key

### Wallets
- ✅ 15 currencies: USD, NGN, GHS, XOF, XAF, KES, ZAR, EGP, MAD, TZS, UGX, ETB, RWF, EUR, GBP
- ✅ Sandbox wallet funding
- ✅ Add new currency wallets

### FX Exchange
- ✅ 20 currency pair rates (cached, configurable live via exchangerate-api.com)
- ✅ Preview conversion before committing
- ✅ One-click wallet-to-wallet swap at 0.5% fee

### Users & Auth
- ✅ Registration + login with JWT
- ✅ API key authentication (test + live keys)
- ✅ bcrypt password hashing
- ✅ First registered user auto-gets admin role
- ✅ KYC document submission + admin review
- ✅ Beneficiaries (saved recipients)
- ✅ Notifications system

### Developer
- ✅ API key management (test/live, one-time reveal)
- ✅ Webhook endpoint management with HMAC secrets
- ✅ Code examples: Node.js, Python, cURL
- ✅ Full REST API reference in-app

### Admin
- ✅ Platform stats (users, volume, transaction count, pending KYC)
- ✅ User management table
- ✅ KYC document review (approve/reject)
- ✅ All-transactions view
- ✅ Admin nav only shown to admin users

---

## 🔌 Payment Provider Setup

### Flutterwave (recommended for Africa)
1. Sign up at [flutterwave.com](https://flutterwave.com)
2. Get test keys from dashboard
3. Add to Replit Secrets: `FLUTTERWAVE_SECRET_KEY`, `FLUTTERWAVE_PUBLIC_KEY`
4. Set webhook URL in Flutterwave dashboard: `https://your-app.replit.app/api/public/webhook/flutterwave`

### Exchange Rates (live rates)
1. Free key at [exchangerate-api.com](https://www.exchangerate-api.com)
2. Add to Secrets: `EXCHANGE_RATE_API_KEY`
3. Rates auto-refresh hourly; fallback to seeded rates if unavailable

---

## 📡 API Reference

```
Authentication
  POST /api/auth/register        Create account
  POST /api/auth/login           Get JWT token
  GET  /api/auth/me              Current user + wallets
  GET  /api/auth/dashboard       Stats + recent transactions
  PUT  /api/auth/profile         Update profile
  POST /api/auth/change-password Change password

Wallets
  GET  /api/wallets              List all wallets
  POST /api/wallets/add          Add currency wallet
  POST /api/wallets/fund         Fund wallet (sandbox only)

Transfers
  POST /api/transfers/bank           Send to bank account
  POST /api/transfers/mobile-money   Send via mobile money
  POST /api/transfers/internal       Send to COBO user (free)
  GET  /api/transfers/fee            Calculate fee estimate
  GET  /api/transfers/banks/:country List supported banks

Exchange
  GET  /api/exchange/rates       All rates vs USD
  GET  /api/exchange/rate        Rate for currency pair
  POST /api/exchange/convert     Preview conversion
  POST /api/exchange/swap        Execute wallet swap

Transactions
  GET  /api/transactions         List (filters: type, status, currency)
  GET  /api/transactions/:id     Single transaction

Payment Links
  POST /api/payment-links        Create link
  GET  /api/payment-links        List my links
  PATCH /api/payment-links/:id/toggle  Toggle active
  DELETE /api/payment-links/:id  Delete

Public (no auth)
  GET  /api/public/pay/:slug     Get payment link data
  POST /api/public/pay/:slug/charge  Process payment

KYC
  POST /api/kyc/submit           Submit document
  GET  /api/kyc/status           Get KYC status + docs

Beneficiaries
  GET  /api/beneficiaries        List saved recipients
  POST /api/beneficiaries        Add beneficiary
  DELETE /api/beneficiaries/:id  Remove

Developer
  POST /api/api-keys             Create API key
  GET  /api/api-keys             List keys
  DELETE /api/api-keys/:id       Revoke key
  POST /api/webhooks             Create webhook
  GET  /api/webhooks             List webhooks
  DELETE /api/webhooks/:id       Delete webhook

Admin (admin role required)
  GET  /api/admin/stats          Platform statistics
  GET  /api/admin/users          All users
  GET  /api/admin/transactions   All transactions
  PATCH /api/admin/kyc/:docId    Approve/reject KYC doc
  PATCH /api/admin/users/:id/toggle  Activate/deactivate user

System
  GET  /api/health               Health check
```

---

## 🌍 Supported Currencies

| Code | Country/Region |
|------|---------------|
| NGN | Nigeria |
| GHS | Ghana |
| XOF | Senegal, Togo, Côte d'Ivoire, Benin, Burkina Faso, Mali, Niger |
| XAF | Cameroon, Chad, Congo, Gabon |
| KES | Kenya |
| ZAR | South Africa |
| EGP | Egypt |
| MAD | Morocco |
| TZS | Tanzania |
| UGX | Uganda |
| ETB | Ethiopia |
| RWF | Rwanda |
| USD | United States (global) |
| EUR | Eurozone |
| GBP | United Kingdom |

---

Built with ❤️ for Africa by **ARGILETTE LLC**  
Platform: COBO Payment Infrastructure v1.0
