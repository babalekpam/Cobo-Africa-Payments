import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import { AuthProvider } from './context/AuthContext'
import App from './App'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <BrowserRouter>
    <AuthProvider>
      <App />
      <Toaster position="top-right" toastOptions={{
        style: { background: '#2E2B1F', color: '#F0E8D5', border: '1px solid rgba(255,255,255,0.06)', fontFamily: 'DM Sans, sans-serif', fontSize: '14px' },
        success: { iconTheme: { primary: '#3DD68C', secondary: '#0D0B07' } },
        error: { iconTheme: { primary: '#F55353', secondary: '#0D0B07' } },
      }} />
    </AuthProvider>
  </BrowserRouter>
)
