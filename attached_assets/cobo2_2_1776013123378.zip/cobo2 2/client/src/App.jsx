import { Routes, Route, Navigate } from 'react-router-dom'
import { useAuth } from './context/AuthContext'
import Layout from './components/Layout'
import Login from './pages/Login'
import Register from './pages/Register'
import Dashboard from './pages/Dashboard'
import Wallets from './pages/Wallets'
import Send from './pages/Send'
import Transactions from './pages/Transactions'
import Exchange from './pages/Exchange'
import PaymentLinks from './pages/PaymentLinks'
import Settings from './pages/Settings'
import Developer from './pages/Developer'
import PayPage from './pages/PayPage'
import KYC from './pages/KYC'
import Notifications from './pages/Notifications'
import Beneficiaries from './pages/Beneficiaries'
import Admin from './pages/Admin'

function PrivateRoute({ children }) {
  const { user, loading } = useAuth()
  if (loading) return (
    <div style={{ minHeight:'100vh', display:'flex', alignItems:'center', justifyContent:'center', background:'var(--dark)' }}>
      <div style={{ textAlign:'center' }}>
        <div style={{ fontFamily:'Syne,sans-serif', fontWeight:800, fontSize:24, color:'var(--gold)', marginBottom:8 }}>🌍 COBO</div>
        <div className="spinner" style={{ margin:'0 auto' }} />
      </div>
    </div>
  )
  return user ? children : <Navigate to="/login" replace />
}

function PublicRoute({ children }) {
  const { user, loading } = useAuth()
  if (loading) return null
  return user ? <Navigate to="/dashboard" replace /> : children
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<PublicRoute><Login /></PublicRoute>} />
      <Route path="/register" element={<PublicRoute><Register /></PublicRoute>} />
      <Route path="/pay/:slug" element={<PayPage />} />
      <Route path="/" element={<PrivateRoute><Layout /></PrivateRoute>}>
        <Route index element={<Navigate to="/dashboard" replace />} />
        <Route path="dashboard" element={<Dashboard />} />
        <Route path="wallets" element={<Wallets />} />
        <Route path="send" element={<Send />} />
        <Route path="transactions" element={<Transactions />} />
        <Route path="exchange" element={<Exchange />} />
        <Route path="payment-links" element={<PaymentLinks />} />
        <Route path="beneficiaries" element={<Beneficiaries />} />
        <Route path="kyc" element={<KYC />} />
        <Route path="notifications" element={<Notifications />} />
        <Route path="developer" element={<Developer />} />
        <Route path="admin" element={<Admin />} />
        <Route path="settings" element={<Settings />} />
      </Route>
      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  )
}
