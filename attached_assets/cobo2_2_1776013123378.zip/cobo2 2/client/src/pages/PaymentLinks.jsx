import { useEffect, useState } from 'react'
import api from '../lib/api'
import { fmt, getCurrencyFlag, CURRENCIES } from '../lib/utils'
import toast from 'react-hot-toast'

export default function PaymentLinks() {
  const [links, setLinks] = useState([])
  const [loading, setLoading] = useState(true)
  const [creating, setCreating] = useState(false)
  const [form, setForm] = useState({ title: '', description: '', amount: '', currency: 'USD', is_fixed_amount: true, redirect_url: '' })
  const [saving, setSaving] = useState(false)
  const set = (k, v) => setForm(p => ({ ...p, [k]: v }))

  const load = async () => {
    setLoading(true)
    try { const r = await api.get('/payment-links'); setLinks(r.data.payment_links || []) } catch {} finally { setLoading(false) }
  }

  useEffect(() => { load() }, [])

  const create = async e => {
    e.preventDefault()
    if (!form.title || !form.currency) return toast.error('Fill required fields')
    setSaving(true)
    try {
      await api.post('/payment-links', { ...form, amount: form.amount ? Number(form.amount) : null })
      await load()
      toast.success('Payment link created!')
      setCreating(false)
      setForm({ title: '', description: '', amount: '', currency: 'USD', is_fixed_amount: true, redirect_url: '' })
    } catch (err) { toast.error(err.response?.data?.message || 'Failed') }
    finally { setSaving(false) }
  }

  const toggle = async id => {
    try { await api.patch(`/payment-links/${id}/toggle`); await load() } catch { toast.error('Failed') }
  }

  const del = async id => {
    if (!confirm('Delete this payment link?')) return
    try { await api.delete(`/payment-links/${id}`); await load(); toast.success('Deleted') } catch { toast.error('Failed') }
  }

  const copy = slug => {
    const url = `${window.location.origin}/pay/${slug}`
    navigator.clipboard?.writeText(url)
    toast.success('Link copied!')
  }

  return (
    <div className="page fade-in">
      <div className="page-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <h1 className="page-title">Payment Links</h1>
          <p className="page-subtitle">Create no-code payment pages to collect money from anyone</p>
        </div>
        <button className="btn btn-primary" onClick={() => setCreating(true)}>+ New Link</button>
      </div>

      {loading ? <div style={{ display: 'flex', gap: 10, color: 'var(--text-dim)' }}><span className="spinner" /> Loading...</div> : (
        <>
          {links.length === 0 && !creating && (
            <div className="empty card" style={{ marginTop: 20 }}>
              <div className="empty-icon">⬡</div>
              <div className="empty-title">No payment links yet</div>
              <div className="empty-desc">Create shareable payment pages to collect money from customers worldwide</div>
              <button className="btn btn-primary" style={{ marginTop: 8 }} onClick={() => setCreating(true)}>Create first link</button>
            </div>
          )}

          <div className="grid-2" style={{ gap: 16 }}>
            {links.map(l => (
              <div key={l.id} className="card">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
                  <div>
                    <div style={{ fontWeight: 600, fontSize: '15px', marginBottom: 2 }}>{l.title}</div>
                    {l.description && <div style={{ fontSize: '13px', color: 'var(--text-dim)' }}>{l.description}</div>}
                  </div>
                  <span className={`badge ${l.is_active ? 'badge-success' : 'badge-dim'}`}>{l.is_active ? 'Active' : 'Inactive'}</span>
                </div>
                <div style={{ display: 'flex', gap: 16, marginBottom: 14 }}>
                  <div>
                    <div style={{ fontSize: '11px', color: 'var(--text-dim)' }}>Amount</div>
                    <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, color: 'var(--gold)' }}>
                      {l.is_fixed_amount && l.amount ? fmt(l.amount, l.currency) : 'Customer sets amount'} <span style={{ fontSize: '11px', color: 'var(--text-dim)', fontFamily: 'DM Sans, sans-serif', fontWeight: 400 }}>{l.currency}</span>
                    </div>
                  </div>
                  <div>
                    <div style={{ fontSize: '11px', color: 'var(--text-dim)' }}>Collected</div>
                    <div style={{ fontWeight: 600 }}>{fmt(l.total_collected, l.currency)} ({l.payment_count} payments)</div>
                  </div>
                </div>
                <div style={{ background: 'var(--surface2)', borderRadius: 'var(--radius-sm)', padding: '8px 12px', fontSize: '12px', color: 'var(--text-dim)', fontFamily: 'monospace', marginBottom: 14, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {window.location.origin}/pay/{l.slug}
                </div>
                <div style={{ display: 'flex', gap: 8 }}>
                  <button className="btn btn-primary btn-sm" style={{ flex: 1 }} onClick={() => copy(l.slug)}>📋 Copy Link</button>
                  <button className="btn btn-ghost btn-sm" onClick={() => toggle(l.id)}>{l.is_active ? 'Pause' : 'Activate'}</button>
                  <button className="btn btn-danger btn-sm" onClick={() => del(l.id)}>✕</button>
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      {/* Create modal */}
      {creating && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 200, padding: 20 }} onClick={() => setCreating(false)}>
          <div className="card-lg" style={{ width: '100%', maxWidth: 480 }} onClick={e => e.stopPropagation()}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
              <h3 style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: '18px' }}>Create Payment Link</h3>
              <button onClick={() => setCreating(false)} style={{ background: 'none', border: 'none', color: 'var(--text-dim)', cursor: 'pointer', fontSize: '18px' }}>✕</button>
            </div>
            <form onSubmit={create} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              <div className="input-group"><label className="input-label">Title *</label><input className="input" placeholder="Invoice #1234" value={form.title} onChange={e => set('title', e.target.value)} required /></div>
              <div className="input-group"><label className="input-label">Description</label><input className="input" placeholder="Payment for web design services" value={form.description} onChange={e => set('description', e.target.value)} /></div>
              <div className="grid-2">
                <div className="input-group">
                  <label className="input-label">Currency *</label>
                  <select className="select" value={form.currency} onChange={e => set('currency', e.target.value)}>
                    {Object.entries(CURRENCIES).map(([c, d]) => <option key={c} value={c}>{d.flag} {c}</option>)}
                  </select>
                </div>
                <div className="input-group">
                  <label className="input-label">Amount type</label>
                  <select className="select" value={form.is_fixed_amount ? 'fixed' : 'open'} onChange={e => set('is_fixed_amount', e.target.value === 'fixed')}>
                    <option value="fixed">Fixed amount</option>
                    <option value="open">Customer enters</option>
                  </select>
                </div>
              </div>
              {form.is_fixed_amount && (
                <div className="input-group"><label className="input-label">Amount</label><input className="input" type="number" placeholder="100" value={form.amount} onChange={e => set('amount', e.target.value)} min="0.01" step="any" /></div>
              )}
              <div className="input-group"><label className="input-label">Redirect URL after payment</label><input className="input" type="url" placeholder="https://yoursite.com/thank-you" value={form.redirect_url} onChange={e => set('redirect_url', e.target.value)} /></div>
              <div style={{ display: 'flex', gap: 10, marginTop: 8 }}>
                <button type="button" className="btn btn-ghost btn-full" onClick={() => setCreating(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary btn-full" disabled={saving}>{saving ? <span className="spinner" /> : 'Create Link'}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
