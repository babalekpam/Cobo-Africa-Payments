import { useState } from 'react'
import { useAuth } from '../context/AuthContext'
import { fmt, getCurrencyFlag, CURRENCIES } from '../lib/utils'
import api from '../lib/api'
import toast from 'react-hot-toast'

export default function Wallets() {
  const { wallets, refreshWallets } = useAuth()
  const [adding, setAdding] = useState(false)
  const [newCur, setNewCur] = useState('XOF')
  const [funding, setFunding] = useState(null)
  const [fundAmt, setFundAmt] = useState('')
  const [loading, setLoading] = useState(false)

  const available = Object.keys(CURRENCIES).filter(c => !wallets.find(w => w.currency === c))

  const addWallet = async () => {
    setLoading(true)
    try {
      await api.post('/wallets/add', { currency: newCur })
      await refreshWallets()
      toast.success(`${newCur} wallet created`)
      setAdding(false)
    } catch (err) { toast.error(err.response?.data?.message || 'Failed') }
    finally { setLoading(false) }
  }

  const fundWallet = async () => {
    if (!fundAmt || fundAmt <= 0) return toast.error('Enter a valid amount')
    setLoading(true)
    try {
      await api.post('/wallets/fund', { currency: funding, amount: Number(fundAmt) })
      await refreshWallets()
      toast.success(`${funding} ${fundAmt} added (sandbox)`)
      setFunding(null); setFundAmt('')
    } catch (err) { toast.error(err.response?.data?.message || 'Failed') }
    finally { setLoading(false) }
  }

  return (
    <div className="page fade-in">
      <div className="page-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <h1 className="page-title">My Wallets</h1>
          <p className="page-subtitle">Multi-currency balances across Africa & beyond</p>
        </div>
        <button className="btn btn-primary" onClick={() => setAdding(true)}>+ Add Currency</button>
      </div>

      <div className="grid-3">
        {wallets.map(w => (
          <div key={w.id} className="card" style={{ position: 'relative', overflow: 'hidden' }}>
            <div style={{ position: 'absolute', top: 0, right: 0, width: 80, height: 80, background: 'radial-gradient(circle, rgba(232,169,64,0.05) 0%, transparent 70%)', pointerEvents: 'none' }} />
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
              <span style={{ fontSize: 32 }}>{getCurrencyFlag(w.currency)}</span>
              {w.is_default === 1 && <span className="badge badge-warning" style={{ fontSize: '10px' }}>Default</span>}
            </div>
            <div style={{ fontFamily: 'Syne, sans-serif', fontSize: '11px', fontWeight: 600, color: 'var(--text-dim)', letterSpacing: '1px', textTransform: 'uppercase', marginBottom: 6 }}>{CURRENCIES[w.currency]?.name || w.currency}</div>
            <div style={{ fontFamily: 'Syne, sans-serif', fontSize: '28px', fontWeight: 800, letterSpacing: '-1.5px', color: w.balance > 0 ? 'var(--text)' : 'var(--text-faint)', marginBottom: 4 }}>
              {fmt(w.balance, w.currency)}
            </div>
            {w.locked_balance > 0 && (
              <div style={{ fontSize: '12px', color: 'var(--text-dim)' }}>🔒 {fmt(w.locked_balance, w.currency)} locked</div>
            )}
            <div className="divider" style={{ margin: '14px 0' }} />
            <div style={{ display: 'flex', gap: 8 }}>
              <button className="btn btn-ghost btn-sm" style={{ flex: 1 }} onClick={() => { setFunding(w.currency); setFundAmt('') }}>+ Fund</button>
              <button className="btn btn-ghost btn-sm" style={{ flex: 1 }}>History</button>
            </div>
          </div>
        ))}
      </div>

      {/* Add currency modal */}
      {adding && (
        <Modal title="Add Currency Wallet" onClose={() => setAdding(false)}>
          <div className="input-group" style={{ marginBottom: 20 }}>
            <label className="input-label">Select currency</label>
            <select className="select" value={newCur} onChange={e => setNewCur(e.target.value)}>
              {available.map(c => <option key={c} value={c}>{getCurrencyFlag(c)} {c} — {CURRENCIES[c]?.name}</option>)}
            </select>
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <button className="btn btn-ghost btn-full" onClick={() => setAdding(false)}>Cancel</button>
            <button className="btn btn-primary btn-full" onClick={addWallet} disabled={loading}>{loading ? <span className="spinner" /> : 'Create Wallet'}</button>
          </div>
        </Modal>
      )}

      {/* Fund modal */}
      {funding && (
        <Modal title={`Fund ${funding} Wallet (Sandbox)`} onClose={() => setFunding(null)}>
          <div style={{ background: 'rgba(232,169,64,0.06)', border: '1px solid var(--border-gold)', borderRadius: 'var(--radius-sm)', padding: '10px 14px', marginBottom: 16, fontSize: '13px', color: 'var(--text-dim)' }}>
            ⚠️ Sandbox mode — funds are simulated for testing
          </div>
          <div className="input-group" style={{ marginBottom: 20 }}>
            <label className="input-label">Amount ({funding})</label>
            <input className="input" type="number" placeholder="1000" value={fundAmt} onChange={e => setFundAmt(e.target.value)} min="1" max="100000" />
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <button className="btn btn-ghost btn-full" onClick={() => setFunding(null)}>Cancel</button>
            <button className="btn btn-primary btn-full" onClick={fundWallet} disabled={loading}>{loading ? <span className="spinner" /> : 'Add Funds'}</button>
          </div>
        </Modal>
      )}
    </div>
  )
}

function Modal({ title, children, onClose }) {
  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 200, padding: 20 }} onClick={onClose}>
      <div className="card-lg" style={{ width: '100%', maxWidth: 420, position: 'relative' }} onClick={e => e.stopPropagation()}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
          <h3 style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: '18px' }}>{title}</h3>
          <button onClick={onClose} style={{ background: 'none', border: 'none', color: 'var(--text-dim)', cursor: 'pointer', fontSize: '18px' }}>✕</button>
        </div>
        {children}
      </div>
    </div>
  )
}
