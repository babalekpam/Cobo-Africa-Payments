import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import api from '../lib/api'
import { fmt, CURRENCIES, getCurrencyFlag } from '../lib/utils'
import toast from 'react-hot-toast'

export default function PayPage() {
  const { slug } = useParams()
  const [link, setLink] = useState(null)
  const [loading, setLoading] = useState(true)
  const [paying, setPaying] = useState(false)
  const [done, setDone] = useState(false)
  const [form, setForm] = useState({ name: '', email: '', amount: '' })
  const set = (k, v) => setForm(p => ({ ...p, [k]: v }))

  useEffect(() => {
    api.get(`/public/pay/${slug}`)
      .then(r => setLink(r.data.payment_link))
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [slug])

  const pay = async e => {
    e.preventDefault()
    if (!form.email) return toast.error('Email required')
    const amount = link.is_fixed_amount ? link.amount : Number(form.amount)
    if (!amount || amount <= 0) return toast.error('Enter a valid amount')
    setPaying(true)
    try {
      await api.post(`/public/pay/${slug}/charge`, { ...form, amount, currency: link.currency })
      setDone(true)
      toast.success('Payment successful!')
    } catch (err) { toast.error(err.response?.data?.message || 'Payment failed') }
    finally { setPaying(false) }
  }

  if (loading) return (
    <div style={{ minHeight: '100vh', background: 'var(--dark)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{ textAlign: 'center' }}>
        <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: '24px', color: 'var(--gold)', marginBottom: 8 }}>🌍 COBO</div>
        <span className="spinner" style={{ margin: '0 auto' }} />
      </div>
    </div>
  )

  if (!link) return (
    <div style={{ minHeight: '100vh', background: 'var(--dark)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div className="card-lg" style={{ textAlign: 'center', maxWidth: 380 }}>
        <div style={{ fontSize: 48, marginBottom: 12 }}>❌</div>
        <h2 style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700 }}>Link Not Found</h2>
        <p style={{ color: 'var(--text-dim)', marginTop: 8, fontSize: '14px' }}>This payment link is invalid or has been deactivated.</p>
      </div>
    </div>
  )

  if (done) return (
    <div style={{ minHeight: '100vh', background: 'var(--dark)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div className="card-lg" style={{ textAlign: 'center', maxWidth: 400 }}>
        <div style={{ fontSize: 64, marginBottom: 16 }}>✅</div>
        <h2 style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: '24px', marginBottom: 8 }}>Payment Successful!</h2>
        <p style={{ color: 'var(--text-dim)', fontSize: '14px' }}>Thank you. Your payment has been received and confirmed.</p>
        {link.redirect_url && (
          <a href={link.redirect_url} className="btn btn-primary btn-lg" style={{ marginTop: 24, display: 'inline-flex' }}>Continue →</a>
        )}
        <div style={{ marginTop: 32, fontSize: '12px', color: 'var(--text-faint)' }}>Secured by 🌍 COBO</div>
      </div>
    </div>
  )

  return (
    <div style={{ minHeight: '100vh', background: 'var(--dark)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
      <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at 50% 40%, rgba(232,169,64,0.05) 0%, transparent 65%)', pointerEvents: 'none' }} />
      <div style={{ width: '100%', maxWidth: 420, position: 'relative' }}>
        {/* Merchant header */}
        <div style={{ textAlign: 'center', marginBottom: 28 }}>
          <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: '14px', color: 'var(--text-dim)', letterSpacing: '2px', textTransform: 'uppercase', marginBottom: 8 }}>Payment Request</div>
          <div style={{ fontWeight: 600, fontSize: '16px', color: 'var(--text)' }}>{link.business_name || `${link.first_name} ${link.last_name}`}</div>
        </div>

        <div className="card-lg">
          {/* Amount display */}
          <div style={{ textAlign: 'center', padding: '20px 0 24px', borderBottom: '1px solid var(--border)', marginBottom: 24 }}>
            <div style={{ fontSize: 36, marginBottom: 8 }}>{getCurrencyFlag(link.currency)}</div>
            <h1 style={{ fontFamily: 'Syne, sans-serif', fontSize: '28px', fontWeight: 800, marginBottom: 6 }}>{link.title}</h1>
            {link.description && <p style={{ color: 'var(--text-dim)', fontSize: '14px', marginBottom: 14 }}>{link.description}</p>}
            {link.is_fixed_amount && link.amount && (
              <div style={{ fontFamily: 'Syne, sans-serif', fontSize: '42px', fontWeight: 800, color: 'var(--gold)', letterSpacing: '-2px' }}>
                {fmt(link.amount, link.currency)}
              </div>
            )}
          </div>

          <form onSubmit={pay} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div className="input-group"><label className="input-label">Full Name</label><input className="input" placeholder="Amara Diallo" value={form.name} onChange={e => set('name', e.target.value)} /></div>
            <div className="input-group"><label className="input-label">Email *</label><input className="input" type="email" placeholder="you@example.com" value={form.email} onChange={e => set('email', e.target.value)} required /></div>
            {!link.is_fixed_amount && (
              <div className="input-group">
                <label className="input-label">Amount ({link.currency})</label>
                <input className="input" type="number" placeholder="0.00" value={form.amount} onChange={e => set('amount', e.target.value)} min="0.01" step="any" required />
              </div>
            )}

            <button className="btn btn-primary btn-full btn-lg" type="submit" disabled={paying} style={{ marginTop: 8 }}>
              {paying ? <><span className="spinner" /> Processing...</> : `Pay ${link.is_fixed_amount && link.amount ? fmt(link.amount, link.currency) : ''}`}
            </button>
          </form>
        </div>

        <div style={{ textAlign: 'center', marginTop: 20, fontSize: '12px', color: 'var(--text-faint)' }}>
          🔒 Payments secured by <strong style={{ color: 'var(--gold)' }}>COBO</strong> · Africa's Unified Payment Infrastructure
        </div>
      </div>
    </div>
  )
}
