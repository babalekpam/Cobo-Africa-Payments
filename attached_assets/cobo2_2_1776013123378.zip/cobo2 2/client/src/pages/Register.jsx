// Register redirects to Login (which has register mode built in)
import { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
export default function Register() {
  const nav = useNavigate()
  useEffect(() => { nav('/login') }, [])
  return null
}
