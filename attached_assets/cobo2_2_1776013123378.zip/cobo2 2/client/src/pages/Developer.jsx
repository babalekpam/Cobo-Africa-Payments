import { useEffect, useState } from 'react'
import api from '../lib/api'
import toast from 'react-hot-toast'
import { fmtDate, copyToClipboard } from '../lib/utils'

export default function Developer() {
  const [keys, setKeys] = useState([])
  const [webhooks, setWebhooks] = useState([])
  const [newKeyName, setNewKeyName] = useState('')
  const [newKeyLive, setNewKeyLive] = useState(false)
  const [newWHUrl, setNewWHUrl] = useState('')
  const [newWHEvents, setNewWHEvents] = useState('payment.success,payment.failed')
  const [revealedKey, setRevealedKey] = useState(null)
  const [loading, setLoading] = useState(false)

  const loadAll = async () => {
    const [k, w] = await Promise.all([api.get('/api-keys'), api.get('/webhooks')])
    setKeys(k.data.api_keys || [])
    setWebhooks(w.data.webhooks || [])
  }

  useEffect(() => { loadAll() }, [])

  const createKey = async () => {
    if (!newKeyName.trim()) return toast.error('Enter a key name')
    setLoading(true)
    try {
      const r = await api.post('/api-keys', { name: newKeyName, is_live: newKeyLive })
      setRevealedKey(r.data.key)
      setNewKeyName('')
      await loadAll()
      toast.success('API key created — save it now!')
    } catch (err) { toast.error(err.response?.data?.message || 'Failed') }
    finally { setLoading(false) }
  }

  const revokeKey = async (id) => {
    if (!confirm('Revoke this API key? This cannot be undone.')) return
    try { await api.delete(`/api-keys/${id}`); await loadAll(); toast.success('Key revoked') } catch { toast.error('Failed') }
  }

  const createWebhook = async () => {
    if (!newWHUrl) return toast.error('Enter webhook URL')
    try {
      await api.post('/webhooks', { url: newWHUrl, events: newWHEvents })
      await loadAll(); setNewWHUrl(''); toast.success('Webhook created')
    } catch { toast.error('Failed') }
  }

  const deleteWH = async (id) => {
    try { await api.delete(`/webhooks/${id}`); await loadAll(); toast.success('Webhook deleted') } catch { toast.error('Failed') }
  }

  const CODE_EXAMPLES = {
    node: `const axios = require('axios')

const cobo = axios.create({
  baseURL: 'https://your-cobo-app.replit.app/api',
  headers: { 'X-API-Key': 'ck_test_your_key_here' }
})

// Check balance
const { data } = await cobo.get('/wallets')
console.log(data.wallets)

// Send money
await cobo.post('/transfers/bank', {
  currency: 'NGN',
  amount: 50000,
  account_number: '0123456789',
  account_name: 'Amara Diallo',
  bank_code: '058',
  country: 'NG',
  description: 'Freelance payment'
})

// Swap currencies  
await cobo.post('/exchange/swap', {
  from_currency: 'USD',
  to_currency: 'NGN',
  amount: 100
})`,
    python: `import requests

BASE = 'https://your-cobo-app.replit.app/api'
HEADERS = {'X-API-Key': 'ck_test_your_key_here'}

# List wallets
r = requests.get(f'{BASE}/wallets', headers=HEADERS)
print(r.json()['wallets'])

# Send via mobile money
r = requests.post(f'{BASE}/transfers/mobile-money', 
  headers=HEADERS,
  json={
    'currency': 'GHS',
    'amount': 200,
    'phone': '+233244000000',
    'provider': 'mtn_momo',
    'country': 'GH',
    'recipient_name': 'Kwame Asante'
  }
)
print(r.json())

# Create payment link
r = requests.post(f'{BASE}/payment-links',
  headers=HEADERS,
  json={
    'title': 'Product Payment',
    'amount': 50,
    'currency': 'USD',
    'is_fixed_amount': True
  }
)
print(r.json()['url'])`,
    curl: `# List wallets
curl https://your-cobo-app.replit.app/api/wallets \\
  -H "X-API-Key: ck_test_your_key_here"

# Get exchange rate
curl "https://your-cobo-app.replit.app/api/exchange/rate?from=USD&to=NGN" \\
  -H "X-API-Key: ck_test_your_key_here"

# Send to bank
curl -X POST https://your-cobo-app.replit.app/api/transfers/bank \\
  -H "X-API-Key: ck_test_your_key_here" \\
  -H "Content-Type: application/json" \\
  -d '{
    "currency": "NGN",
    "amount": 50000,
    "account_number": "0123456789",
    "account_name": "John Doe",
    "bank_code": "058",
    "country": "NG"
  }'`
  }

  const [codeLang, setCodeLang] = useState('node')

  return (
    <div className="page fade-in">
      <div className="page-header">
        <h1 className="page-title">Developer</h1>
        <p className="page-subtitle">API keys, webhooks, and integration guides</p>
      </div>

      {/* Revealed key alert */}
      {revealedKey && (
        <div style={{ background: 'rgba(61,214,140,0.08)', border: '1px solid rgba(61,214,140,0.3)', borderRadius: 'var(--radius)', padding: '16px 20px', marginBottom: 24, display: 'flex', gap: 16, alignItems: 'flex-start' }}>
          <span style={{ fontSize: 24 }}>🔑</span>
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 600, color: 'var(--green)', marginBottom: 8 }}>Save your API key — shown only once!</div>
            <div style={{ fontFamily: 'monospace', fontSize: '13px', background: 'var(--surface2)', padding: '10px 14px', borderRadius: 'var(--radius-sm)', wordBreak: 'break-all', color: 'var(--text)', marginBottom: 10 }}>{revealedKey}</div>
            <button className="btn btn-primary btn-sm" onClick={() => { copyToClipboard(revealedKey); toast.success('Copied!') }}>📋 Copy Key</button>
          </div>
          <button onClick={() => setRevealedKey(null)} style={{ background: 'none', border: 'none', color: 'var(--text-dim)', cursor: 'pointer', fontSize: '18px' }}>✕</button>
        </div>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
        {/* API Keys */}
        <div>
          <div className="card">
            <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: '16px', marginBottom: 20 }}>API Keys</div>
            
            <div style={{ display: 'flex', gap: 10, marginBottom: 20 }}>
              <input className="input" placeholder="Key name (e.g. Production App)" value={newKeyName} onChange={e => setNewKeyName(e.target.value)} style={{ flex: 1 }} />
              <select className="select" style={{ width: 100 }} value={newKeyLive ? 'live' : 'test'} onChange={e => setNewKeyLive(e.target.value === 'live')}>
                <option value="test">Test</option>
                <option value="live">Live</option>
              </select>
              <button className="btn btn-primary btn-sm" onClick={createKey} disabled={loading}>
                {loading ? <span className="spinner" style={{ width: 14, height: 14 }} /> : '+ Create'}
              </button>
            </div>

            {keys.length === 0 ? (
              <div className="empty" style={{ padding: '30px 0' }}>
                <div className="empty-icon" style={{ fontSize: 28 }}>🔑</div>
                <div className="empty-desc">No API keys yet. Create one above.</div>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {keys.map(k => (
                  <div key={k.id} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 14px', background: 'var(--surface2)', borderRadius: 'var(--radius-sm)' }}>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontWeight: 600, fontSize: '14px', marginBottom: 2 }}>{k.name}</div>
                      <div style={{ fontFamily: 'monospace', fontSize: '12px', color: 'var(--text-dim)' }}>{k.key_prefix}••••••••</div>
                    </div>
                    <span className={`badge ${k.is_live ? 'badge-success' : 'badge-info'}`}>{k.is_live ? 'Live' : 'Test'}</span>
                    <button className="btn btn-danger btn-sm" onClick={() => revokeKey(k.id)}>Revoke</button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Webhooks */}
        <div>
          <div className="card">
            <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: '16px', marginBottom: 20 }}>Webhooks</div>
            
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 20 }}>
              <input className="input" type="url" placeholder="https://yoursite.com/webhook" value={newWHUrl} onChange={e => setNewWHUrl(e.target.value)} />
              <input className="input" placeholder="Events (comma-separated)" value={newWHEvents} onChange={e => setNewWHEvents(e.target.value)} />
              <button className="btn btn-primary btn-sm" style={{ alignSelf: 'flex-start' }} onClick={createWebhook}>+ Add Webhook</button>
            </div>

            <div style={{ fontSize: '12px', color: 'var(--text-dim)', marginBottom: 14 }}>
              <strong style={{ color: 'var(--text)' }}>Available events:</strong> payment.success, payment.failed, kyc.approved, kyc.rejected, transfer.success, transfer.failed
            </div>

            {webhooks.length === 0 ? (
              <div className="empty" style={{ padding: '30px 0' }}>
                <div className="empty-icon" style={{ fontSize: 28 }}>⚡</div>
                <div className="empty-desc">No webhooks yet.</div>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {webhooks.map(w => (
                  <div key={w.id} style={{ padding: '12px 14px', background: 'var(--surface2)', borderRadius: 'var(--radius-sm)' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                      <span style={{ fontFamily: 'monospace', fontSize: '12px', color: 'var(--text)', wordBreak: 'break-all', flex: 1 }}>{w.url}</span>
                      <button className="btn btn-danger btn-sm" style={{ marginLeft: 8, flexShrink: 0 }} onClick={() => deleteWH(w.id)}>✕</button>
                    </div>
                    <div style={{ fontSize: '11px', color: 'var(--text-dim)' }}>{w.events}</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Code Examples */}
      <div className="card" style={{ marginTop: 24 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
          <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: '16px' }}>Integration Examples</div>
          <div style={{ display: 'flex', gap: 4, background: 'var(--surface2)', borderRadius: 'var(--radius-sm)', padding: 4 }}>
            {Object.keys(CODE_EXAMPLES).map(lang => (
              <button key={lang} onClick={() => setCodeLang(lang)} style={{ padding: '6px 14px', borderRadius: 6, border: 'none', cursor: 'pointer', fontFamily: 'DM Sans, sans-serif', fontSize: '13px', fontWeight: codeLang === lang ? 600 : 400, background: codeLang === lang ? 'var(--surface3)' : 'transparent', color: codeLang === lang ? 'var(--text)' : 'var(--text-dim)', transition: 'all 0.15s' }}>
                {lang === 'node' ? 'Node.js' : lang === 'python' ? 'Python' : 'cURL'}
              </button>
            ))}
          </div>
        </div>
        <pre style={{ background: 'var(--dark)', border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)', padding: '20px 24px', overflow: 'auto', fontSize: '13px', lineHeight: 1.7, color: 'var(--text-dim)', fontFamily: 'monospace', maxHeight: 400 }}>
          <code style={{ color: 'var(--text)' }}>{CODE_EXAMPLES[codeLang]}</code>
        </pre>
        <button className="btn btn-ghost btn-sm" style={{ marginTop: 12 }} onClick={() => { copyToClipboard(CODE_EXAMPLES[codeLang]); toast.success('Copied!') }}>📋 Copy Code</button>
      </div>

      {/* API Reference */}
      <div className="card" style={{ marginTop: 24 }}>
        <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: '16px', marginBottom: 20 }}>API Reference</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          {[
            { method: 'GET', path: '/api/wallets', desc: 'List all wallets with balances' },
            { method: 'POST', path: '/api/wallets/add', desc: 'Add new currency wallet' },
            { method: 'POST', path: '/api/wallets/fund', desc: 'Fund wallet (sandbox)' },
            { method: 'POST', path: '/api/transfers/bank', desc: 'Send to bank account' },
            { method: 'POST', path: '/api/transfers/mobile-money', desc: 'Send via mobile money' },
            { method: 'POST', path: '/api/transfers/internal', desc: 'Send to COBO user (free)' },
            { method: 'GET', path: '/api/exchange/rates', desc: 'Get all rates vs USD' },
            { method: 'POST', path: '/api/exchange/convert', desc: 'Preview currency conversion' },
            { method: 'POST', path: '/api/exchange/swap', desc: 'Execute wallet-to-wallet swap' },
            { method: 'GET', path: '/api/transactions', desc: 'List transactions with filters' },
            { method: 'POST', path: '/api/payment-links', desc: 'Create payment link' },
            { method: 'GET', path: '/api/public/pay/:slug', desc: 'Get payment link (public)' },
          ].map(e => (
            <div key={e.path} style={{ display: 'flex', gap: 10, alignItems: 'flex-start', padding: '10px 12px', background: 'var(--surface2)', borderRadius: 'var(--radius-sm)' }}>
              <span style={{ background: e.method === 'GET' ? 'var(--blue-bg)' : 'rgba(232,169,64,0.1)', color: e.method === 'GET' ? 'var(--blue)' : 'var(--gold)', fontSize: '10px', fontWeight: 700, padding: '3px 7px', borderRadius: 4, fontFamily: 'monospace', flexShrink: 0, marginTop: 1 }}>{e.method}</span>
              <div>
                <div style={{ fontFamily: 'monospace', fontSize: '13px', color: 'var(--text)' }}>{e.path}</div>
                <div style={{ fontSize: '12px', color: 'var(--text-dim)', marginTop: 2 }}>{e.desc}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
