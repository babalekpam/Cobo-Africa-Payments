import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts'
import api from '../lib/api'
import { useAuth } from '../context/AuthContext'
import { fmt, fmtDate, txSign, txColor, statusBadge, getCurrencyFlag } from '../lib/utils'

export default function Dashboard() {
  const { user, wallets } = useAuth()
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    api.get('/auth/dashboard').then(r => { setData(r.data); setLoading(false) }).catch(() => setLoading(false))
  }, [])

  const chartData = (data?.monthly_volume || []).reverse().map(m => ({
    month: m.month?.slice(5) || '',
    volume: Number((m.volume || 0).toFixed(2)),
    count: m.count
  }))

  if (loading) return <div className="page" style={{ display: 'flex', alignItems: 'center', gap: 12 }}><span className="spinner" /> Loading dashboard...</div>

  const totalBalance = wallets.reduce((sum, w) => sum + (w.currency === 'USD' ? w.balance : 0), 0)

  return (
    <div className="page fade-in">
      <div className="page-header" style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
        <div>
          <h1 className="page-title">Good {getGreeting()}, {user?.first_name}! 👋</h1>
          <p className="page-subtitle">Here's your financial overview</p>
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <Link to="/send" className="btn btn-primary btn-sm">↑ Send</Link>
          <Link to="/exchange" className="btn btn-ghost btn-sm">⇄ Swap</Link>
        </div>
      </div>

      {/* KYC Banner */}
      {user?.kyc_status !== 'verified' && (
        <div style={{ background: 'rgba(232,169,64,0.08)', border: '1px solid var(--border-gold)', borderRadius: 'var(--radius)', padding: '14px 20px', marginBottom: 24, display: 'flex', alignItems: 'center', gap: 12 }}>
          <span style={{ fontSize: 20 }}>⚠️</span>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: '14px', fontWeight: 600, color: 'var(--gold)' }}>Complete your verification</div>
            <div style={{ fontSize: '13px', color: 'var(--text-dim)' }}>Verify your identity to unlock full send/receive limits and live payments.</div>
          </div>
          <Link to="/kyc" className="btn btn-sm" style={{ background: 'var(--gold)', color: 'var(--dark)', fontWeight: 600 }}>Verify Now</Link>
        </div>
      )}

      {/* Stats row */}
      <div className="grid-4" style={{ marginBottom: 24 }}>
        <div className="stat-card">
          <div className="stat-card-icon">💰</div>
          <div className="stat-card-label">Total USD Balance</div>
          <div className="stat-card-value" style={{ color: 'var(--gold)' }}>{fmt(totalBalance, 'USD')}</div>
          <div className="stat-card-sub">{wallets.length} wallet{wallets.length !== 1 ? 's' : ''} active</div>
        </div>
        <div className="stat-card">
          <div className="stat-card-icon">📊</div>
          <div className="stat-card-label">Total Transactions</div>
          <div className="stat-card-value">{data?.stats?.total_transactions || 0}</div>
          <div className="stat-card-sub">All time</div>
        </div>
        <div className="stat-card">
          <div className="stat-card-icon">📤</div>
          <div className="stat-card-label">Total Volume</div>
          <div className="stat-card-value">{fmt(data?.stats?.total_volume || 0, 'USD')}</div>
          <div className="stat-card-sub">Processed</div>
        </div>
        <div className="stat-card">
          <div className="stat-card-icon">🔔</div>
          <div className="stat-card-label">Notifications</div>
          <div className="stat-card-value">{data?.stats?.unread_notifications || 0}</div>
          <div className="stat-card-sub">Unread</div>
        </div>
      </div>

      <div className="grid-2" style={{ gap: 20 }}>
        {/* Chart */}
        <div className="card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
            <div>
              <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: '16px' }}>Monthly Volume</div>
              <div style={{ fontSize: '12px', color: 'var(--text-dim)', marginTop: 2 }}>Last 6 months</div>
            </div>
          </div>
          {chartData.length > 0 ? (
            <ResponsiveContainer width="100%" height={180}>
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="goldGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#E8A940" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#E8A940" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="month" stroke="var(--text-faint)" tick={{ fontSize: 11, fill: 'var(--text-dim)' }} />
                <YAxis stroke="var(--text-faint)" tick={{ fontSize: 11, fill: 'var(--text-dim)' }} />
                <Tooltip contentStyle={{ background: 'var(--surface2)', border: '1px solid var(--border)', borderRadius: 8, color: 'var(--text)', fontSize: 13 }} />
                <Area type="monotone" dataKey="volume" stroke="#E8A940" fill="url(#goldGrad)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          ) : (
            <div className="empty">
              <div className="empty-icon">📈</div>
              <div className="empty-title">No volume yet</div>
              <div className="empty-desc">Make your first transaction to see analytics</div>
            </div>
          )}
        </div>

        {/* Wallets */}
        <div className="card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
            <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: '16px' }}>My Wallets</div>
            <Link to="/wallets" className="btn btn-ghost btn-sm">View all →</Link>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {wallets.length === 0 && <div className="empty"><div className="empty-icon">◉</div><div className="empty-title">No wallets</div></div>}
            {wallets.slice(0, 5).map(w => (
              <div key={w.id} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 14px', background: 'var(--surface2)', borderRadius: 'var(--radius-sm)' }}>
                <span style={{ fontSize: 22 }}>{getCurrencyFlag(w.currency)}</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: '14px', fontWeight: 600 }}>{w.currency}</div>
                  <div style={{ fontSize: '11px', color: 'var(--text-dim)' }}>Available balance</div>
                </div>
                <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: '15px', color: w.balance > 0 ? 'var(--text)' : 'var(--text-faint)' }}>
                  {fmt(w.balance, w.currency)}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent transactions */}
      <div className="card" style={{ marginTop: 20 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
          <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: '16px' }}>Recent Transactions</div>
          <Link to="/transactions" className="btn btn-ghost btn-sm">View all →</Link>
        </div>
        {!data?.recent_transactions?.length ? (
          <div className="empty">
            <div className="empty-icon">💸</div>
            <div className="empty-title">No transactions yet</div>
            <div className="empty-desc">Send money or fund your wallet to get started</div>
            <div style={{ display: 'flex', gap: 10, marginTop: 8 }}>
              <Link to="/send" className="btn btn-primary btn-sm">Send Money</Link>
              <Link to="/wallets" className="btn btn-ghost btn-sm">Fund Wallet</Link>
            </div>
          </div>
        ) : (
          <div className="table-wrap">
            <table>
              <thead><tr>
                <th>Type</th><th>Description</th><th>Currency</th><th>Amount</th><th>Status</th><th>Date</th>
              </tr></thead>
              <tbody>
                {data.recent_transactions.map(tx => (
                  <tr key={tx.id}>
                    <td><span className={`badge ${tx.type === 'receive' || tx.type === 'deposit' ? 'badge-success' : 'badge-dim'}`}>{tx.type}</span></td>
                    <td style={{ maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', color: 'var(--text-dim)', fontSize: '13px' }}>{tx.description || '—'}</td>
                    <td><span style={{ fontSize: '18px' }}>{getCurrencyFlag(tx.currency)}</span> {tx.currency}</td>
                    <td style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, color: txColor(tx.type) }}>{txSign(tx.type)}{fmt(tx.amount, tx.currency)}</td>
                    <td><span className={`badge ${statusBadge(tx.status)}`}>{tx.status}</span></td>
                    <td style={{ color: 'var(--text-dim)', fontSize: '12px' }}>{fmtDate(tx.created_at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}

function getGreeting() {
  const h = new Date().getHours()
  if (h < 12) return 'morning'
  if (h < 17) return 'afternoon'
  return 'evening'
}
