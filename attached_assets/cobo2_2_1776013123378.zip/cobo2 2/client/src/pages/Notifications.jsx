import { useEffect, useState } from 'react'
import api from '../lib/api'
import toast from 'react-hot-toast'
import { fmtDate } from '../lib/utils'

export default function Notifications() {
  const [notifs, setNotifs] = useState([])
  const [loading, setLoading] = useState(true)

  const load = async () => {
    try { const r = await api.get('/notifications'); setNotifs(r.data.notifications || []) } catch {}
    setLoading(false)
  }

  useEffect(() => { load() }, [])

  const markAll = async () => {
    await api.patch('/notifications/read-all')
    setNotifs(p => p.map(n => ({ ...n, is_read: true })))
    toast.success('All marked as read')
  }

  const markOne = async (id) => {
    await api.patch(`/notifications/${id}/read`)
    setNotifs(p => p.map(n => n.id === id ? { ...n, is_read: true } : n))
  }

  const unread = notifs.filter(n => !n.is_read).length

  return (
    <div className="page fade-in">
      <div className="page-header" style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start' }}>
        <div><h1 className="page-title">Notifications</h1><p className="page-subtitle">{unread} unread</p></div>
        {unread > 0 && <button className="btn btn-ghost btn-sm" onClick={markAll}>Mark all read</button>}
      </div>
      {loading ? <div style={{ padding:20, color:'var(--text-dim)' }}>Loading...</div> : (
        notifs.length === 0 ? (
          <div className="empty card"><div className="empty-icon">🔔</div><div className="empty-title">No notifications</div></div>
        ) : (
          <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
            {notifs.map(n => (
              <div key={n.id} onClick={() => !n.is_read && markOne(n.id)} style={{ background: n.is_read ? 'var(--surface)' : 'var(--dark)', border:`1px solid ${n.is_read ? 'var(--border)' : n.type === 'success' ? 'rgba(61,214,140,0.3)' : 'rgba(232,169,64,0.3)'}`, borderRadius:'var(--radius)', padding:'14px 18px', display:'flex', gap:14, cursor: n.is_read ? 'default' : 'pointer' }}>
                <span style={{ fontSize:22 }}>{n.type === 'success' ? '✅' : n.type === 'error' ? '❌' : 'ℹ️'}</span>
                <div style={{ flex:1 }}>
                  <div style={{ fontWeight: n.is_read ? 400 : 600, fontSize:14, marginBottom:3 }}>{n.title}</div>
                  <div style={{ fontSize:13, color:'var(--text-dim)' }}>{n.message}</div>
                  <div style={{ fontSize:11, color:'var(--text-faint)', marginTop:6 }}>{fmtDate(n.created_at)}</div>
                </div>
                {!n.is_read && <div style={{ width:8, height:8, borderRadius:'50%', background:'var(--gold)', flexShrink:0, marginTop:6 }} />}
              </div>
            ))}
          </div>
        )
      )}
    </div>
  )
}
