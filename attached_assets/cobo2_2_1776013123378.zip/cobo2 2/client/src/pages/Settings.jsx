import { useState } from 'react'
import { useAuth } from '../context/AuthContext'
import { COUNTRIES } from '../lib/utils'
import api from '../lib/api'
import toast from 'react-hot-toast'

export default function Settings() {
  const { user, setUser } = useAuth()
  const [profile, setProfile] = useState({ first_name: user?.first_name || '', last_name: user?.last_name || '', phone: user?.phone || '', business_name: user?.business_name || '', business_type: user?.business_type || 'individual' })
  const [passwords, setPasswords] = useState({ current_password: '', new_password: '', confirm: '' })
  const [savingProfile, setSavingProfile] = useState(false)
  const [savingPw, setSavingPw] = useState(false)
  const setP = (k, v) => setProfile(p => ({ ...p, [k]: v }))
  const setPw = (k, v) => setPasswords(p => ({ ...p, [k]: v }))

  const saveProfile = async e => {
    e.preventDefault()
    setSavingProfile(true)
    try {
      await api.put('/auth/profile', profile)
      setUser(u => ({ ...u, ...profile }))
      toast.success('Profile updated')
    } catch (err) { toast.error(err.response?.data?.message || 'Failed') }
    finally { setSavingProfile(false) }
  }

  const changePassword = async e => {
    e.preventDefault()
    if (passwords.new_password !== passwords.confirm) return toast.error('Passwords do not match')
    if (passwords.new_password.length < 8) return toast.error('New password too short')
    setSavingPw(true)
    try {
      await api.post('/auth/change-password', { current_password: passwords.current_password, new_password: passwords.new_password })
      setPasswords({ current_password: '', new_password: '', confirm: '' })
      toast.success('Password changed successfully')
    } catch (err) { toast.error(err.response?.data?.message || 'Failed') }
    finally { setSavingPw(false) }
  }

  return (
    <div className="page fade-in">
      <div className="page-header">
        <h1 className="page-title">Settings</h1>
        <p className="page-subtitle">Manage your account preferences and security</p>
      </div>

      <div style={{ maxWidth: 640, display: 'flex', flexDirection: 'column', gap: 24 }}>

        {/* Account info */}
        <div className="card-lg">
          <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: '17px', marginBottom: 20 }}>Account Information</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 24, padding: '16px 20px', background: 'var(--surface2)', borderRadius: 'var(--radius)' }}>
            <div style={{ width: 52, height: 52, borderRadius: '50%', background: 'linear-gradient(135deg,#E8A940,#E8624A)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '22px', fontFamily: 'Syne, sans-serif', fontWeight: 800, color: '#0D0B07' }}>
              {user?.first_name?.[0]}{user?.last_name?.[0]}
            </div>
            <div>
              <div style={{ fontWeight: 600, fontSize: '16px' }}>{user?.first_name} {user?.last_name}</div>
              <div style={{ fontSize: '13px', color: 'var(--text-dim)' }}>{user?.email}</div>
              <div style={{ fontSize: '12px', color: 'var(--text-faint)', marginTop: 2 }}>Member since {new Date(user?.created_at).getFullYear()}</div>
            </div>
          </div>
          <form onSubmit={saveProfile} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <div className="grid-2">
              <div className="input-group"><label className="input-label">First Name</label><input className="input" value={profile.first_name} onChange={e => setP('first_name', e.target.value)} /></div>
              <div className="input-group"><label className="input-label">Last Name</label><input className="input" value={profile.last_name} onChange={e => setP('last_name', e.target.value)} /></div>
            </div>
            <div className="input-group"><label className="input-label">Phone Number</label><input className="input" value={profile.phone} onChange={e => setP('phone', e.target.value)} placeholder="+234 800 000 0000" /></div>
            <div className="input-group">
              <label className="input-label">Account Type</label>
              <select className="select" value={profile.business_type} onChange={e => setP('business_type', e.target.value)}>
                <option value="individual">👤 Individual</option>
                <option value="business">🏢 Business</option>
                <option value="startup">🚀 Startup</option>
                <option value="ngo">🌿 NGO / Non-profit</option>
              </select>
            </div>
            {profile.business_type !== 'individual' && (
              <div className="input-group"><label className="input-label">Business Name</label><input className="input" value={profile.business_name} onChange={e => setP('business_name', e.target.value)} /></div>
            )}
            <button className="btn btn-primary" type="submit" disabled={savingProfile} style={{ alignSelf: 'flex-start', minWidth: 140 }}>
              {savingProfile ? <span className="spinner" /> : 'Save Changes'}
            </button>
          </form>
        </div>

        {/* Security */}
        <div className="card-lg">
          <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: '17px', marginBottom: 20 }}>🔒 Security</div>
          <form onSubmit={changePassword} style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <div className="input-group"><label className="input-label">Current Password</label><input className="input" type="password" value={passwords.current_password} onChange={e => setPw('current_password', e.target.value)} required /></div>
            <div className="input-group"><label className="input-label">New Password</label><input className="input" type="password" value={passwords.new_password} onChange={e => setPw('new_password', e.target.value)} required minLength={8} /></div>
            <div className="input-group"><label className="input-label">Confirm New Password</label><input className="input" type="password" value={passwords.confirm} onChange={e => setPw('confirm', e.target.value)} required /></div>
            <button className="btn btn-ghost" type="submit" disabled={savingPw} style={{ alignSelf: 'flex-start', minWidth: 160 }}>
              {savingPw ? <span className="spinner" /> : 'Change Password'}
            </button>
          </form>
        </div>

        {/* Platform info */}
        <div className="card">
          <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: '16px', marginBottom: 16 }}>Platform Details</div>
          {[
            { label: 'Platform', value: 'COBO Payment Infrastructure v1.0' },
            { label: 'Environment', value: process.env.NODE_ENV === 'production' ? '🟢 Production' : '🟡 Sandbox / Development' },
            { label: 'Account ID', value: user?.id },
            { label: 'Country', value: COUNTRIES.find(c => c.code === user?.country)?.name || user?.country },
            { label: 'KYC Level', value: `Level ${user?.kyc_level || 0} — ${user?.kyc_status}` },
          ].map(r => (
            <div key={r.label} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 0', borderBottom: '1px solid var(--border)' }}>
              <span style={{ fontSize: '13px', color: 'var(--text-dim)' }}>{r.label}</span>
              <span style={{ fontSize: '13px', fontFamily: r.label === 'Account ID' ? 'monospace' : undefined, color: 'var(--text)' }}>{r.value}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
