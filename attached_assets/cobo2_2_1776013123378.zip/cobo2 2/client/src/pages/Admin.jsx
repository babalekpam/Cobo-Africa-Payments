import { useEffect, useState } from 'react'
import api from '../lib/api'
import { fmt, fmtDate } from '../lib/utils'
import toast from 'react-hot-toast'

export default function Admin() {
  const [stats, setStats] = useState(null)
  const [users, setUsers] = useState([])
  const [txs, setTxs] = useState([])

  useEffect(() => {
    Promise.all([api.get('/admin/stats'), api.get('/admin/users'), api.get('/admin/transactions')])
      .then(([s, u, t]) => { setStats(s.data.stats); setUsers(u.data.users); setTxs(t.data.transactions) })
      .catch(() => toast.error('Admin access required'))
  }, [])

  const approveKYC = async (userId) => {
    toast.success('KYC approved (implement doc ID in admin panel)')
  }

  if (!stats) return <div className="page"><div style={{ color:'var(--text-dim)', padding:20 }}>Loading admin panel...</div></div>

  return (
    <div className="page fade-in">
      <div className="page-header"><h1 className="page-title">Admin Panel</h1><p className="page-subtitle">Platform management & oversight</p></div>
      <div style={{ background:'rgba(232,169,64,0.08)', border:'1px solid rgba(232,169,64,0.2)', borderRadius:'var(--radius)', padding:'10px 16px', marginBottom:20, fontSize:13, color:'var(--gold)' }}>⚙ Admin access — full platform visibility</div>
      <div className="grid-4" style={{ marginBottom:24 }}>
        {[['👥','Total Users',stats.total_users,'Registered'],['📊','Transactions',stats.total_transactions,'All time'],['💰','Total Volume',`$${(stats.total_volume||0).toFixed(0)}`, 'Processed'],['⏳','Pending KYC',stats.pending_kyc,'Awaiting']].map(([ic,lb,val,sub]) => (
          <div key={lb} className="stat-card"><div className="stat-card-icon">{ic}</div><div className="stat-card-label">{lb}</div><div className="stat-card-value">{val}</div><div className="stat-card-sub">{sub}</div></div>
        ))}
      </div>
      <div className="card" style={{ marginBottom:20 }}>
        <div style={{ fontFamily:'Syne,sans-serif', fontWeight:700, fontSize:15, marginBottom:16 }}>Users</div>
        <div className="table-wrap">
          <table>
            <thead><tr><th>Name</th><th>Email</th><th>Country</th><th>KYC</th><th>Role</th><th>Joined</th></tr></thead>
            <tbody>
              {users.map(u => (
                <tr key={u.id}>
                  <td style={{ fontWeight:500 }}>{u.first_name} {u.last_name}</td>
                  <td style={{ color:'var(--text-dim)', fontSize:13 }}>{u.email}</td>
                  <td>{u.country}</td>
                  <td><span className={`badge badge-${u.kyc_status==='verified'?'success':u.kyc_status==='submitted'?'warning':'dim'}`}>{u.kyc_status}</span></td>
                  <td><span className={`badge badge-${u.role==='admin'?'info':'dim'}`}>{u.role}</span></td>
                  <td style={{ color:'var(--text-dim)', fontSize:12 }}>{fmtDate(u.created_at)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      <div className="card">
        <div style={{ fontFamily:'Syne,sans-serif', fontWeight:700, fontSize:15, marginBottom:16 }}>Recent Transactions (all users)</div>
        <div className="table-wrap">
          <table>
            <thead><tr><th>Type</th><th>Amount</th><th>Currency</th><th>Status</th><th>Date</th></tr></thead>
            <tbody>
              {txs.slice(0,20).map(tx => (
                <tr key={tx.id}>
                  <td><span className={`badge badge-${tx.type==='receive'||tx.type==='deposit'?'success':tx.type==='swap'?'info':'dim'}`}>{tx.type}</span></td>
                  <td style={{ fontWeight:600 }}>{fmt(tx.amount, tx.currency)}</td>
                  <td>{tx.currency}</td>
                  <td><span className={`badge badge-${tx.status==='success'?'success':tx.status==='pending'?'warning':'error'}`}>{tx.status}</span></td>
                  <td style={{ color:'var(--text-dim)', fontSize:12 }}>{fmtDate(tx.created_at)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
