import { useState, useEffect } from 'react'
import { useAuth } from '../context/AuthContext'
import { fmt, CURRENCIES, COUNTRIES, MOBILE_PROVIDERS, getCurrencyFlag } from '../lib/utils'
import api from '../lib/api'
import toast from 'react-hot-toast'

const TABS = [
  { id: 'bank', label: '🏦 Bank Transfer' },
  { id: 'mobile', label: '📱 Mobile Money' },
  { id: 'internal', label: '⚡ COBO User' },
]

export default function Send() {
  const { wallets, refreshWallets } = useAuth()
  const [tab, setTab] = useState('bank')
  const [loading, setLoading] = useState(false)
  const [banks, setBanks] = useState([])
  const [feeInfo, setFeeInfo] = useState(null)
  const [done, setDone] = useState(null)
  const [resolving, setResolving] = useState(false)
  const [resolvedName, setResolvedName] = useState('')

  const [form, setForm] = useState({
    currency: Object.keys(wallets)[0] || 'USD',
    amount: '', country: 'NG',
    bank_code: '', bank_name: '', account_number: '', account_name: '',
    phone: '', provider: 'mtn_momo', recipient_name: '',
    recipient_email: '', description: ''
  })
  const set = (k, v) => setForm(p => ({ ...p, [k]: v }))

  const wallet = wallets.find(w => w.currency === form.currency)

  useEffect(() => {
    if (form.country) {
      api.get(`/transfers/banks/${form.country}`)
        .then(r => setBanks(r.data.banks || []))
        .catch(() => {})
    }
  }, [form.country])

  useEffect(() => {
    const amt = Number(form.amount)
    if (amt > 0) {
      const timer = setTimeout(() => {
        api.get(`/transfers/fee?amount=${amt}&type=${tab === 'internal' ? 'internal' : 'external'}`)
          .then(r => setFeeInfo(r.data))
          .catch(() => {})
      }, 300)
      return () => clearTimeout(timer)
    } else setFeeInfo(null)
  }, [form.amount, tab])

  // Resolve account name when account number + bank filled
  const resolveAccount = async () => {
    if (!form.account_number || !form.bank_code) return
    setResolving(true)
    setResolvedName('')
    try {
      const r = await api.post('/transfers/resolve-account', {
        account_number: form.account_number,
        account_bank: form.bank_code
      })
      if (r.data.account_name) {
        setResolvedName(r.data.account_name)
        set('account_name', r.data.account_name)
        toast.success('Account verified: ' + r.data.account_name)
      }
    } catch {
      // Sandbox: just use what user typed
    }
    setResolving(false)
  }

  const providers = MOBILE_PROVIDERS.filter(p => p.countries.includes(form.country))

  const submit = async e => {
    e.preventDefault()
    if (!form.amount || form.amount <= 0) { toast.error('Enter a valid amount'); return }
    const walletBalance = wallets.find(w => w.currency === form.currency)?.balance || 0
    if (walletBalance < Number(form.amount)) { toast.error('Insufficient balance'); return }

    setLoading(true)
    try {
      let res
      if (tab === 'bank') {
        if (!form.account_number) { toast.error('Enter account number'); return }
        res = await api.post('/transfers/bank', { ...form, amount: Number(form.amount) })
      } else if (tab === 'mobile') {
        if (!form.phone) { toast.error('Enter phone number'); return }
        res = await api.post('/transfers/mobile-money', { ...form, amount: Number(form.amount), provider: form.provider, recipient_name: form.recipient_name, phone: form.phone })
      } else {
        if (!form.recipient_email) { toast.error('Enter recipient email'); return }
        res = await api.post('/transfers/internal', { ...form, amount: Number(form.amount) })
      }
      await refreshWallets()
      setDone(res.data)
      toast.success('Transfer initiated!')
    } catch (err) {
      toast.error(err.response?.data?.message || 'Transfer failed')
    } finally { setLoading(false) }
  }

  if (done) return (
    <div className="page fade-in" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '60vh' }}>
      <div className="card-lg" style={{ maxWidth: 400, textAlign: 'center' }}>
        <div style={{ fontSize: 56, marginBottom: 16 }}>✅</div>
        <h2 style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: 22, marginBottom: 8 }}>Transfer Initiated!</h2>
        <p style={{ color: 'var(--text-dim)', fontSize: 14, marginBottom: 16 }}>
          {done.mode === 'sandbox' ? 'Sandbox mode — simulated success' : 'Your transfer is being processed'}
        </p>
        <div style={{ background: 'var(--surface2)', borderRadius: 8, padding: '12px 16px', marginBottom: 24, fontSize: 13, color: 'var(--text-dim)', wordBreak: 'break-all' }}>
          Ref: <strong style={{ color: 'var(--gold)' }}>{done.reference}</strong>
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <button className="btn btn-ghost btn-full" onClick={() => {
            setDone(null)
            setForm(p => ({ ...p, amount: '', account_number: '', account_name: '', phone: '', recipient_email: '' }))
            setResolvedName('')
            setFeeInfo(null)
          }}>New Transfer</button>
          <a href="/transactions" className="btn btn-primary btn-full">View History</a>
        </div>
      </div>
    </div>
  )

  const walletList = wallets

  return (
    <div className="page fade-in">
      <div className="page-header">
        <h1 className="page-title">Send Money</h1>
        <p className="page-subtitle">Transfer to banks, mobile wallets, or COBO users</p>
      </div>

      <div style={{ maxWidth: 560 }}>
        {/* Tab selector */}
        <div style={{ display: 'flex', gap: 4, background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 'var(--radius)', padding: 4, marginBottom: 22 }}>
          {TABS.map(t => (
            <button key={t.id} onClick={() => { setTab(t.id); setFeeInfo(null) }} style={{
              flex: 1, padding: '9px', borderRadius: 10, border: 'none', cursor: 'pointer',
              fontFamily: 'DM Sans, sans-serif', fontSize: 13, fontWeight: tab === t.id ? 600 : 400,
              background: tab === t.id ? 'var(--surface3)' : 'transparent',
              color: tab === t.id ? 'var(--text)' : 'var(--text-dim)',
              transition: 'all 0.15s'
            }}>{t.label}</button>
          ))}
        </div>

        <form onSubmit={submit}>
          <div className="card-lg" style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {/* Currency + Amount */}
            <div className="grid-2">
              <div className="input-group">
                <label className="input-label">From wallet</label>
                <select className="select" value={form.currency} onChange={e => set('currency', e.target.value)}>
                  {walletList.map(w => (
                    <option key={w.currency} value={w.currency}>
                      {getCurrencyFlag(w.currency)} {w.currency} — {fmt(w.balance, w.currency)}
                    </option>
                  ))}
                </select>
              </div>
              <div className="input-group">
                <label className="input-label">Amount</label>
                <input className="input" type="number" placeholder="0.00" value={form.amount}
                  onChange={e => set('amount', e.target.value)} min="0.01" step="any" required />
              </div>
            </div>

            {/* Fee preview */}
            {feeInfo && Number(form.amount) > 0 && (
              <div style={{ background: 'var(--surface2)', borderRadius: 8, padding: '12px 16px', fontSize: 13 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', color: 'var(--text-dim)', marginBottom: 4 }}>
                  <span>Fee ({tab === 'internal' ? 'free' : '0.9%'})</span>
                  <span>{feeInfo.fee === 0 ? 'Free' : fmt(feeInfo.fee, form.currency)}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 600, color: 'var(--text)' }}>
                  <span>Total deducted</span>
                  <span style={{ color: 'var(--gold)' }}>{fmt(feeInfo.total, form.currency)}</span>
                </div>
                {feeInfo.mode === 'live' && (
                  <div style={{ marginTop: 6, fontSize: 11, color: 'var(--green)' }}>🟢 Live mode — Flutterwave connected</div>
                )}
                {feeInfo.mode === 'sandbox' && (
                  <div style={{ marginTop: 6, fontSize: 11, color: 'var(--text-faint)' }}>🟡 Sandbox mode — transfers are simulated</div>
                )}
              </div>
            )}

            {/* Bank tab */}
            {tab === 'bank' && (
              <>
                <div className="input-group">
                  <label className="input-label">Recipient country</label>
                  <select className="select" value={form.country} onChange={e => set('country', e.target.value)}>
                    {COUNTRIES.map(c => <option key={c.code} value={c.code}>{c.flag} {c.name}</option>)}
                  </select>
                </div>
                <div className="input-group">
                  <label className="input-label">Bank</label>
                  <select className="select" value={form.bank_code}
                    onChange={e => {
                      const b = banks.find(b => b.code === e.target.value)
                      set('bank_code', e.target.value)
                      set('bank_name', b?.name || '')
                      setResolvedName('')
                    }}>
                    <option value="">Select bank</option>
                    {banks.map(b => <option key={b.code} value={b.code}>{b.name}</option>)}
                  </select>
                </div>
                <div className="input-group">
                  <label className="input-label">Account number</label>
                  <div style={{ display: 'flex', gap: 8 }}>
                    <input className="input" placeholder="0123456789" value={form.account_number}
                      onChange={e => { set('account_number', e.target.value); setResolvedName('') }}
                      onBlur={resolveAccount}
                    />
                    {resolving && <span className="spinner" style={{ flexShrink: 0, marginTop: 10 }} />}
                  </div>
                  {resolvedName && (
                    <div style={{ fontSize: 12, color: 'var(--green)', marginTop: 4 }}>✓ {resolvedName}</div>
                  )}
                </div>
                <div className="input-group">
                  <label className="input-label">Account name</label>
                  <input className="input" placeholder="John Doe" value={form.account_name}
                    onChange={e => set('account_name', e.target.value)} />
                </div>
              </>
            )}

            {/* Mobile tab */}
            {tab === 'mobile' && (
              <>
                <div className="input-group">
                  <label className="input-label">Country</label>
                  <select className="select" value={form.country} onChange={e => set('country', e.target.value)}>
                    {COUNTRIES.map(c => <option key={c.code} value={c.code}>{c.flag} {c.name}</option>)}
                  </select>
                </div>
                <div className="input-group">
                  <label className="input-label">Mobile money provider</label>
                  <select className="select" value={form.provider} onChange={e => set('provider', e.target.value)}>
                    {providers.length > 0
                      ? providers.map(p => <option key={p.id} value={p.id}>{p.name}</option>)
                      : <option disabled>No providers for this country</option>
                    }
                  </select>
                </div>
                <div className="input-group">
                  <label className="input-label">Phone number (with country code)</label>
                  <input className="input" placeholder="+228 90 12 34 56" value={form.phone}
                    onChange={e => set('phone', e.target.value)} />
                </div>
                <div className="input-group">
                  <label className="input-label">Recipient name (optional)</label>
                  <input className="input" placeholder="Amara Diallo" value={form.recipient_name}
                    onChange={e => set('recipient_name', e.target.value)} />
                </div>
              </>
            )}

            {/* Internal tab */}
            {tab === 'internal' && (
              <>
                <div style={{ background: 'var(--green-bg, rgba(61,214,140,0.08))', border: '1px solid rgba(61,214,140,0.2)', borderRadius: 8, padding: '10px 14px', fontSize: 13, color: 'var(--green)' }}>
                  ⚡ Free instant transfer to any COBO user — zero fees, no limits
                </div>
                <div className="input-group">
                  <label className="input-label">Recipient COBO email</label>
                  <input className="input" type="email" placeholder="friend@cobo.africa" value={form.recipient_email}
                    onChange={e => set('recipient_email', e.target.value)} />
                </div>
              </>
            )}

            <div className="input-group">
              <label className="input-label">Description / note (optional)</label>
              <input className="input" placeholder="Payment for services..." value={form.description}
                onChange={e => set('description', e.target.value)} />
            </div>

            <button className="btn btn-primary btn-full btn-lg" type="submit" disabled={loading} style={{ marginTop: 4 }}>
              {loading
                ? <><span className="spinner" /> Processing...</>
                : `↑ Send ${form.amount ? fmt(Number(form.amount), form.currency) : 'Money'}`
              }
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
