import { useEffect, useState } from 'react'
import api from '../lib/api'
import { fmt, fmtDate, getCurrencyFlag, statusBadge } from '../lib/utils'
import toast from 'react-hot-toast'

export default function Transactions() {
  const [txs, setTxs] = useState([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState({ type: '', status: '', currency: '' })
  const [page, setPage] = useState(1)
  const [total, setTotal] = useState(0)
  const [selected, setSelected] = useState(null)

  const load = async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams({ page, limit: 20 })
      if (filter.type) params.set('type', filter.type)
      if (filter.status) params.set('status', filter.status)
      if (filter.currency) params.set('currency', filter.currency)
      const r = await api.get(`/transactions?${params}`)
      setTxs(r.data.transactions || [])
      setTotal(r.data.pagination?.total || 0)
    } catch { toast.error('Failed to load transactions') }
    setLoading(false)
  }

  useEffect(() => { load() }, [page, filter])

  const copy = (text) => {
    navigator.clipboard?.writeText(text)
    toast.success('Copied!')
  }

  return (
    <div className="page fade-in">
      <div className="page-header">
        <h1 className="page-title">Transactions</h1>
        <p className="page-subtitle">{total} total · click any row for receipt</p>
      </div>

      {/* Filters */}
      <div style={{ display: 'flex', gap: 10, marginBottom: 18, flexWrap: 'wrap' }}>
        {[
          ['type', ['', 'send', 'receive', 'deposit', 'swap'], 'All types'],
          ['status', ['', 'success', 'pending', 'processing', 'failed'], 'All status'],
          ['currency', ['', 'USD', 'NGN', 'GHS', 'XOF', 'KES', 'ZAR', 'EUR', 'GBP'], 'All currencies'],
        ].map(([key, opts, placeholder]) => (
          <select key={key} value={filter[key]}
            onChange={e => { setFilter(p => ({ ...p, [key]: e.target.value })); setPage(1) }}
            style={{ padding: '8px 12px', background: 'var(--surface)', border: '0.5px solid var(--border)', borderRadius: 8, color: 'var(--text-primary, var(--text))', fontSize: 13, minWidth: 130 }}>
            {opts.map(o => <option key={o} value={o}>{o || placeholder}</option>)}
          </select>
        ))}
        <button className="btn btn-ghost btn-sm" onClick={() => { setFilter({ type: '', status: '', currency: '' }); setPage(1) }}>Clear</button>
      </div>

      <div className="card">
        {loading ? (
          <div style={{ padding: '40px', textAlign: 'center', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 12, color: 'var(--text-dim)' }}>
            <span className="spinner" /> Loading transactions...
          </div>
        ) : txs.length === 0 ? (
          <div className="empty">
            <div className="empty-icon">📭</div>
            <div className="empty-title">No transactions found</div>
            <div className="empty-desc">Try changing your filters or make your first transfer</div>
          </div>
        ) : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  {['Type', 'Description', 'Amount', 'Fee', 'Status', 'Date', ''].map(h => (
                    <th key={h}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {txs.map(tx => {
                  const isIn = tx.type === 'receive' || tx.type === 'deposit'
                  return (
                    <tr key={tx.id} onClick={() => setSelected(tx)} style={{ cursor: 'pointer' }}>
                      <td>
                        <span className={`badge badge-${isIn ? 'success' : tx.type === 'swap' ? 'info' : 'dim'}`}>
                          {tx.type}
                        </span>
                      </td>
                      <td style={{ maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', color: 'var(--text-dim)', fontSize: 13 }}>
                        {tx.description || '—'}
                      </td>
                      <td>
                        <div style={{ fontWeight: 600, color: isIn ? 'var(--green)' : 'var(--text)' }}>
                          {isIn ? '+' : '−'}{fmt(tx.amount, tx.currency)}
                        </div>
                        <div style={{ fontSize: 11, color: 'var(--text-faint)' }}>
                          {getCurrencyFlag(tx.currency)} {tx.currency}
                        </div>
                      </td>
                      <td style={{ fontSize: 13, color: 'var(--text-dim)' }}>
                        {tx.fee > 0 ? fmt(tx.fee, tx.currency) : '—'}
                      </td>
                      <td>
                        <span className={`badge ${statusBadge(tx.status)}`}>{tx.status}</span>
                      </td>
                      <td style={{ fontSize: 12, color: 'var(--text-dim)' }}>{fmtDate(tx.created_at)}</td>
                      <td style={{ color: 'var(--text-faint)', fontSize: 12 }}>→</td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Pagination */}
        {total > 20 && (
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '16px 0 0', borderTop: '1px solid var(--border)', marginTop: 12 }}>
            <span style={{ fontSize: 13, color: 'var(--text-dim)' }}>
              Page {page} of {Math.ceil(total / 20)} · {total} transactions
            </span>
            <div style={{ display: 'flex', gap: 8 }}>
              <button className="btn btn-ghost btn-sm" disabled={page === 1} onClick={() => setPage(p => p - 1)}>← Prev</button>
              <button className="btn btn-ghost btn-sm" disabled={page >= Math.ceil(total / 20)} onClick={() => setPage(p => p + 1)}>Next →</button>
            </div>
          </div>
        )}
      </div>

      {/* Transaction Receipt Modal */}
      {selected && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 200, padding: 20 }}
          onClick={() => setSelected(null)}>
          <div className="card-lg" style={{ width: '100%', maxWidth: 440 }} onClick={e => e.stopPropagation()}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
              <h3 style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: 17 }}>Transaction Receipt</h3>
              <button onClick={() => setSelected(null)} style={{ background: 'none', border: 'none', fontSize: 18, cursor: 'pointer', color: 'var(--text-dim)' }}>✕</button>
            </div>

            {/* Status banner */}
            <div style={{
              padding: '14px 18px', borderRadius: 10, marginBottom: 20,
              background: selected.status === 'success' ? 'rgba(61,214,140,0.08)' : selected.status === 'pending' || selected.status === 'processing' ? 'rgba(232,169,64,0.08)' : 'rgba(245,83,83,0.08)',
              border: `1px solid ${selected.status === 'success' ? 'rgba(61,214,140,0.3)' : selected.status === 'pending' || selected.status === 'processing' ? 'rgba(232,169,64,0.3)' : 'rgba(245,83,83,0.3)'}`,
              display: 'flex', alignItems: 'center', gap: 12
            }}>
              <span style={{ fontSize: 24 }}>
                {selected.status === 'success' ? '✅' : selected.status === 'pending' || selected.status === 'processing' ? '⏳' : '❌'}
              </span>
              <div>
                <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 2 }}>
                  {selected.status === 'success' ? 'Transaction Successful' : selected.status === 'pending' ? 'Pending Processing' : selected.status === 'processing' ? 'Being Processed' : 'Transaction Failed'}
                </div>
                <div style={{ fontSize: 12, color: 'var(--text-dim)' }}>{fmtDate(selected.created_at)}</div>
              </div>
              <div style={{ marginLeft: 'auto', textAlign: 'right' }}>
                <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: 20, color: (selected.type === 'receive' || selected.type === 'deposit') ? 'var(--green)' : 'var(--text)' }}>
                  {(selected.type === 'receive' || selected.type === 'deposit') ? '+' : '−'}{fmt(selected.amount, selected.currency)}
                </div>
                <div style={{ fontSize: 11, color: 'var(--text-dim)' }}>{selected.currency}</div>
              </div>
            </div>

            {/* Details */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
              {[
                ['Transaction ID', selected.id, true],
                ['Type', selected.type],
                ['Description', selected.description || '—'],
                ['Amount', fmt(selected.amount, selected.currency)],
                ['Fee', selected.fee > 0 ? fmt(selected.fee, selected.currency) : 'None'],
                ['Net amount', fmt(selected.net_amount || selected.amount, selected.currency)],
                selected.recipient_name && ['Recipient', selected.recipient_name],
                selected.recipient_account && ['Account / Phone', selected.recipient_account],
                selected.recipient_bank && ['Bank', selected.recipient_bank],
                ['Provider', selected.provider || '—'],
                ['Reference', selected.reference || '—', true],
                selected.external_reference && ['External ref', selected.external_reference, true],
              ].filter(Boolean).map(([label, value, mono]) => (
                <div key={label} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderBottom: '0.5px solid var(--border)', fontSize: 13 }}>
                  <span style={{ color: 'var(--text-dim)', flexShrink: 0, marginRight: 12 }}>{label}</span>
                  <span style={{ fontFamily: mono ? 'monospace' : undefined, fontSize: mono ? 11 : 13, textAlign: 'right', wordBreak: 'break-all' }}>
                    {value}
                  </span>
                </div>
              ))}
            </div>

            <div style={{ display: 'flex', gap: 10, marginTop: 20 }}>
              <button className="btn btn-ghost btn-full" onClick={() => setSelected(null)}>Close</button>
              <button className="btn btn-primary btn-full" onClick={() => copy(selected.reference || selected.id)}>
                📋 Copy Reference
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
