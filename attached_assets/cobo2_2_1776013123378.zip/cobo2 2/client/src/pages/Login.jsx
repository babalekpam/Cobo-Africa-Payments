import { useState } from 'react'
import { useAuth } from '../context/AuthContext'
import coboLogo from '../assets/cobo-logo.png'

export default function Login() {
  const { login, register, loading } = useAuth()
  const [mode, setMode] = useState('login')
  const [form, setForm] = useState({ email:'', password:'', first_name:'', last_name:'', country:'TG', business_name:'' })
  const [err, setErr] = useState('')
  const set = (k,v) => setForm(p => ({ ...p, [k]: v }))

  const COUNTRIES = [
    {c:'NG',n:'Nigeria'},{c:'GH',n:'Ghana'},{c:'SN',n:'Senegal'},{c:'TG',n:'Togo'},
    {c:'CI',n:"Côte d'Ivoire"},{c:'KE',n:'Kenya'},{c:'ZA',n:'South Africa'},
    {c:'EG',n:'Egypt'},{c:'MA',n:'Morocco'},{c:'CM',n:'Cameroon'},
    {c:'ET',n:'Ethiopia'},{c:'TZ',n:'Tanzania'},{c:'UG',n:'Uganda'},
    {c:'RW',n:'Rwanda'},{c:'US',n:'United States'},{c:'GB',n:'United Kingdom'},
  ]

  const submit = async e => {
    e.preventDefault()
    setErr('')
    try {
      if (mode === 'login') {
        await login(form.email, form.password)
      } else {
        if (!form.first_name || !form.last_name) { setErr('First and last name required'); return }
        await register(form)
      }
    } catch (error) {
      setErr(error.response?.data?.message || 'Something went wrong')
    }
  }

  return (
    <div style={{ minHeight:'100vh', display:'flex', alignItems:'center', justifyContent:'center', background:'var(--dark)', padding:20 }}>
      <div style={{ width:'100%', maxWidth:420 }}>

        {/* Logo */}
        <div style={{ marginBottom:24, borderRadius:14, overflow:'hidden', border:'1px solid rgba(200,146,26,0.3)', boxShadow:'0 0 40px rgba(200,146,26,0.08)' }}>
          <img src={coboLogo} alt="COBO Africa Payments" style={{ width:'100%', display:'block' }} />
        </div>

        {/* Card */}
        <div className="card-lg">
          <h2 style={{ fontFamily:'Syne, sans-serif', fontWeight:800, fontSize:20, marginBottom:4, letterSpacing:'-0.5px' }}>
            {mode === 'login' ? 'Sign in' : 'Create account'}
          </h2>
          <p style={{ fontSize:13, color:'var(--text-dim)', marginBottom:20 }}>
            {mode === 'login' ? 'Welcome back to COBO' : 'Join Africa\'s unified payment network'}
          </p>

          {err && (
            <div style={{ background:'rgba(176,32,32,0.08)', border:'1px solid rgba(176,32,32,0.3)', borderRadius:8, padding:'9px 13px', fontSize:13, color:'#b02020', marginBottom:14 }}>
              {err}
            </div>
          )}

          <form onSubmit={submit} style={{ display:'flex', flexDirection:'column', gap:13 }}>
            {mode === 'register' && (
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
                <div className="input-group">
                  <label className="input-label">First name</label>
                  <input className="input" placeholder="Abel" value={form.first_name} onChange={e => set('first_name', e.target.value)} required />
                </div>
                <div className="input-group">
                  <label className="input-label">Last name</label>
                  <input className="input" placeholder="Nkawula" value={form.last_name} onChange={e => set('last_name', e.target.value)} required />
                </div>
              </div>
            )}

            <div className="input-group">
              <label className="input-label">Email address</label>
              <input className="input" type="email" placeholder="you@example.com" value={form.email} onChange={e => set('email', e.target.value)} required />
            </div>

            <div className="input-group">
              <label className="input-label">Password</label>
              <input className="input" type="password" placeholder="••••••••" value={form.password} onChange={e => set('password', e.target.value)} required />
            </div>

            {mode === 'register' && (
              <>
                <div className="input-group">
                  <label className="input-label">Country</label>
                  <select className="select" value={form.country} onChange={e => set('country', e.target.value)}>
                    {COUNTRIES.map(c => <option key={c.c} value={c.c}>{c.n}</option>)}
                  </select>
                </div>
                <div className="input-group">
                  <label className="input-label">Business name (optional)</label>
                  <input className="input" placeholder="ARGILETTE LLC" value={form.business_name} onChange={e => set('business_name', e.target.value)} />
                </div>
              </>
            )}

            <button className="btn btn-primary btn-full btn-lg" type="submit" disabled={loading} style={{ marginTop:4 }}>
              {loading ? 'Please wait...' : mode === 'login' ? 'Sign In →' : 'Create Account →'}
            </button>
          </form>

          <div style={{ height:'0.5px', background:'var(--border)', margin:'18px 0' }} />

          <div style={{ textAlign:'center', fontSize:13, color:'var(--text-dim)' }}>
            {mode === 'login' ? "Don't have an account? " : 'Already have an account? '}
            <button onClick={() => { setMode(mode === 'login' ? 'register' : 'login'); setErr('') }}
              style={{ background:'none', border:'none', color:'#C8921A', cursor:'pointer', fontWeight:600, fontSize:13, padding:0 }}>
              {mode === 'login' ? 'Create free account' : 'Sign in'}
            </button>
          </div>
        </div>

        <div style={{ textAlign:'center', marginTop:16, fontSize:11, color:'var(--text-faint)' }}>
          🔒 Bank-grade encryption · 54 African countries
        </div>
      </div>
    </div>
  )
}
