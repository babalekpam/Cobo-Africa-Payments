import { useState, useEffect } from 'react'
import { useAuth } from '../context/AuthContext'
import { fmt, getCurrencyFlag, CURRENCIES } from '../lib/utils'
import api from '../lib/api'
import toast from 'react-hot-toast'

export default function Exchange() {
  const { wallets, refreshWallets } = useAuth()
  const [from, setFrom] = useState(wallets[0]?.currency || 'USD')
  const [to, setTo] = useState('NGN')
  const [amount, setAmount] = useState('')
  const [preview, setPreview] = useState(null)
  const [rates, setRates] = useState({})
  const [loading, setLoading] = useState(false)
  const [swapping, setSwapping] = useState(false)

  useEffect(() => {
    api.get('/exchange/rates').then(r => setRates(r.data.rates || {})).catch(() => {})
  }, [])

  useEffect(() => {
    if (amount > 0 && from && to && from !== to) {
      const timer = setTimeout(() => {
        api.post('/exchange/convert', { from, to, amount: Number(amount) })
          .then(r => setPreview(r.data)).catch(() => setPreview(null))
      }, 400)
      return () => clearTimeout(timer)
    } else setPreview(null)
  }, [from, to, amount])

  const fromWallet = wallets.find(w => w.currency === from)

  const doSwap = async () => {
    if (!amount || amount <= 0) return toast.error('Enter amount')
    if (!fromWallet || fromWallet.balance < Number(amount)) return toast.error('Insufficient balance')
    setSwapping(true)
    try {
      const r = await api.post('/exchange/swap', { from_currency: from, to_currency: to, amount: Number(amount) })
      await refreshWallets()
      toast.success(`Swapped ${from} → ${to}!`)
      setAmount('')
      setPreview(null)
    } catch (err) { toast.error(err.response?.data?.message || 'Swap failed') }
    finally { setSwapping(false) }
  }

  const currencies = [...new Set([...wallets.map(w => w.currency), ...Object.keys(CURRENCIES)])]

  return (
    <div className="page fade-in">
      <div className="page-header">
        <h1 className="page-title">FX Exchange</h1>
        <p className="page-subtitle">Swap between currencies at live market rates</p>
      </div>

      <div style={{ maxWidth: 520 }}>
        <div className="card-lg" style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
          {/* From */}
          <div>
            <label className="input-label" style={{ marginBottom: 8, display: 'block' }}>You Send</label>
            <div style={{ display: 'flex', gap: 10 }}>
              <select className="select" style={{ width: 140, flexShrink: 0 }} value={from} onChange={e => setFrom(e.target.value)}>
                {wallets.map(w => <option key={w.id} value={w.currency}>{getCurrencyFlag(w.currency)} {w.currency}</option>)}
              </select>
              <input className="input" type="number" placeholder="0.00" value={amount} onChange={e => setAmount(e.target.value)} step="any" min="0" />
            </div>
            {fromWallet && <div style={{ marginTop: 6, fontSize: '12px', color: 'var(--text-dim)' }}>Balance: {fmt(fromWallet.balance, from)}</div>}
          </div>

          {/* Swap button */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{ flex: 1, height: 1, background: 'var(--border)' }} />
            <button onClick={() => { setFrom(to); setTo(from) }} style={{ background: 'var(--surface3)', border: '1px solid var(--border)', borderRadius: '50%', width: 36, height: 36, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', fontSize: '16px', color: 'var(--gold)', transition: 'transform 0.2s' }} title="Swap currencies">⇅</button>
            <div style={{ flex: 1, height: 1, background: 'var(--border)' }} />
          </div>

          {/* To */}
          <div>
            <label className="input-label" style={{ marginBottom: 8, display: 'block' }}>You Receive</label>
            <div style={{ display: 'flex', gap: 10 }}>
              <select className="select" style={{ width: 140, flexShrink: 0 }} value={to} onChange={e => setTo(e.target.value)}>
                {currencies.filter(c => c !== from).map(c => <option key={c} value={c}>{getCurrencyFlag(c)} {c}</option>)}
              </select>
              <div className="input" style={{ display: 'flex', alignItems: 'center', color: preview ? 'var(--green)' : 'var(--text-faint)', fontFamily: 'Syne, sans-serif', fontWeight: 700, background: 'var(--surface)', cursor: 'default' }}>
                {preview ? fmt(preview.net_amount, to) : '—'}
              </div>
            </div>
          </div>

          {/* Preview */}
          {preview && (
            <div style={{ background: 'var(--surface2)', borderRadius: 'var(--radius-sm)', padding: '14px 16px', display: 'flex', flexDirection: 'column', gap: 8, fontSize: '13px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', color: 'var(--text-dim)' }}>
                <span>Exchange rate</span><span style={{ color: 'var(--text)' }}>1 {from} = {preview.rate?.toFixed(4)} {to}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', color: 'var(--text-dim)' }}>
                <span>FX fee (0.5%)</span><span>{fmt(preview.fee_amount, from)}</span>
              </div>
              <div style={{ height: 1, background: 'var(--border)' }} />
              <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 600, color: 'var(--text)' }}>
                <span>You receive</span><span style={{ color: 'var(--green)', fontFamily: 'Syne, sans-serif', fontWeight: 700 }}>{fmt(preview.net_amount, to)}</span>
              </div>
            </div>
          )}

          <button className="btn btn-primary btn-full btn-lg" onClick={doSwap} disabled={!preview || swapping}>
            {swapping ? <><span className="spinner" /> Processing swap...</> : `⇄ Swap ${from} → ${to}`}
          </button>
        </div>

        {/* Rates table */}
        <div className="card" style={{ marginTop: 20 }}>
          <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: '15px', marginBottom: 16 }}>Live Rates vs USD</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {Object.entries(rates).filter(([c]) => c !== 'USD').map(([cur, rate]) => (
              <div key={cur} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 12px', background: 'var(--surface2)', borderRadius: 'var(--radius-sm)' }}>
                <span style={{ fontSize: 20 }}>{getCurrencyFlag(cur)}</span>
                <span style={{ fontWeight: 600, flex: 1 }}>{cur}</span>
                <span style={{ fontFamily: 'Syne, sans-serif', fontSize: '15px', fontWeight: 700 }}>{rate.toLocaleString()}</span>
                <span style={{ fontSize: '12px', color: 'var(--text-dim)' }}>/ USD</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
