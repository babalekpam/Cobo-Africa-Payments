import { useEffect, useState } from 'react'
import api from '../lib/api'
import { useAuth } from '../context/AuthContext'
import toast from 'react-hot-toast'

const DOCS = [
  { id: 'national_id', label: 'National ID / Passport', desc: 'Government-issued photo ID' },
  { id: 'proof_of_address', label: 'Proof of Address', desc: 'Utility bill or bank statement (last 3 months)' },
  { id: 'business_reg', label: 'Business Registration', desc: 'For business accounts only' },
  { id: 'selfie', label: 'Selfie with ID', desc: 'Clear photo holding your ID' },
]

export default function KYC() {
  const { user } = useAuth()
  const [status, setStatus] = useState(null)
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(null)
  const [urls, setUrls] = useState({})

  const load = async () => {
    setLoading(true)
    try { const r = await api.get('/kyc/status'); setStatus(r.data) } catch {} finally { setLoading(false) }
  }

  useEffect(() => { load() }, [])

  const submit = async (doc_type) => {
    const url = urls[doc_type]
    if (!url) return toast.error('Enter document URL or upload link')
    setSubmitting(doc_type)
    try {
      await api.post('/kyc/submit', { doc_type, doc_url: url })
      toast.success('Document submitted for review')
      await load()
    } catch (err) { toast.error(err.response?.data?.message || 'Failed') }
    finally { setSubmitting(null) }
  }

  const kycColor = { verified: 'var(--green)', submitted: 'var(--blue)', pending: 'var(--gold)', rejected: 'var(--red)' }

  return (
    <div className="page fade-in">
      <div className="page-header">
        <h1 className="page-title">Identity Verification (KYC)</h1>
        <p className="page-subtitle">Verify your identity to unlock full transaction limits</p>
      </div>

      {/* Status banner */}
      <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 'var(--radius)', padding: '20px 24px', marginBottom: 28, display: 'flex', alignItems: 'center', gap: 20 }}>
        <div style={{ fontSize: 40 }}>{user?.kyc_status === 'verified' ? '✅' : user?.kyc_status === 'submitted' ? '⏳' : user?.kyc_status === 'rejected' ? '❌' : '🔓'}</div>
        <div style={{ flex: 1 }}>
          <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: '18px', color: kycColor[user?.kyc_status] || 'var(--text)' }}>
            {user?.kyc_status === 'verified' ? 'Account Verified' : user?.kyc_status === 'submitted' ? 'Under Review' : user?.kyc_status === 'rejected' ? 'Verification Rejected' : 'Verification Required'}
          </div>
          <div style={{ fontSize: '13px', color: 'var(--text-dim)', marginTop: 4 }}>
            {user?.kyc_status === 'verified' ? 'You have full access to all COBO features and limits.' :
             user?.kyc_status === 'submitted' ? 'We\'re reviewing your documents. Usually takes 24 hours.' :
             user?.kyc_status === 'rejected' ? 'Please resubmit your documents with better quality images.' :
             'Submit your documents to increase limits and unlock all features.'}
          </div>
        </div>
        <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: '22px', color: 'var(--text-dim)' }}>Level {user?.kyc_level || 0}</div>
      </div>

      {/* Limits table */}
      <div className="card" style={{ marginBottom: 24 }}>
        <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: '16px', marginBottom: 16 }}>Verification Levels & Limits</div>
        <div className="table-wrap">
          <table>
            <thead><tr><th>Level</th><th>Status</th><th>Daily Send Limit</th><th>Monthly Limit</th><th>Features</th></tr></thead>
            <tbody>
              <tr><td><strong>Level 0</strong></td><td><span className="badge badge-dim">Unverified</span></td><td>$100</td><td>$500</td><td>Basic features</td></tr>
              <tr><td><strong>Level 1</strong></td><td><span className="badge badge-success">KYC Basic</span></td><td>$5,000</td><td>$50,000</td><td>All payment methods</td></tr>
              <tr><td><strong>Level 2</strong></td><td><span className="badge badge-info">KYC Full</span></td><td>Unlimited</td><td>Unlimited</td><td>Business features + API</td></tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Document submission */}
      {user?.kyc_status !== 'verified' && (
        <div>
          <div style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: '18px', marginBottom: 16 }}>Submit Documents</div>
          <div className="grid-2">
            {DOCS.map(doc => {
              const submitted = status?.documents?.find(d => d.doc_type === doc.id)
              return (
                <div key={doc.id} className="card">
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
                    <div>
                      <div style={{ fontWeight: 600, fontSize: '15px', marginBottom: 3 }}>{doc.label}</div>
                      <div style={{ fontSize: '13px', color: 'var(--text-dim)' }}>{doc.desc}</div>
                    </div>
                    {submitted && <span className={`badge badge-${submitted.status === 'approved' ? 'success' : submitted.status === 'rejected' ? 'error' : 'warning'}`}>{submitted.status}</span>}
                  </div>
                  {submitted?.status === 'approved' ? (
                    <div style={{ color: 'var(--green)', fontSize: '13px', padding: '10px 0' }}>✓ Approved</div>
                  ) : (
                    <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
                      <input className="input" placeholder="Paste image URL or cloud link" value={urls[doc.id] || ''} onChange={e => setUrls(p => ({ ...p, [doc.id]: e.target.value }))} style={{ flex: 1 }} />
                      <button className="btn btn-primary btn-sm" onClick={() => submit(doc.id)} disabled={submitting === doc.id} style={{ flexShrink: 0 }}>
                        {submitting === doc.id ? <span className="spinner" style={{ width: 14, height: 14 }} /> : 'Submit'}
                      </button>
                    </div>
                  )}
                  {submitted?.rejection_reason && <div style={{ marginTop: 8, fontSize: '12px', color: 'var(--red)' }}>Reason: {submitted.rejection_reason}</div>}
                </div>
              )
            })}
          </div>
        </div>
      )}
    </div>
  )
}
