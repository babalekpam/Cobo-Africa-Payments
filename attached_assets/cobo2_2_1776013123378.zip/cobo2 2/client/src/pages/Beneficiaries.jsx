import { useEffect, useState } from 'react'
import api from '../lib/api'
import { COUNTRIES, CURRENCIES, MOBILE_PROVIDERS, getCurrencyFlag } from '../lib/utils'
import toast from 'react-hot-toast'

export default function Beneficiaries() {
  const [bens, setBens] = useState([])
  const [adding, setAdding] = useState(false)
  const [form, setForm] = useState({ name:'', country:'NG', currency:'NGN', type:'bank', account_number:'', bank_name:'', phone:'', provider:'' })
  const sf = (k,v) => setForm(p => ({ ...p, [k]:v }))

  const load = async () => {
    try { const r = await api.get('/beneficiaries'); setBens(r.data.beneficiaries || []) } catch {}
  }
  useEffect(() => { load() }, [])

  const add = async () => {
    if (!form.name) return toast.error('Name required')
    try { await api.post('/beneficiaries', form); await load(); toast.success(`${form.name} saved`); setAdding(false) } catch { toast.error('Failed') }
  }

  const del = async (id) => {
    try { await api.delete(`/beneficiaries/${id}`); await load(); toast.success('Removed') } catch {}
  }

  return (
    <div className="page fade-in">
      <div className="page-header" style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start' }}>
        <div><h1 className="page-title">Beneficiaries</h1><p className="page-subtitle">Saved recipients for quick transfers</p></div>
        <button className="btn btn-primary" onClick={() => setAdding(true)}>+ Add Beneficiary</button>
      </div>
      {bens.length === 0 && !adding && (
        <div className="empty card">
          <div className="empty-icon">★</div><div className="empty-title">No beneficiaries yet</div>
          <div className="empty-desc">Save frequent recipients to send money faster</div>
          <button className="btn btn-primary" style={{ marginTop:8 }} onClick={() => setAdding(true)}>Add first beneficiary</button>
        </div>
      )}
      <div className="grid-2">
        {bens.map(b => (
          <div key={b.id} className="card">
            <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:12 }}>
              <div style={{ width:42, height:42, borderRadius:'50%', background:'rgba(232,169,64,0.1)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:16, fontWeight:600, color:'var(--gold)' }}>{b.name[0]}</div>
              <div><div style={{ fontWeight:600, fontSize:14 }}>{b.name}</div><div style={{ fontSize:12, color:'var(--text-dim)' }}>{COUNTRIES.find(c=>c.code===b.country)?.flag} {b.country} · {b.currency}</div></div>
            </div>
            <div style={{ fontSize:12, color:'var(--text-dim)', marginBottom:12 }}>{b.type==='bank' ? `🏦 ${b.bank_name||'Bank'} · ${b.account_number}` : `📱 ${b.provider||'Mobile'} · ${b.phone}`}</div>
            <div style={{ display:'flex', gap:8 }}>
              <a href="/send" className="btn btn-primary btn-sm" style={{ flex:1, textAlign:'center' }}>↑ Send</a>
              <button className="btn btn-danger btn-sm" onClick={() => del(b.id)}>Remove</button>
            </div>
          </div>
        ))}
      </div>
      {adding && (
        <div style={{ position:'fixed', inset:0, background:'rgba(0,0,0,0.7)', display:'flex', alignItems:'center', justifyContent:'center', zIndex:200, padding:20 }} onClick={() => setAdding(false)}>
          <div className="card-lg" style={{ width:'100%', maxWidth:440 }} onClick={e => e.stopPropagation()}>
            <div style={{ display:'flex', justifyContent:'space-between', marginBottom:20 }}><h3 style={{ fontFamily:'Syne,sans-serif', fontWeight:700, fontSize:17 }}>Add Beneficiary</h3><button onClick={() => setAdding(false)} style={{ background:'none', border:'none', fontSize:18, cursor:'pointer', color:'var(--text-dim)' }}>✕</button></div>
            <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
              <div className="input-group"><label className="input-label">Full name *</label><input className="input" placeholder="Amara Diallo" value={form.name} onChange={e => sf('name', e.target.value)} /></div>
              <div className="grid-2">
                <div className="input-group"><label className="input-label">Country</label><select className="select" value={form.country} onChange={e => sf('country', e.target.value)}>{COUNTRIES.map(c => <option key={c.code} value={c.code}>{c.flag} {c.name}</option>)}</select></div>
                <div className="input-group"><label className="input-label">Currency</label><select className="select" value={form.currency} onChange={e => sf('currency', e.target.value)}>{Object.entries(CURRENCIES).map(([c,d]) => <option key={c} value={c}>{d.flag} {c}</option>)}</select></div>
              </div>
              <div className="input-group"><label className="input-label">Type</label><select className="select" value={form.type} onChange={e => sf('type', e.target.value)}><option value="bank">🏦 Bank Account</option><option value="mobile">📱 Mobile Money</option><option value="cobo">⚡ COBO User</option></select></div>
              {form.type === 'bank' && <><div className="input-group"><label className="input-label">Bank name</label><input className="input" placeholder="GTBank" value={form.bank_name} onChange={e => sf('bank_name', e.target.value)} /></div><div className="input-group"><label className="input-label">Account number *</label><input className="input" placeholder="0123456789" value={form.account_number} onChange={e => sf('account_number', e.target.value)} /></div></>}
              {form.type === 'mobile' && <><div className="input-group"><label className="input-label">Provider</label><input className="input" placeholder="MTN MoMo" value={form.provider} onChange={e => sf('provider', e.target.value)} /></div><div className="input-group"><label className="input-label">Phone *</label><input className="input" placeholder="+234 800 000 0000" value={form.phone} onChange={e => sf('phone', e.target.value)} /></div></>}
              {form.type === 'cobo' && <div className="input-group"><label className="input-label">COBO email *</label><input className="input" type="email" placeholder="friend@cobo.africa" value={form.account_number} onChange={e => sf('account_number', e.target.value)} /></div>}
              <div style={{ display:'flex', gap:10, marginTop:4 }}>
                <button className="btn btn-ghost btn-full" onClick={() => setAdding(false)}>Cancel</button>
                <button className="btn btn-primary btn-full" onClick={add}>Save Beneficiary</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
