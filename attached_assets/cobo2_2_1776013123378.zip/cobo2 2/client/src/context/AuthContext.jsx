import { createContext, useContext, useState, useEffect } from 'react'
import api from '../lib/api'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [wallets, setWallets] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const token = localStorage.getItem('cobo_token')
    if (token) {
      api.get('/auth/me')
        .then(r => { setUser(r.data.user); setWallets(r.data.wallets || []) })
        .catch(() => { localStorage.removeItem('cobo_token'); localStorage.removeItem('cobo_user') })
        .finally(() => setLoading(false))
    } else {
      setLoading(false)
    }
  }, [])

  const login = async (email, password) => {
    const r = await api.post('/auth/login', { email, password })
    localStorage.setItem('cobo_token', r.data.token)
    setUser(r.data.user)
    setWallets(r.data.wallets || [])
    return r.data
  }

  const register = async (data) => {
    const r = await api.post('/auth/register', data)
    localStorage.setItem('cobo_token', r.data.token)
    setUser(r.data.user)
    setWallets(r.data.wallets || [])
    return r.data
  }

  const logout = () => {
    localStorage.removeItem('cobo_token')
    localStorage.removeItem('cobo_user')
    setUser(null)
    setWallets([])
    window.location.href = '/login'
  }

  const refreshWallets = async () => {
    try {
      const r = await api.get('/wallets')
      setWallets(r.data.wallets || [])
    } catch {}
  }

  return (
    <AuthContext.Provider value={{ user, wallets, loading, login, register, logout, refreshWallets, setUser, setWallets }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => useContext(AuthContext)
