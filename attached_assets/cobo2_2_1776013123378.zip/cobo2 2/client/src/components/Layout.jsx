import { Outlet, NavLink } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { useEffect, useState } from 'react'
import api from '../lib/api'
import { fmt, kycBadge } from '../lib/utils'
import coboLogo from '../assets/cobo-logo.png'

const NAV = [
  { to: '/dashboard',      ic: '⬡', lb: 'Dashboard' },
  { to: '/wallets',        ic: '◉', lb: 'Wallets' },
  { to: '/send',           ic: '↑', lb: 'Send Money' },
  { to: '/transactions',   ic: '≡', lb: 'Transactions' },
  { to: '/exchange',       ic: '⇄', lb: 'FX Exchange' },
  { to: '/payment-links',  ic: '⬡', lb: 'Payment Links' },
  { to: '/beneficiaries',  ic: '★', lb: 'Beneficiaries' },
  { to: '/kyc',            ic: '◎', lb: 'Verification' },
  { to: '/notifications',  ic: '🔔', lb: 'Notifications', badge: true },
  { to: '/developer',      ic: '{}', lb: 'Developer' },
  { to: '/admin',          ic: '⚙', lb: 'Admin Panel', adminOnly: true },
  { to: '/settings',       ic: '⊙', lb: 'Settings' },
]

export default function Layout() {
  const { user, wallets, logout } = useAuth()
  const [unread, setUnread]       = useState(0)
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const totalUSD = wallets.reduce((s,w) => s + (w.currency==='USD' ? w.balance : 0), 0)
  const isAdmin  = user?.role === 'admin'

  useEffect(() => {
    api.get('/auth/dashboard')
       .then(r => setUnread(r.data.stats?.unread_notifications || 0))
       .catch(() => {})
  }, [])

  const sidebar = (
    <>
      {/* ── LOGO ── */}
      <div style={{ padding:'0', borderBottom:'1px solid var(--border)' }}>
        <img
          src={coboLogo}
          alt="COBO Africa Payments"
          style={{ width:'100%', display:'block', objectFit:'cover', maxHeight:90, objectPosition:'right center' }}
        />
      </div>

      {/* ── USER ── */}
      <div style={{ padding:'10px 12px', borderBottom:'1px solid var(--border)' }}>
        <div style={{ display:'flex', alignItems:'center', gap:9 }}>
          <div style={{ width:34, height:34, borderRadius:'50%', background:'rgba(200,146,26,0.12)', border:'1px solid rgba(200,146,26,0.3)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:12, fontWeight:600, color:'#C8921A', flexShrink:0 }}>
            {user?.first_name?.[0]}{user?.last_name?.[0]}
          </div>
          <div style={{ overflow:'hidden' }}>
            <div style={{ fontWeight:600, fontSize:12, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>
              {user?.first_name} {user?.last_name}
            </div>
            <div style={{ fontSize:10, color:'var(--text-dim)', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>
              {user?.email}
            </div>
          </div>
        </div>
        <div style={{ marginTop:7, display:'flex', gap:5, flexWrap:'wrap' }}>
          <span className={`badge ${kycBadge(user?.kyc_status)}`} style={{ fontSize:10, padding:'2px 7px' }}>
            {user?.kyc_status === 'verified' ? '✓ Verified' : '⚠ Unverified'}
          </span>
          {isAdmin && <span className="badge badge-info" style={{ fontSize:10, padding:'2px 7px' }}>Admin</span>}
        </div>
      </div>

      {/* ── BALANCE ── */}
      <div style={{ padding:'8px 12px 7px', borderBottom:'1px solid var(--border)', background:'rgba(200,146,26,0.05)' }}>
        <div style={{ fontSize:10, color:'var(--text-faint)', marginBottom:2 }}>USD Balance</div>
        <div style={{ fontFamily:'Syne, sans-serif', fontSize:18, fontWeight:800, color:'#C8921A', letterSpacing:'-0.5px' }}>
          {fmt(totalUSD, 'USD')}
        </div>
      </div>

      {/* ── NAV ── */}
      <nav style={{ flex:1, padding:'6px 7px', overflowY:'auto' }}>
        {NAV.filter(n => !n.adminOnly || isAdmin).map(n => (
          <NavLink key={n.to} to={n.to}
            onClick={() => setSidebarOpen(false)}
            style={({ isActive }) => ({
              display:'flex', alignItems:'center', gap:9,
              padding:'8px 9px', borderRadius:7,
              textDecoration:'none', marginBottom:1,
              background: isActive ? 'rgba(200,146,26,0.08)' : 'transparent',
              color: isActive ? '#C8921A' : 'var(--text-dim)',
              fontSize:12, fontWeight: isActive ? 600 : 400,
              borderLeft: isActive ? '2px solid #C8921A' : '2px solid transparent',
              transition:'all 0.15s'
            })}>
            <span style={{ width:15, textAlign:'center', fontSize:11, fontFamily:'monospace', flexShrink:0 }}>{n.ic}</span>
            <span style={{ flex:1 }}>{n.lb}</span>
            {n.badge && unread > 0 && (
              <span style={{ background:'var(--red)', color:'#fff', borderRadius:99, fontSize:10, padding:'1px 6px', fontWeight:700 }}>
                {unread}
              </span>
            )}
          </NavLink>
        ))}
      </nav>

      {/* ── LOGOUT ── */}
      <div style={{ padding:'8px 7px', borderTop:'1px solid var(--border)' }}>
        <button onClick={logout} className="btn btn-ghost btn-full btn-sm"
          style={{ justifyContent:'flex-start', gap:8, fontSize:12 }}>
          ⎋ Sign Out
        </button>
      </div>
    </>
  )

  return (
    <div style={{ display:'flex', minHeight:'100vh', background:'var(--dark)' }}>
      {/* Desktop sidebar */}
      <aside style={{
        width:'var(--sidebar-w)', flexShrink:0,
        background:'var(--surface)', borderRight:'1px solid var(--border)',
        display:'flex', flexDirection:'column',
        position:'fixed', top:0, left:0, bottom:0, zIndex:50,
      }} className={sidebarOpen ? 'sidebar-open' : ''}>
        {sidebar}
      </aside>

      {/* Mobile overlay */}
      {sidebarOpen && (
        <div onClick={() => setSidebarOpen(false)}
          style={{ position:'fixed', inset:0, background:'rgba(0,0,0,0.6)', zIndex:49 }} />
      )}

      {/* Main */}
      <main style={{ marginLeft:'var(--sidebar-w)', flex:1, minHeight:'100vh', overflowX:'hidden' }}>
        {/* Mobile topbar */}
        <div className="mobile-topbar" style={{
          display:'none', alignItems:'center', justifyContent:'space-between',
          padding:'0 16px', height:56,
          background:'var(--surface)', borderBottom:'1px solid var(--border)',
          position:'sticky', top:0, zIndex:40
        }}>
          <img src={coboLogo} alt="COBO" style={{ height:40, objectFit:'cover', objectPosition:'right center', borderRadius:6 }} />
          <button onClick={() => setSidebarOpen(p => !p)} style={{
            background:'none', border:'1px solid var(--border)', borderRadius:8,
            padding:'6px 10px', cursor:'pointer', color:'var(--text-dim)', fontSize:14
          }}>☰</button>
        </div>
        <Outlet />
      </main>

      <style>{`
        @media (max-width: 768px) {
          aside { transform: translateX(-100%) !important; transition: transform 0.25s !important; }
          aside.sidebar-open { transform: translateX(0) !important; }
          main { margin-left: 0 !important; }
          .mobile-topbar { display: flex !important; }
        }
      `}</style>
    </div>
  )
}
