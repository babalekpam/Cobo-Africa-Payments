/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        gold: { DEFAULT: '#E8A940', light: '#F5C96A', dim: '#8A6320' },
        earth: { DEFAULT: '#1A1208', dark: '#0D0B07' },
        surface: { DEFAULT: '#1E1A10', 2: '#2A2416', 3: '#342D1C' },
        coral: '#E8624A',
        cobo: {
          bg: '#0D0B07',
          surface: '#1E1A10',
          border: '#342D1C',
          text: '#F0E8D5',
          muted: '#9A8F75',
          faint: '#5A5240',
        }
      },
      fontFamily: {
        display: ['Syne', 'sans-serif'],
        body: ['DM Sans', 'sans-serif'],
      },
      backgroundImage: {
        'gold-gradient': 'linear-gradient(135deg, #E8A940, #D4941E)',
        'surface-gradient': 'linear-gradient(135deg, #2A2010, #1E1A10)',
      }
    }
  },
  plugins: []
}
